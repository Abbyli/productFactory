/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ final class BufferingClientHttpRequestWrapper extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final ClientHttpRequest request;
/*    */ 
/*    */   BufferingClientHttpRequestWrapper(ClientHttpRequest request)
/*    */   {
/* 40 */     Assert.notNull(request, "'request' must not be null");
/* 41 */     this.request = request;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 46 */     return this.request.getMethod();
/*    */   }
/*    */ 
/*    */   public URI getURI() {
/* 50 */     return this.request.getURI();
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException
/*    */   {
/* 55 */     this.request.getHeaders().putAll(headers);
/* 56 */     StreamUtils.copy(bufferedOutput, this.request.getBody());
/* 57 */     ClientHttpResponse response = this.request.execute();
/* 58 */     return new BufferingClientHttpResponseWrapper(response);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.BufferingClientHttpRequestWrapper
 * JD-Core Version:    0.6.1
 */