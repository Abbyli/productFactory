/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.MarshalException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.PropertyException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ public class Jaxb2RootElementHttpMessageConverter extends AbstractJaxb2HttpMessageConverter<Object>
/*     */ {
/*  63 */   private boolean processExternalEntities = false;
/*     */ 
/* 167 */   private static final EntityResolver NO_OP_ENTITY_RESOLVER = new EntityResolver()
/*     */   {
/*     */     public InputSource resolveEntity(String publicId, String systemId) {
/* 170 */       return new InputSource(new StringReader(""));
/*     */     }
/* 167 */   };
/*     */ 
/*     */   public void setProcessExternalEntities(boolean processExternalEntities)
/*     */   {
/*  71 */     this.processExternalEntities = processExternalEntities;
/*     */   }
/*     */ 
/*     */   public boolean isProcessExternalEntities()
/*     */   {
/*  78 */     return this.processExternalEntities;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  84 */     return ((clazz.isAnnotationPresent(XmlRootElement.class)) || (clazz.isAnnotationPresent(XmlType.class))) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  90 */     return (AnnotationUtils.findAnnotation(clazz, XmlRootElement.class) != null) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  96 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readFromSource(Class<?> clazz, HttpHeaders headers, Source source) throws IOException
/*     */   {
/*     */     try {
/* 102 */       source = processSource(source);
/* 103 */       Unmarshaller unmarshaller = createUnmarshaller(clazz);
/* 104 */       if (clazz.isAnnotationPresent(XmlRootElement.class)) {
/* 105 */         return unmarshaller.unmarshal(source);
/*     */       }
/*     */ 
/* 108 */       JAXBElement jaxbElement = unmarshaller.unmarshal(source, clazz);
/* 109 */       return jaxbElement.getValue();
/*     */     }
/*     */     catch (UnmarshalException ex)
/*     */     {
/* 113 */       throw new HttpMessageNotReadableException("Could not unmarshal to [" + clazz + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex)
/*     */     {
/* 117 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Source processSource(Source source) {
/* 122 */     if ((source instanceof StreamSource)) {
/* 123 */       StreamSource streamSource = (StreamSource)source;
/* 124 */       InputSource inputSource = new InputSource(streamSource.getInputStream());
/*     */       try {
/* 126 */         XMLReader xmlReader = XMLReaderFactory.createXMLReader();
/* 127 */         String featureName = "http://xml.org/sax/features/external-general-entities";
/* 128 */         xmlReader.setFeature(featureName, isProcessExternalEntities());
/* 129 */         if (!isProcessExternalEntities()) {
/* 130 */           xmlReader.setEntityResolver(NO_OP_ENTITY_RESOLVER);
/*     */         }
/* 132 */         return new SAXSource(xmlReader, inputSource);
/*     */       }
/*     */       catch (SAXException ex) {
/* 135 */         this.logger.warn("Processing of external entities could not be disabled", ex);
/* 136 */         return source;
/*     */       }
/*     */     }
/*     */ 
/* 140 */     return source;
/*     */   }
/*     */ 
/*     */   protected void writeToResult(Object o, HttpHeaders headers, Result result) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 147 */       Class clazz = ClassUtils.getUserClass(o);
/* 148 */       Marshaller marshaller = createMarshaller(clazz);
/* 149 */       setCharset(headers.getContentType(), marshaller);
/* 150 */       marshaller.marshal(o, result);
/*     */     }
/*     */     catch (MarshalException ex) {
/* 153 */       throw new HttpMessageNotWritableException("Could not marshal [" + o + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex) {
/* 156 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setCharset(MediaType contentType, Marshaller marshaller) throws PropertyException {
/* 161 */     if ((contentType != null) && (contentType.getCharSet() != null))
/* 162 */       marshaller.setProperty("jaxb.encoding", contentType.getCharSet().name());
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter
 * JD-Core Version:    0.6.1
 */