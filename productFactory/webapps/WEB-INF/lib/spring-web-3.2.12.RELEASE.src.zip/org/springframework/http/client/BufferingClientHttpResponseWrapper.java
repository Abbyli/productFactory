/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpStatus;
/*    */ import org.springframework.util.StreamUtils;
/*    */ 
/*    */ final class BufferingClientHttpResponseWrapper
/*    */   implements ClientHttpResponse
/*    */ {
/*    */   private final ClientHttpResponse response;
/*    */   private byte[] body;
/*    */ 
/*    */   BufferingClientHttpResponseWrapper(ClientHttpResponse response)
/*    */   {
/* 43 */     this.response = response;
/*    */   }
/*    */ 
/*    */   public HttpStatus getStatusCode() throws IOException
/*    */   {
/* 48 */     return this.response.getStatusCode();
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode() throws IOException {
/* 52 */     return this.response.getRawStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException {
/* 56 */     return this.response.getStatusText();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders() {
/* 60 */     return this.response.getHeaders();
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException {
/* 64 */     if (this.body == null) {
/* 65 */       this.body = StreamUtils.copyToByteArray(this.response.getBody());
/*    */     }
/* 67 */     return new ByteArrayInputStream(this.body);
/*    */   }
/*    */ 
/*    */   public void close() {
/* 71 */     this.response.close();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.BufferingClientHttpResponseWrapper
 * JD-Core Version:    0.6.1
 */