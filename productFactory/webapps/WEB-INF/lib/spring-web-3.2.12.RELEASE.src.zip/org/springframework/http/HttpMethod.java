/*    */ package org.springframework.http;
/*    */ 
/*    */ public enum HttpMethod
/*    */ {
/* 29 */   GET, POST, HEAD, OPTIONS, PUT, PATCH, DELETE, TRACE;
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpMethod
 * JD-Core Version:    0.6.1
 */