package org.springframework.http.client;

import java.io.IOException;
import java.net.URI;
import org.springframework.http.HttpMethod;

public abstract interface ClientHttpRequestFactory
{
  public abstract ClientHttpRequest createRequest(URI paramURI, HttpMethod paramHttpMethod)
    throws IOException;
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.ClientHttpRequestFactory
 * JD-Core Version:    0.6.1
 */