/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.TreeSet;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.comparator.CompoundComparator;
/*     */ 
/*     */ public class MediaType
/*     */   implements Comparable<MediaType>
/*     */ {
/* 245 */   public static final MediaType ALL = valueOf("*/*");
/*     */   public static final String ALL_VALUE = "*/*";
/* 246 */   public static final MediaType APPLICATION_ATOM_XML = valueOf("application/atom+xml");
/*     */   public static final String APPLICATION_ATOM_XML_VALUE = "application/atom+xml";
/* 247 */   public static final MediaType APPLICATION_FORM_URLENCODED = valueOf("application/x-www-form-urlencoded");
/*     */   public static final String APPLICATION_FORM_URLENCODED_VALUE = "application/x-www-form-urlencoded";
/* 248 */   public static final MediaType APPLICATION_JSON = valueOf("application/json");
/*     */   public static final String APPLICATION_JSON_VALUE = "application/json";
/* 249 */   public static final MediaType APPLICATION_OCTET_STREAM = valueOf("application/octet-stream");
/*     */   public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream";
/* 250 */   public static final MediaType APPLICATION_XHTML_XML = valueOf("application/xhtml+xml");
/*     */   public static final String APPLICATION_XHTML_XML_VALUE = "application/xhtml+xml";
/* 251 */   public static final MediaType APPLICATION_XML = valueOf("application/xml");
/*     */   public static final String APPLICATION_XML_VALUE = "application/xml";
/* 252 */   public static final MediaType IMAGE_GIF = valueOf("image/gif");
/*     */   public static final String IMAGE_GIF_VALUE = "image/gif";
/* 253 */   public static final MediaType IMAGE_JPEG = valueOf("image/jpeg");
/*     */   public static final String IMAGE_JPEG_VALUE = "image/jpeg";
/* 254 */   public static final MediaType IMAGE_PNG = valueOf("image/png");
/*     */   public static final String IMAGE_PNG_VALUE = "image/png";
/* 255 */   public static final MediaType MULTIPART_FORM_DATA = valueOf("multipart/form-data");
/*     */   public static final String MULTIPART_FORM_DATA_VALUE = "multipart/form-data";
/* 256 */   public static final MediaType TEXT_HTML = valueOf("text/html");
/*     */   public static final String TEXT_HTML_VALUE = "text/html";
/* 257 */   public static final MediaType TEXT_PLAIN = valueOf("text/plain");
/*     */   public static final String TEXT_PLAIN_VALUE = "text/plain";
/* 258 */   public static final MediaType TEXT_XML = valueOf("text/xml");
/*     */   public static final String TEXT_XML_VALUE = "text/xml";
/*     */   private static final BitSet TOKEN;
/*     */   private static final String WILDCARD_TYPE = "*";
/*     */   private static final String PARAM_QUALITY_FACTOR = "q";
/*     */   private static final String PARAM_CHARSET = "charset";
/*     */   private final String type;
/*     */   private final String subtype;
/*     */   private final Map<String, String> parameters;
/* 850 */   public static final Comparator<MediaType> SPECIFICITY_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(MediaType mediaType1, MediaType mediaType2) {
/* 853 */       if ((mediaType1.isWildcardType()) && (!mediaType2.isWildcardType())) {
/* 854 */         return 1;
/*     */       }
/* 856 */       if ((mediaType2.isWildcardType()) && (!mediaType1.isWildcardType())) {
/* 857 */         return -1;
/*     */       }
/* 859 */       if (!mediaType1.getType().equals(mediaType2.getType())) {
/* 860 */         return 0;
/*     */       }
/*     */ 
/* 863 */       if ((mediaType1.isWildcardSubtype()) && (!mediaType2.isWildcardSubtype())) {
/* 864 */         return 1;
/*     */       }
/* 866 */       if ((mediaType2.isWildcardSubtype()) && (!mediaType1.isWildcardSubtype())) {
/* 867 */         return -1;
/*     */       }
/* 869 */       if (!mediaType1.getSubtype().equals(mediaType2.getSubtype())) {
/* 870 */         return 0;
/*     */       }
/*     */ 
/* 873 */       double quality1 = mediaType1.getQualityValue();
/* 874 */       double quality2 = mediaType2.getQualityValue();
/* 875 */       int qualityComparison = Double.compare(quality2, quality1);
/* 876 */       if (qualityComparison != 0) {
/* 877 */         return qualityComparison;
/*     */       }
/*     */ 
/* 880 */       int paramsSize1 = mediaType1.parameters.size();
/* 881 */       int paramsSize2 = mediaType2.parameters.size();
/* 882 */       return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */     }
/* 850 */   };
/*     */ 
/* 893 */   public static final Comparator<MediaType> QUALITY_VALUE_COMPARATOR = new Comparator()
/*     */   {
/*     */     public int compare(MediaType mediaType1, MediaType mediaType2) {
/* 896 */       double quality1 = mediaType1.getQualityValue();
/* 897 */       double quality2 = mediaType2.getQualityValue();
/* 898 */       int qualityComparison = Double.compare(quality2, quality1);
/* 899 */       if (qualityComparison != 0) {
/* 900 */         return qualityComparison;
/*     */       }
/* 902 */       if ((mediaType1.isWildcardType()) && (!mediaType2.isWildcardType())) {
/* 903 */         return 1;
/*     */       }
/* 905 */       if ((mediaType2.isWildcardType()) && (!mediaType1.isWildcardType())) {
/* 906 */         return -1;
/*     */       }
/* 908 */       if (!mediaType1.getType().equals(mediaType2.getType())) {
/* 909 */         return 0;
/*     */       }
/*     */ 
/* 912 */       if ((mediaType1.isWildcardSubtype()) && (!mediaType2.isWildcardSubtype())) {
/* 913 */         return 1;
/*     */       }
/* 915 */       if ((mediaType2.isWildcardSubtype()) && (!mediaType1.isWildcardSubtype())) {
/* 916 */         return -1;
/*     */       }
/* 918 */       if (!mediaType1.getSubtype().equals(mediaType2.getSubtype())) {
/* 919 */         return 0;
/*     */       }
/*     */ 
/* 922 */       int paramsSize1 = mediaType1.parameters.size();
/* 923 */       int paramsSize2 = mediaType2.parameters.size();
/* 924 */       return paramsSize2 == paramsSize1 ? 0 : paramsSize2 < paramsSize1 ? -1 : 1;
/*     */     }
/* 893 */   };
/*     */ 
/*     */   public MediaType(String type)
/*     */   {
/* 269 */     this(type, "*");
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype)
/*     */   {
/* 280 */     this(type, subtype, Collections.emptyMap());
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Charset charset)
/*     */   {
/* 291 */     this(type, subtype, Collections.singletonMap("charset", charset.name()));
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, double qualityValue)
/*     */   {
/* 302 */     this(type, subtype, Collections.singletonMap("q", Double.toString(qualityValue)));
/*     */   }
/*     */ 
/*     */   public MediaType(MediaType other, Map<String, String> parameters)
/*     */   {
/* 313 */     this(other.getType(), other.getSubtype(), parameters);
/*     */   }
/*     */ 
/*     */   public MediaType(String type, String subtype, Map<String, String> parameters)
/*     */   {
/* 324 */     Assert.hasLength(type, "type must not be empty");
/* 325 */     Assert.hasLength(subtype, "subtype must not be empty");
/* 326 */     checkToken(type);
/* 327 */     checkToken(subtype);
/* 328 */     this.type = type.toLowerCase(Locale.ENGLISH);
/* 329 */     this.subtype = subtype.toLowerCase(Locale.ENGLISH);
/* 330 */     if (!CollectionUtils.isEmpty(parameters)) {
/* 331 */       Map m = new LinkedCaseInsensitiveMap(parameters.size(), Locale.ENGLISH);
/* 332 */       for (Map.Entry entry : parameters.entrySet()) {
/* 333 */         String attribute = (String)entry.getKey();
/* 334 */         String value = (String)entry.getValue();
/* 335 */         checkParameters(attribute, value);
/* 336 */         m.put(attribute, value);
/*     */       }
/* 338 */       this.parameters = Collections.unmodifiableMap(m);
/*     */     }
/*     */     else {
/* 341 */       this.parameters = Collections.emptyMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkToken(String token)
/*     */   {
/* 351 */     for (int i = 0; i < token.length(); i++) {
/* 352 */       char ch = token.charAt(i);
/* 353 */       if (!TOKEN.get(ch))
/* 354 */         throw new IllegalArgumentException("Invalid token character '" + ch + "' in token \"" + token + "\"");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkParameters(String attribute, String value)
/*     */   {
/* 360 */     Assert.hasLength(attribute, "parameter attribute must not be empty");
/* 361 */     Assert.hasLength(value, "parameter value must not be empty");
/* 362 */     checkToken(attribute);
/* 363 */     if ("q".equals(attribute)) {
/* 364 */       value = unquote(value);
/* 365 */       double d = Double.parseDouble(value);
/* 366 */       Assert.isTrue((d >= 0.0D) && (d <= 1.0D), "Invalid quality value \"" + value + "\": should be between 0.0 and 1.0");
/*     */     }
/* 369 */     else if ("charset".equals(attribute)) {
/* 370 */       value = unquote(value);
/* 371 */       Charset.forName(value);
/*     */     }
/* 373 */     else if (!isQuotedString(value)) {
/* 374 */       checkToken(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isQuotedString(String s) {
/* 379 */     if (s.length() < 2) {
/* 380 */       return false;
/*     */     }
/*     */ 
/* 383 */     return ((s.startsWith("\"")) && (s.endsWith("\""))) || ((s.startsWith("'")) && (s.endsWith("'")));
/*     */   }
/*     */ 
/*     */   private String unquote(String s)
/*     */   {
/* 388 */     if (s == null) {
/* 389 */       return null;
/*     */     }
/* 391 */     return isQuotedString(s) ? s.substring(1, s.length() - 1) : s;
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 398 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean isWildcardType()
/*     */   {
/* 405 */     return "*".equals(this.type);
/*     */   }
/*     */ 
/*     */   public String getSubtype()
/*     */   {
/* 412 */     return this.subtype;
/*     */   }
/*     */ 
/*     */   public boolean isWildcardSubtype()
/*     */   {
/* 421 */     return ("*".equals(this.subtype)) || (this.subtype.startsWith("*+"));
/*     */   }
/*     */ 
/*     */   public boolean isConcrete()
/*     */   {
/* 430 */     return (!isWildcardType()) && (!isWildcardSubtype());
/*     */   }
/*     */ 
/*     */   public Charset getCharSet()
/*     */   {
/* 438 */     String charSet = getParameter("charset");
/* 439 */     return charSet != null ? Charset.forName(unquote(charSet)) : null;
/*     */   }
/*     */ 
/*     */   public double getQualityValue()
/*     */   {
/* 448 */     String qualityFactory = getParameter("q");
/* 449 */     return qualityFactory != null ? Double.parseDouble(unquote(qualityFactory)) : 1.0D;
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 458 */     return (String)this.parameters.get(name);
/*     */   }
/*     */ 
/*     */   public Map<String, String> getParameters()
/*     */   {
/* 466 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public boolean includes(MediaType other)
/*     */   {
/* 477 */     if (other == null) {
/* 478 */       return false;
/*     */     }
/* 480 */     if (isWildcardType())
/*     */     {
/* 482 */       return true;
/*     */     }
/* 484 */     if (this.type.equals(other.type)) {
/* 485 */       if (this.subtype.equals(other.subtype)) {
/* 486 */         return true;
/*     */       }
/* 488 */       if (isWildcardSubtype())
/*     */       {
/* 490 */         int thisPlusIdx = this.subtype.indexOf('+');
/* 491 */         if (thisPlusIdx == -1) {
/* 492 */           return true;
/*     */         }
/*     */ 
/* 496 */         int otherPlusIdx = other.subtype.indexOf('+');
/* 497 */         if (otherPlusIdx != -1) {
/* 498 */           String thisSubtypeNoSuffix = this.subtype.substring(0, thisPlusIdx);
/* 499 */           String thisSubtypeSuffix = this.subtype.substring(thisPlusIdx + 1);
/* 500 */           String otherSubtypeSuffix = other.subtype.substring(otherPlusIdx + 1);
/* 501 */           if ((thisSubtypeSuffix.equals(otherSubtypeSuffix)) && ("*".equals(thisSubtypeNoSuffix))) {
/* 502 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 508 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isCompatibleWith(MediaType other)
/*     */   {
/* 519 */     if (other == null) {
/* 520 */       return false;
/*     */     }
/* 522 */     if ((isWildcardType()) || (other.isWildcardType())) {
/* 523 */       return true;
/*     */     }
/* 525 */     if (this.type.equals(other.type)) {
/* 526 */       if (this.subtype.equals(other.subtype)) {
/* 527 */         return true;
/*     */       }
/*     */ 
/* 530 */       if ((isWildcardSubtype()) || (other.isWildcardSubtype()))
/*     */       {
/* 532 */         int thisPlusIdx = this.subtype.indexOf('+');
/* 533 */         int otherPlusIdx = other.subtype.indexOf('+');
/*     */ 
/* 535 */         if ((thisPlusIdx == -1) && (otherPlusIdx == -1)) {
/* 536 */           return true;
/*     */         }
/* 538 */         if ((thisPlusIdx != -1) && (otherPlusIdx != -1)) {
/* 539 */           String thisSubtypeNoSuffix = this.subtype.substring(0, thisPlusIdx);
/* 540 */           String otherSubtypeNoSuffix = other.subtype.substring(0, otherPlusIdx);
/*     */ 
/* 542 */           String thisSubtypeSuffix = this.subtype.substring(thisPlusIdx + 1);
/* 543 */           String otherSubtypeSuffix = other.subtype.substring(otherPlusIdx + 1);
/*     */ 
/* 545 */           if ((thisSubtypeSuffix.equals(otherSubtypeSuffix)) && (("*".equals(thisSubtypeNoSuffix)) || ("*".equals(otherSubtypeNoSuffix))))
/*     */           {
/* 547 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 552 */     return false;
/*     */   }
/*     */ 
/*     */   public MediaType copyQualityValue(MediaType mediaType)
/*     */   {
/* 560 */     if (!mediaType.parameters.containsKey("q")) {
/* 561 */       return this;
/*     */     }
/* 563 */     Map params = new LinkedHashMap(this.parameters);
/* 564 */     params.put("q", mediaType.parameters.get("q"));
/* 565 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public MediaType removeQualityValue()
/*     */   {
/* 573 */     if (!this.parameters.containsKey("q")) {
/* 574 */       return this;
/*     */     }
/* 576 */     Map params = new LinkedHashMap(this.parameters);
/* 577 */     params.remove("q");
/* 578 */     return new MediaType(this, params);
/*     */   }
/*     */ 
/*     */   public int compareTo(MediaType other)
/*     */   {
/* 587 */     int comp = this.type.compareToIgnoreCase(other.type);
/* 588 */     if (comp != 0) {
/* 589 */       return comp;
/*     */     }
/* 591 */     comp = this.subtype.compareToIgnoreCase(other.subtype);
/* 592 */     if (comp != 0) {
/* 593 */       return comp;
/*     */     }
/* 595 */     comp = this.parameters.size() - other.parameters.size();
/* 596 */     if (comp != 0) {
/* 597 */       return comp;
/*     */     }
/* 599 */     TreeSet thisAttributes = new TreeSet(String.CASE_INSENSITIVE_ORDER);
/* 600 */     thisAttributes.addAll(this.parameters.keySet());
/* 601 */     TreeSet otherAttributes = new TreeSet(String.CASE_INSENSITIVE_ORDER);
/* 602 */     otherAttributes.addAll(other.parameters.keySet());
/* 603 */     Iterator thisAttributesIterator = thisAttributes.iterator();
/* 604 */     Iterator otherAttributesIterator = otherAttributes.iterator();
/* 605 */     while (thisAttributesIterator.hasNext()) {
/* 606 */       String thisAttribute = (String)thisAttributesIterator.next();
/* 607 */       String otherAttribute = (String)otherAttributesIterator.next();
/* 608 */       comp = thisAttribute.compareToIgnoreCase(otherAttribute);
/* 609 */       if (comp != 0) {
/* 610 */         return comp;
/*     */       }
/* 612 */       String thisValue = (String)this.parameters.get(thisAttribute);
/* 613 */       String otherValue = (String)other.parameters.get(otherAttribute);
/* 614 */       if (otherValue == null) {
/* 615 */         otherValue = "";
/*     */       }
/* 617 */       comp = thisValue.compareTo(otherValue);
/* 618 */       if (comp != 0) {
/* 619 */         return comp;
/*     */       }
/*     */     }
/* 622 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 627 */     if (this == other) {
/* 628 */       return true;
/*     */     }
/* 630 */     if (!(other instanceof MediaType)) {
/* 631 */       return false;
/*     */     }
/* 633 */     MediaType otherType = (MediaType)other;
/* 634 */     return (this.type.equalsIgnoreCase(otherType.type)) && (this.subtype.equalsIgnoreCase(otherType.subtype)) && (this.parameters.equals(otherType.parameters));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 640 */     int result = this.type.hashCode();
/* 641 */     result = 31 * result + this.subtype.hashCode();
/* 642 */     result = 31 * result + this.parameters.hashCode();
/* 643 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 648 */     StringBuilder builder = new StringBuilder();
/* 649 */     appendTo(builder);
/* 650 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   private void appendTo(StringBuilder builder) {
/* 654 */     builder.append(this.type);
/* 655 */     builder.append('/');
/* 656 */     builder.append(this.subtype);
/* 657 */     appendTo(this.parameters, builder);
/*     */   }
/*     */ 
/*     */   private void appendTo(Map<String, String> map, StringBuilder builder) {
/* 661 */     for (Map.Entry entry : map.entrySet()) {
/* 662 */       builder.append(';');
/* 663 */       builder.append((String)entry.getKey());
/* 664 */       builder.append('=');
/* 665 */       builder.append((String)entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static MediaType valueOf(String value)
/*     */   {
/* 677 */     return parseMediaType(value);
/*     */   }
/*     */ 
/*     */   public static MediaType parseMediaType(String mediaType)
/*     */   {
/* 687 */     Assert.hasLength(mediaType, "'mediaType' must not be empty");
/* 688 */     String[] parts = StringUtils.tokenizeToStringArray(mediaType, ";");
/*     */ 
/* 690 */     String fullType = parts[0].trim();
/*     */ 
/* 692 */     if ("*".equals(fullType)) {
/* 693 */       fullType = "*/*";
/*     */     }
/* 695 */     int subIndex = fullType.indexOf('/');
/* 696 */     if (subIndex == -1) {
/* 697 */       throw new InvalidMediaTypeException(mediaType, "does not contain '/'");
/*     */     }
/* 699 */     if (subIndex == fullType.length() - 1) {
/* 700 */       throw new InvalidMediaTypeException(mediaType, "does not contain subtype after '/'");
/*     */     }
/* 702 */     String type = fullType.substring(0, subIndex);
/* 703 */     String subtype = fullType.substring(subIndex + 1, fullType.length());
/* 704 */     if (("*".equals(type)) && (!"*".equals(subtype))) {
/* 705 */       throw new InvalidMediaTypeException(mediaType, "wildcard type is legal only in '*/*' (all media types)");
/*     */     }
/*     */ 
/* 708 */     Map parameters = null;
/* 709 */     if (parts.length > 1) {
/* 710 */       parameters = new LinkedHashMap(parts.length - 1);
/* 711 */       for (int i = 1; i < parts.length; i++) {
/* 712 */         String parameter = parts[i];
/* 713 */         int eqIndex = parameter.indexOf('=');
/* 714 */         if (eqIndex != -1) {
/* 715 */           String attribute = parameter.substring(0, eqIndex);
/* 716 */           String value = parameter.substring(eqIndex + 1, parameter.length());
/* 717 */           parameters.put(attribute, value);
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 723 */       return new MediaType(type, subtype, parameters);
/*     */     }
/*     */     catch (UnsupportedCharsetException ex) {
/* 726 */       throw new InvalidMediaTypeException(mediaType, "unsupported charset '" + ex.getCharsetName() + "'");
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 729 */       throw new InvalidMediaTypeException(mediaType, ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static List<MediaType> parseMediaTypes(String mediaTypes)
/*     */   {
/* 742 */     if (!StringUtils.hasLength(mediaTypes)) {
/* 743 */       return Collections.emptyList();
/*     */     }
/* 745 */     String[] tokens = mediaTypes.split(",\\s*");
/* 746 */     List result = new ArrayList(tokens.length);
/* 747 */     for (String token : tokens) {
/* 748 */       result.add(parseMediaType(token));
/*     */     }
/* 750 */     return result;
/*     */   }
/*     */ 
/*     */   public static String toString(Collection<MediaType> mediaTypes)
/*     */   {
/* 761 */     StringBuilder builder = new StringBuilder();
/* 762 */     for (Iterator iterator = mediaTypes.iterator(); iterator.hasNext(); ) {
/* 763 */       MediaType mediaType = (MediaType)iterator.next();
/* 764 */       mediaType.appendTo(builder);
/* 765 */       if (iterator.hasNext()) {
/* 766 */         builder.append(", ");
/*     */       }
/*     */     }
/* 769 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificity(List<MediaType> mediaTypes)
/*     */   {
/* 799 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 800 */     if (mediaTypes.size() > 1)
/* 801 */       Collections.sort(mediaTypes, SPECIFICITY_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortByQualityValue(List<MediaType> mediaTypes)
/*     */   {
/* 826 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 827 */     if (mediaTypes.size() > 1)
/* 828 */       Collections.sort(mediaTypes, QUALITY_VALUE_COMPARATOR);
/*     */   }
/*     */ 
/*     */   public static void sortBySpecificityAndQuality(List<MediaType> mediaTypes)
/*     */   {
/* 839 */     Assert.notNull(mediaTypes, "'mediaTypes' must not be null");
/* 840 */     if (mediaTypes.size() > 1)
/* 841 */       Collections.sort(mediaTypes, new CompoundComparator(new Comparator[] { SPECIFICITY_COMPARATOR, QUALITY_VALUE_COMPARATOR }));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 213 */     BitSet ctl = new BitSet(128);
/* 214 */     for (int i = 0; i <= 31; i++) {
/* 215 */       ctl.set(i);
/*     */     }
/* 217 */     ctl.set(127);
/*     */ 
/* 219 */     BitSet separators = new BitSet(128);
/* 220 */     separators.set(40);
/* 221 */     separators.set(41);
/* 222 */     separators.set(60);
/* 223 */     separators.set(62);
/* 224 */     separators.set(64);
/* 225 */     separators.set(44);
/* 226 */     separators.set(59);
/* 227 */     separators.set(58);
/* 228 */     separators.set(92);
/* 229 */     separators.set(34);
/* 230 */     separators.set(47);
/* 231 */     separators.set(91);
/* 232 */     separators.set(93);
/* 233 */     separators.set(63);
/* 234 */     separators.set(61);
/* 235 */     separators.set(123);
/* 236 */     separators.set(125);
/* 237 */     separators.set(32);
/* 238 */     separators.set(9);
/*     */ 
/* 240 */     TOKEN = new BitSet(128);
/* 241 */     TOKEN.set(0, 128);
/* 242 */     TOKEN.andNot(ctl);
/* 243 */     TOKEN.andNot(separators);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.MediaType
 * JD-Core Version:    0.6.1
 */