/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.HttpEntityEnclosingRequest;
/*    */ import org.apache.http.HttpResponse;
/*    */ import org.apache.http.client.HttpClient;
/*    */ import org.apache.http.client.methods.HttpUriRequest;
/*    */ import org.apache.http.entity.ByteArrayEntity;
/*    */ import org.apache.http.protocol.HttpContext;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ final class HttpComponentsClientHttpRequest extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final HttpClient httpClient;
/*    */   private final HttpUriRequest httpRequest;
/*    */   private final HttpContext httpContext;
/*    */ 
/*    */   HttpComponentsClientHttpRequest(HttpClient httpClient, HttpUriRequest httpRequest, HttpContext httpContext)
/*    */   {
/* 58 */     this.httpClient = httpClient;
/* 59 */     this.httpRequest = httpRequest;
/* 60 */     this.httpContext = httpContext;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 65 */     return HttpMethod.valueOf(this.httpRequest.getMethod());
/*    */   }
/*    */ 
/*    */   public URI getURI() {
/* 69 */     return this.httpRequest.getURI();
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput)
/*    */     throws IOException
/*    */   {
/* 75 */     addHeaders(this.httpRequest, headers);
/*    */ 
/* 77 */     if ((this.httpRequest instanceof HttpEntityEnclosingRequest)) {
/* 78 */       HttpEntityEnclosingRequest entityEnclosingRequest = (HttpEntityEnclosingRequest)this.httpRequest;
/* 79 */       HttpEntity requestEntity = new ByteArrayEntity(bufferedOutput);
/* 80 */       entityEnclosingRequest.setEntity(requestEntity);
/*    */     }
/* 82 */     HttpResponse httpResponse = this.httpClient.execute(this.httpRequest, this.httpContext);
/* 83 */     return new HttpComponentsClientHttpResponse(httpResponse);
/*    */   }
/*    */ 
/*    */   static void addHeaders(HttpUriRequest httpRequest, HttpHeaders headers)
/*    */   {
/* 93 */     for (Map.Entry entry : headers.entrySet()) {
/* 94 */       headerName = (String)entry.getKey();
/* 95 */       if ("Cookie".equalsIgnoreCase(headerName)) {
/* 96 */         String headerValue = StringUtils.collectionToDelimitedString((Collection)entry.getValue(), "; ");
/* 97 */         httpRequest.addHeader(headerName, headerValue);
/*    */       }
/* 99 */       else if ((!"Content-Length".equalsIgnoreCase(headerName)) && (!"Transfer-Encoding".equalsIgnoreCase(headerName)))
/*    */       {
/* 101 */         for (String headerValue : (List)entry.getValue())
/* 102 */           httpRequest.addHeader(headerName, headerValue);
/*    */       }
/*    */     }
/*    */     String headerName;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpRequest
 * JD-Core Version:    0.6.1
 */