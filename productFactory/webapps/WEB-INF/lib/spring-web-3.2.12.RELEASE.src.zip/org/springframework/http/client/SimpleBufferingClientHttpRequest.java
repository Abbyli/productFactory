/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ final class SimpleBufferingClientHttpRequest extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final HttpURLConnection connection;
/*    */   private final boolean outputStreaming;
/*    */ 
/*    */   SimpleBufferingClientHttpRequest(HttpURLConnection connection, boolean outputStreaming)
/*    */   {
/* 48 */     this.connection = connection;
/* 49 */     this.outputStreaming = outputStreaming;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 54 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*    */   }
/*    */ 
/*    */   public URI getURI() {
/*    */     try {
/* 59 */       return this.connection.getURL().toURI();
/*    */     }
/*    */     catch (URISyntaxException ex) {
/* 62 */       throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected ClientHttpResponse executeInternal(HttpHeaders headers, byte[] bufferedOutput) throws IOException
/*    */   {
/* 68 */     addHeaders(this.connection, headers);
/*    */ 
/* 70 */     if ((this.connection.getDoOutput()) && (this.outputStreaming)) {
/* 71 */       this.connection.setFixedLengthStreamingMode(bufferedOutput.length);
/*    */     }
/* 73 */     this.connection.connect();
/* 74 */     if (this.connection.getDoOutput()) {
/* 75 */       FileCopyUtils.copy(bufferedOutput, this.connection.getOutputStream());
/*    */     }
/*    */ 
/* 78 */     return new SimpleClientHttpResponse(this.connection);
/*    */   }
/*    */ 
/*    */   static void addHeaders(HttpURLConnection connection, HttpHeaders headers)
/*    */   {
/* 88 */     for (Map.Entry entry : headers.entrySet()) {
/* 89 */       headerName = (String)entry.getKey();
/* 90 */       if ("Cookie".equalsIgnoreCase(headerName)) {
/* 91 */         String headerValue = StringUtils.collectionToDelimitedString((Collection)entry.getValue(), "; ");
/* 92 */         connection.setRequestProperty(headerName, headerValue);
/*    */       }
/*    */       else {
/* 95 */         for (String headerValue : (List)entry.getValue())
/* 96 */           connection.addRequestProperty(headerName, headerValue);
/*    */       }
/*    */     }
/*    */     String headerName;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleBufferingClientHttpRequest
 * JD-Core Version:    0.6.1
 */