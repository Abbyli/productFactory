/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.imageio.IIOImage;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReadParam;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.ImageWriteParam;
/*     */ import javax.imageio.ImageWriter;
/*     */ import javax.imageio.stream.FileCacheImageInputStream;
/*     */ import javax.imageio.stream.FileCacheImageOutputStream;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import javax.imageio.stream.ImageOutputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageInputStream;
/*     */ import javax.imageio.stream.MemoryCacheImageOutputStream;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class BufferedImageHttpMessageConverter
/*     */   implements HttpMessageConverter<BufferedImage>
/*     */ {
/*  69 */   private final List<MediaType> readableMediaTypes = new ArrayList();
/*     */   private MediaType defaultContentType;
/*     */   private File cacheDir;
/*     */ 
/*     */   public BufferedImageHttpMessageConverter()
/*     */   {
/*  77 */     String[] readerMediaTypes = ImageIO.getReaderMIMETypes();
/*  78 */     for (String mediaType : readerMediaTypes) {
/*  79 */       if (StringUtils.hasText(mediaType)) {
/*  80 */         this.readableMediaTypes.add(MediaType.parseMediaType(mediaType));
/*     */       }
/*     */     }
/*     */ 
/*  84 */     String[] writerMediaTypes = ImageIO.getWriterMIMETypes();
/*  85 */     for (String mediaType : writerMediaTypes)
/*  86 */       if (StringUtils.hasText(mediaType)) {
/*  87 */         this.defaultContentType = MediaType.parseMediaType(mediaType);
/*  88 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setDefaultContentType(MediaType defaultContentType)
/*     */   {
/*  99 */     Assert.notNull(defaultContentType, "'contentType' must not be null");
/* 100 */     Iterator imageWriters = ImageIO.getImageWritersByMIMEType(defaultContentType.toString());
/* 101 */     if (!imageWriters.hasNext()) {
/* 102 */       throw new IllegalArgumentException("Content-Type [" + defaultContentType + "] is not supported by the Java Image I/O API");
/*     */     }
/*     */ 
/* 106 */     this.defaultContentType = defaultContentType;
/*     */   }
/*     */ 
/*     */   public MediaType getDefaultContentType()
/*     */   {
/* 114 */     return this.defaultContentType;
/*     */   }
/*     */ 
/*     */   public void setCacheDir(File cacheDir)
/*     */   {
/* 122 */     Assert.notNull(cacheDir, "'cacheDir' must not be null");
/* 123 */     Assert.isTrue(cacheDir.isDirectory(), "'cacheDir' is not a directory");
/* 124 */     this.cacheDir = cacheDir;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 129 */     return (BufferedImage.class.equals(clazz)) && (isReadable(mediaType));
/*     */   }
/*     */ 
/*     */   private boolean isReadable(MediaType mediaType) {
/* 133 */     if (mediaType == null) {
/* 134 */       return true;
/*     */     }
/* 136 */     Iterator imageReaders = ImageIO.getImageReadersByMIMEType(mediaType.toString());
/* 137 */     return imageReaders.hasNext();
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType) {
/* 141 */     return (BufferedImage.class.equals(clazz)) && (isWritable(mediaType));
/*     */   }
/*     */ 
/*     */   private boolean isWritable(MediaType mediaType) {
/* 145 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 146 */       return true;
/*     */     }
/* 148 */     Iterator imageWriters = ImageIO.getImageWritersByMIMEType(mediaType.toString());
/* 149 */     return imageWriters.hasNext();
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes() {
/* 153 */     return Collections.unmodifiableList(this.readableMediaTypes);
/*     */   }
/*     */ 
/*     */   public BufferedImage read(Class<? extends BufferedImage> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 159 */     ImageInputStream imageInputStream = null;
/* 160 */     ImageReader imageReader = null;
/*     */     try {
/* 162 */       imageInputStream = createImageInputStream(inputMessage.getBody());
/* 163 */       MediaType contentType = inputMessage.getHeaders().getContentType();
/* 164 */       Iterator imageReaders = ImageIO.getImageReadersByMIMEType(contentType.toString());
/* 165 */       if (imageReaders.hasNext()) {
/* 166 */         imageReader = (ImageReader)imageReaders.next();
/* 167 */         ImageReadParam irp = imageReader.getDefaultReadParam();
/* 168 */         process(irp);
/* 169 */         imageReader.setInput(imageInputStream, true);
/* 170 */         return imageReader.read(0, irp);
/*     */       }
/*     */ 
/* 173 */       throw new HttpMessageNotReadableException("Could not find javax.imageio.ImageReader for Content-Type [" + contentType + "]");
/*     */     }
/*     */     finally
/*     */     {
/* 178 */       if (imageReader != null) {
/* 179 */         imageReader.dispose();
/*     */       }
/* 181 */       if (imageInputStream != null)
/*     */         try {
/* 183 */           imageInputStream.close();
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private ImageInputStream createImageInputStream(InputStream is) throws IOException
/*     */   {
/* 193 */     if (this.cacheDir != null) {
/* 194 */       return new FileCacheImageInputStream(is, this.cacheDir);
/*     */     }
/*     */ 
/* 197 */     return new MemoryCacheImageInputStream(is);
/*     */   }
/*     */ 
/*     */   public void write(BufferedImage image, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 204 */     if ((contentType == null) || (contentType.isWildcardType()) || (contentType.isWildcardSubtype())) {
/* 205 */       contentType = getDefaultContentType();
/*     */     }
/* 207 */     Assert.notNull(contentType, "Count not determine Content-Type, set one using the 'defaultContentType' property");
/*     */ 
/* 209 */     outputMessage.getHeaders().setContentType(contentType);
/* 210 */     ImageOutputStream imageOutputStream = null;
/* 211 */     ImageWriter imageWriter = null;
/*     */     try {
/* 213 */       imageOutputStream = createImageOutputStream(outputMessage.getBody());
/* 214 */       Iterator imageWriters = ImageIO.getImageWritersByMIMEType(contentType.toString());
/* 215 */       if (imageWriters.hasNext()) {
/* 216 */         imageWriter = (ImageWriter)imageWriters.next();
/* 217 */         ImageWriteParam iwp = imageWriter.getDefaultWriteParam();
/* 218 */         process(iwp);
/* 219 */         imageWriter.setOutput(imageOutputStream);
/* 220 */         imageWriter.write(null, new IIOImage(image, null, null), iwp);
/*     */       }
/*     */       else {
/* 223 */         throw new HttpMessageNotWritableException("Could not find javax.imageio.ImageWriter for Content-Type [" + contentType + "]");
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 228 */       if (imageWriter != null) {
/* 229 */         imageWriter.dispose();
/*     */       }
/* 231 */       if (imageOutputStream != null)
/*     */         try {
/* 233 */           imageOutputStream.close();
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private ImageOutputStream createImageOutputStream(OutputStream os) throws IOException
/*     */   {
/* 243 */     if (this.cacheDir != null) {
/* 244 */       return new FileCacheImageOutputStream(os, this.cacheDir);
/*     */     }
/*     */ 
/* 247 */     return new MemoryCacheImageOutputStream(os);
/*     */   }
/*     */ 
/*     */   protected void process(ImageReadParam irp)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void process(ImageWriteParam iwp)
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.BufferedImageHttpMessageConverter
 * JD-Core Version:    0.6.1
 */