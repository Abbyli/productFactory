/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import org.codehaus.jackson.JsonEncoding;
/*     */ import org.codehaus.jackson.JsonFactory;
/*     */ import org.codehaus.jackson.JsonGenerator;
/*     */ import org.codehaus.jackson.JsonProcessingException;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.type.TypeFactory;
/*     */ import org.codehaus.jackson.type.JavaType;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MappingJacksonHttpMessageConverter extends AbstractHttpMessageConverter<Object>
/*     */   implements GenericHttpMessageConverter<Object>
/*     */ {
/*  56 */   public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
/*     */ 
/*  59 */   private ObjectMapper objectMapper = new ObjectMapper();
/*     */   private String jsonPrefix;
/*     */   private Boolean prettyPrint;
/*     */ 
/*     */   public MappingJacksonHttpMessageConverter()
/*     */   {
/*  70 */     super(new MediaType[] { new MediaType("application", "json", DEFAULT_CHARSET), new MediaType("application", "*+json", DEFAULT_CHARSET) });
/*     */   }
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/*  85 */     Assert.notNull(objectMapper, "ObjectMapper must not be null");
/*  86 */     this.objectMapper = objectMapper;
/*  87 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObjectMapper()
/*     */   {
/*  94 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public void setJsonPrefix(String jsonPrefix)
/*     */   {
/* 103 */     this.jsonPrefix = jsonPrefix;
/*     */   }
/*     */ 
/*     */   public void setPrefixJson(boolean prefixJson)
/*     */   {
/* 115 */     this.jsonPrefix = (prefixJson ? "{} && " : null);
/*     */   }
/*     */ 
/*     */   public void setPrettyPrint(boolean prettyPrint)
/*     */   {
/* 129 */     this.prettyPrint = Boolean.valueOf(prettyPrint);
/* 130 */     configurePrettyPrint();
/*     */   }
/*     */ 
/*     */   private void configurePrettyPrint() {
/* 134 */     if (this.prettyPrint != null)
/* 135 */       this.objectMapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, this.prettyPrint.booleanValue());
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 142 */     return canRead(clazz, null, mediaType);
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType) {
/* 146 */     JavaType javaType = getJavaType(type, contextClass);
/* 147 */     return (this.objectMapper.canDeserialize(javaType)) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 152 */     return (this.objectMapper.canSerialize(clazz)) && (canWrite(mediaType));
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 158 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected Object readInternal(Class<?> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 165 */     JavaType javaType = getJavaType(clazz, null);
/* 166 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   public Object read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 172 */     JavaType javaType = getJavaType(type, contextClass);
/* 173 */     return readJavaType(javaType, inputMessage);
/*     */   }
/*     */ 
/*     */   private Object readJavaType(JavaType javaType, HttpInputMessage inputMessage) {
/*     */     try {
/* 178 */       return this.objectMapper.readValue(inputMessage.getBody(), javaType);
/*     */     }
/*     */     catch (IOException ex) {
/* 181 */       throw new HttpMessageNotReadableException("Could not read JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Object object, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 189 */     JsonEncoding encoding = getJsonEncoding(outputMessage.getHeaders().getContentType());
/* 190 */     JsonGenerator jsonGenerator = this.objectMapper.getJsonFactory().createJsonGenerator(outputMessage.getBody(), encoding);
/*     */ 
/* 195 */     if (this.objectMapper.getSerializationConfig().isEnabled(SerializationConfig.Feature.INDENT_OUTPUT)) {
/* 196 */       jsonGenerator.useDefaultPrettyPrinter();
/*     */     }
/*     */     try
/*     */     {
/* 200 */       if (this.jsonPrefix != null) {
/* 201 */         jsonGenerator.writeRaw(this.jsonPrefix);
/*     */       }
/* 203 */       this.objectMapper.writeValue(jsonGenerator, object);
/*     */     }
/*     */     catch (JsonProcessingException ex) {
/* 206 */       throw new HttpMessageNotWritableException("Could not write JSON: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JavaType getJavaType(Type type, Class<?> contextClass)
/*     */   {
/* 231 */     return contextClass != null ? TypeFactory.type(type, TypeFactory.type(contextClass)) : TypeFactory.type(type);
/*     */   }
/*     */ 
/*     */   protected JsonEncoding getJsonEncoding(MediaType contentType)
/*     */   {
/* 241 */     if ((contentType != null) && (contentType.getCharSet() != null)) {
/* 242 */       Charset charset = contentType.getCharSet();
/* 243 */       for (JsonEncoding encoding : JsonEncoding.values()) {
/* 244 */         if (charset.name().equals(encoding.getJavaName())) {
/* 245 */           return encoding;
/*     */         }
/*     */       }
/*     */     }
/* 249 */     return JsonEncoding.UTF8;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.MappingJacksonHttpMessageConverter
 * JD-Core Version:    0.6.1
 */