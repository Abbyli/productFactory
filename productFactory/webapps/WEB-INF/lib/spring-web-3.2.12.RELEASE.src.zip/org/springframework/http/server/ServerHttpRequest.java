package org.springframework.http.server;

import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpRequest;

public abstract interface ServerHttpRequest extends HttpRequest, HttpInputMessage
{
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServerHttpRequest
 * JD-Core Version:    0.6.1
 */