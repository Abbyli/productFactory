/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.oxm.Marshaller;
/*     */ import org.springframework.oxm.MarshallingFailureException;
/*     */ import org.springframework.oxm.Unmarshaller;
/*     */ import org.springframework.oxm.UnmarshallingFailureException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MarshallingHttpMessageConverter extends AbstractXmlHttpMessageConverter<Object>
/*     */ {
/*     */   private Marshaller marshaller;
/*     */   private Unmarshaller unmarshaller;
/*     */ 
/*     */   public MarshallingHttpMessageConverter()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MarshallingHttpMessageConverter(Marshaller marshaller)
/*     */   {
/*  71 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  72 */     this.marshaller = marshaller;
/*  73 */     if ((marshaller instanceof Unmarshaller))
/*  74 */       this.unmarshaller = ((Unmarshaller)marshaller);
/*     */   }
/*     */ 
/*     */   public MarshallingHttpMessageConverter(Marshaller marshaller, Unmarshaller unmarshaller)
/*     */   {
/*  85 */     Assert.notNull(marshaller, "Marshaller must not be null");
/*  86 */     Assert.notNull(unmarshaller, "Unmarshaller must not be null");
/*  87 */     this.marshaller = marshaller;
/*  88 */     this.unmarshaller = unmarshaller;
/*     */   }
/*     */ 
/*     */   public void setMarshaller(Marshaller marshaller)
/*     */   {
/*  96 */     this.marshaller = marshaller;
/*     */   }
/*     */ 
/*     */   public void setUnmarshaller(Unmarshaller unmarshaller)
/*     */   {
/* 103 */     this.unmarshaller = unmarshaller;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/* 109 */     return this.unmarshaller.supports(clazz);
/*     */   }
/*     */ 
/*     */   protected Object readFromSource(Class<?> clazz, HttpHeaders headers, Source source) throws IOException
/*     */   {
/* 114 */     Assert.notNull(this.unmarshaller, "Property 'unmarshaller' is required");
/*     */     try {
/* 116 */       Object result = this.unmarshaller.unmarshal(source);
/* 117 */       if (!clazz.isInstance(result)) {
/* 118 */         throw new TypeMismatchException(result, clazz);
/*     */       }
/* 120 */       return result;
/*     */     }
/*     */     catch (UnmarshallingFailureException ex) {
/* 123 */       throw new HttpMessageNotReadableException("Could not read [" + clazz + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeToResult(Object o, HttpHeaders headers, Result result) throws IOException
/*     */   {
/* 129 */     Assert.notNull(this.marshaller, "Property 'marshaller' is required");
/*     */     try {
/* 131 */       this.marshaller.marshal(o, result);
/*     */     }
/*     */     catch (MarshallingFailureException ex) {
/* 134 */       throw new HttpMessageNotWritableException("Could not write [" + o + "]", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.MarshallingHttpMessageConverter
 * JD-Core Version:    0.6.1
 */