/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator.Feature;
/*     */ import com.fasterxml.jackson.core.JsonParser.Feature;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.FatalBeanException;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class Jackson2ObjectMapperFactoryBean
/*     */   implements FactoryBean<ObjectMapper>, InitializingBean
/*     */ {
/*     */   private ObjectMapper objectMapper;
/*     */   private DateFormat dateFormat;
/*     */   private AnnotationIntrospector annotationIntrospector;
/* 109 */   private final Map<Class<?>, JsonSerializer<?>> serializers = new LinkedHashMap();
/*     */ 
/* 111 */   private final Map<Class<?>, JsonDeserializer<?>> deserializers = new LinkedHashMap();
/*     */ 
/* 113 */   private final Map<Object, Boolean> features = new HashMap();
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/* 121 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   public void setDateFormat(DateFormat dateFormat)
/*     */   {
/* 131 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */   public void setSimpleDateFormat(String format)
/*     */   {
/* 141 */     this.dateFormat = new SimpleDateFormat(format);
/*     */   }
/*     */ 
/*     */   public void setAnnotationIntrospector(AnnotationIntrospector annotationIntrospector)
/*     */   {
/* 148 */     this.annotationIntrospector = annotationIntrospector;
/*     */   }
/*     */ 
/*     */   public void setSerializers(JsonSerializer<?>[] serializers)
/*     */   {
/* 158 */     if (serializers != null)
/* 159 */       for (JsonSerializer serializer : serializers) {
/* 160 */         Class handledType = serializer.handledType();
/* 161 */         Assert.isTrue((handledType != null) && (handledType != Object.class), "Unknown handled type in " + serializer.getClass().getName());
/*     */ 
/* 163 */         this.serializers.put(serializer.handledType(), serializer);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setSerializersByType(Map<Class<?>, JsonSerializer<?>> serializers)
/*     */   {
/* 173 */     if (serializers != null)
/* 174 */       this.serializers.putAll(serializers);
/*     */   }
/*     */ 
/*     */   public void setDeserializersByType(Map<Class<?>, JsonDeserializer<?>> deserializers)
/*     */   {
/* 182 */     if (deserializers != null)
/* 183 */       this.deserializers.putAll(deserializers);
/*     */   }
/*     */ 
/*     */   public void setAutoDetectFields(boolean autoDetectFields)
/*     */   {
/* 191 */     this.features.put(MapperFeature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/*     */   }
/*     */ 
/*     */   public void setAutoDetectGettersSetters(boolean autoDetectGettersSetters)
/*     */   {
/* 199 */     this.features.put(MapperFeature.AUTO_DETECT_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 200 */     this.features.put(MapperFeature.AUTO_DETECT_SETTERS, Boolean.valueOf(autoDetectGettersSetters));
/*     */   }
/*     */ 
/*     */   public void setFailOnEmptyBeans(boolean failOnEmptyBeans)
/*     */   {
/* 207 */     this.features.put(SerializationFeature.FAIL_ON_EMPTY_BEANS, Boolean.valueOf(failOnEmptyBeans));
/*     */   }
/*     */ 
/*     */   public void setIndentOutput(boolean indentOutput)
/*     */   {
/* 214 */     this.features.put(SerializationFeature.INDENT_OUTPUT, Boolean.valueOf(indentOutput));
/*     */   }
/*     */ 
/*     */   public void setFeaturesToEnable(Object[] featuresToEnable)
/*     */   {
/* 226 */     if (featuresToEnable != null)
/* 227 */       for (Object feature : featuresToEnable)
/* 228 */         this.features.put(feature, Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   public void setFeaturesToDisable(Object[] featuresToDisable)
/*     */   {
/* 242 */     if (featuresToDisable != null)
/* 243 */       for (Object feature : featuresToDisable)
/* 244 */         this.features.put(feature, Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 251 */     if (this.objectMapper == null) {
/* 252 */       this.objectMapper = new ObjectMapper();
/*     */     }
/*     */ 
/* 255 */     if (this.dateFormat != null) {
/* 256 */       this.objectMapper.setDateFormat(this.dateFormat);
/*     */     }
/*     */ 
/* 259 */     if (this.annotationIntrospector != null) {
/* 260 */       this.objectMapper.setAnnotationIntrospector(this.annotationIntrospector);
/*     */     }
/*     */ 
/* 263 */     if ((!this.serializers.isEmpty()) || (!this.deserializers.isEmpty())) {
/* 264 */       SimpleModule module = new SimpleModule();
/* 265 */       addSerializers(module);
/* 266 */       addDeserializers(module);
/* 267 */       this.objectMapper.registerModule(module);
/*     */     }
/*     */ 
/* 270 */     for (Iterator i$ = this.features.keySet().iterator(); i$.hasNext(); ) { Object feature = i$.next();
/* 271 */       configureFeature(feature, ((Boolean)this.features.get(feature)).booleanValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   private <T> void addSerializers(SimpleModule module)
/*     */   {
/* 277 */     for (Class type : this.serializers.keySet())
/* 278 */       module.addSerializer(type, (JsonSerializer)this.serializers.get(type));
/*     */   }
/*     */ 
/*     */   private <T> void addDeserializers(SimpleModule module)
/*     */   {
/* 284 */     for (Class type : this.deserializers.keySet())
/* 285 */       module.addDeserializer(type, (JsonDeserializer)this.deserializers.get(type));
/*     */   }
/*     */ 
/*     */   private void configureFeature(Object feature, boolean enabled)
/*     */   {
/* 290 */     if ((feature instanceof JsonParser.Feature)) {
/* 291 */       this.objectMapper.configure((JsonParser.Feature)feature, enabled);
/*     */     }
/* 293 */     else if ((feature instanceof JsonGenerator.Feature)) {
/* 294 */       this.objectMapper.configure((JsonGenerator.Feature)feature, enabled);
/*     */     }
/* 296 */     else if ((feature instanceof SerializationFeature)) {
/* 297 */       this.objectMapper.configure((SerializationFeature)feature, enabled);
/*     */     }
/* 299 */     else if ((feature instanceof DeserializationFeature)) {
/* 300 */       this.objectMapper.configure((DeserializationFeature)feature, enabled);
/*     */     }
/* 302 */     else if ((feature instanceof MapperFeature)) {
/* 303 */       this.objectMapper.configure((MapperFeature)feature, enabled);
/*     */     }
/*     */     else
/* 306 */       throw new FatalBeanException("Unknown feature class: " + feature.getClass().getName());
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObject()
/*     */   {
/* 315 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 319 */     return ObjectMapper.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 323 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.Jackson2ObjectMapperFactoryBean
 * JD-Core Version:    0.6.1
 */