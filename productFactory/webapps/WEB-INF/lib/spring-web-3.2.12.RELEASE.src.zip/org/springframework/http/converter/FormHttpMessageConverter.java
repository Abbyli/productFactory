/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class FormHttpMessageConverter
/*     */   implements HttpMessageConverter<MultiValueMap<String, ?>>
/*     */ {
/*  74 */   private static final byte[] BOUNDARY_CHARS = { 45, 95, 49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90 };
/*     */ 
/*  80 */   private final Random rnd = new Random();
/*     */ 
/*  82 */   private Charset charset = Charset.forName("UTF-8");
/*     */ 
/*  84 */   private List<MediaType> supportedMediaTypes = new ArrayList();
/*     */ 
/*  86 */   private List<HttpMessageConverter<?>> partConverters = new ArrayList();
/*     */ 
/*     */   public FormHttpMessageConverter()
/*     */   {
/*  90 */     this.supportedMediaTypes.add(MediaType.APPLICATION_FORM_URLENCODED);
/*  91 */     this.supportedMediaTypes.add(MediaType.MULTIPART_FORM_DATA);
/*     */ 
/*  93 */     this.partConverters.add(new ByteArrayHttpMessageConverter());
/*  94 */     StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter();
/*  95 */     stringHttpMessageConverter.setWriteAcceptCharset(false);
/*  96 */     this.partConverters.add(stringHttpMessageConverter);
/*  97 */     this.partConverters.add(new ResourceHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public final void setPartConverters(List<HttpMessageConverter<?>> partConverters)
/*     */   {
/* 105 */     Assert.notEmpty(partConverters, "'partConverters' must not be empty");
/* 106 */     this.partConverters = partConverters;
/*     */   }
/*     */ 
/*     */   public final void addPartConverter(HttpMessageConverter<?> partConverter)
/*     */   {
/* 113 */     Assert.notNull(partConverter, "'partConverter' must not be NULL");
/* 114 */     this.partConverters.add(partConverter);
/*     */   }
/*     */ 
/*     */   public void setCharset(Charset charset)
/*     */   {
/* 121 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType) {
/* 125 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 126 */       return false;
/*     */     }
/* 128 */     if (mediaType == null) {
/* 129 */       return true;
/*     */     }
/* 131 */     for (MediaType supportedMediaType : getSupportedMediaTypes())
/*     */     {
/* 133 */       if ((!supportedMediaType.equals(MediaType.MULTIPART_FORM_DATA)) && (supportedMediaType.includes(mediaType)))
/*     */       {
/* 135 */         return true;
/*     */       }
/*     */     }
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType) {
/* 142 */     if (!MultiValueMap.class.isAssignableFrom(clazz)) {
/* 143 */       return false;
/*     */     }
/* 145 */     if ((mediaType == null) || (MediaType.ALL.equals(mediaType))) {
/* 146 */       return true;
/*     */     }
/* 148 */     for (MediaType supportedMediaType : getSupportedMediaTypes()) {
/* 149 */       if (supportedMediaType.isCompatibleWith(mediaType)) {
/* 150 */         return true;
/*     */       }
/*     */     }
/* 153 */     return false;
/*     */   }
/*     */ 
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes)
/*     */   {
/* 160 */     this.supportedMediaTypes = supportedMediaTypes;
/*     */   }
/*     */ 
/*     */   public List<MediaType> getSupportedMediaTypes() {
/* 164 */     return Collections.unmodifiableList(this.supportedMediaTypes);
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, String> read(Class<? extends MultiValueMap<String, ?>> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 170 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/* 171 */     Charset charset = contentType.getCharSet() != null ? contentType.getCharSet() : this.charset;
/* 172 */     String body = StreamUtils.copyToString(inputMessage.getBody(), charset);
/*     */ 
/* 174 */     String[] pairs = StringUtils.tokenizeToStringArray(body, "&");
/*     */ 
/* 176 */     MultiValueMap result = new LinkedMultiValueMap(pairs.length);
/*     */ 
/* 178 */     for (String pair : pairs) {
/* 179 */       int idx = pair.indexOf('=');
/* 180 */       if (idx == -1) {
/* 181 */         result.add(URLDecoder.decode(pair, charset.name()), null);
/*     */       }
/*     */       else {
/* 184 */         String name = URLDecoder.decode(pair.substring(0, idx), charset.name());
/* 185 */         String value = URLDecoder.decode(pair.substring(idx + 1), charset.name());
/* 186 */         result.add(name, value);
/*     */       }
/*     */     }
/* 189 */     return result;
/*     */   }
/*     */ 
/*     */   public void write(MultiValueMap<String, ?> map, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/* 195 */     if (!isMultipart(map, contentType)) {
/* 196 */       writeForm(map, contentType, outputMessage);
/*     */     }
/*     */     else
/* 199 */       writeMultipart(map, outputMessage);
/*     */   }
/*     */ 
/*     */   private boolean isMultipart(MultiValueMap<String, ?> map, MediaType contentType)
/*     */   {
/* 204 */     if (contentType != null) {
/* 205 */       return MediaType.MULTIPART_FORM_DATA.equals(contentType);
/*     */     }
/* 207 */     for (String name : map.keySet())
/* 208 */       for (i$ = ((List)map.get(name)).iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 209 */         if ((value != null) && (!(value instanceof String)))
/* 210 */           return true;
/*     */       }
/*     */     Iterator i$;
/* 214 */     return false;
/*     */   }
/*     */ 
/*     */   private void writeForm(MultiValueMap<String, String> form, MediaType contentType, HttpOutputMessage outputMessage)
/*     */     throws IOException
/*     */   {
/*     */     Charset charset;
/*     */     Charset charset;
/* 220 */     if (contentType != null) {
/* 221 */       outputMessage.getHeaders().setContentType(contentType);
/* 222 */       charset = contentType.getCharSet() != null ? contentType.getCharSet() : this.charset;
/*     */     }
/*     */     else {
/* 225 */       outputMessage.getHeaders().setContentType(MediaType.APPLICATION_FORM_URLENCODED);
/* 226 */       charset = this.charset;
/*     */     }
/* 228 */     StringBuilder builder = new StringBuilder();
/* 229 */     for (Iterator nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 230 */       String name = (String)nameIterator.next();
/* 231 */       for (Iterator valueIterator = ((List)form.get(name)).iterator(); valueIterator.hasNext(); ) {
/* 232 */         String value = (String)valueIterator.next();
/* 233 */         builder.append(URLEncoder.encode(name, charset.name()));
/* 234 */         if (value != null) {
/* 235 */           builder.append('=');
/* 236 */           builder.append(URLEncoder.encode(value, charset.name()));
/* 237 */           if (valueIterator.hasNext()) {
/* 238 */             builder.append('&');
/*     */           }
/*     */         }
/*     */       }
/* 242 */       if (nameIterator.hasNext()) {
/* 243 */         builder.append('&');
/*     */       }
/*     */     }
/* 246 */     byte[] bytes = builder.toString().getBytes(charset.name());
/* 247 */     outputMessage.getHeaders().setContentLength(bytes.length);
/* 248 */     StreamUtils.copy(bytes, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */   private void writeMultipart(MultiValueMap<String, Object> parts, HttpOutputMessage outputMessage) throws IOException
/*     */   {
/* 253 */     byte[] boundary = generateMultipartBoundary();
/*     */ 
/* 255 */     Map parameters = Collections.singletonMap("boundary", new String(boundary, "US-ASCII"));
/* 256 */     MediaType contentType = new MediaType(MediaType.MULTIPART_FORM_DATA, parameters);
/* 257 */     outputMessage.getHeaders().setContentType(contentType);
/*     */ 
/* 259 */     writeParts(outputMessage.getBody(), parts, boundary);
/* 260 */     writeEnd(boundary, outputMessage.getBody());
/*     */   }
/*     */ 
/*     */   private void writeParts(OutputStream os, MultiValueMap<String, Object> parts, byte[] boundary) throws IOException {
/* 264 */     for (Map.Entry entry : parts.entrySet()) {
/* 265 */       name = (String)entry.getKey();
/* 266 */       for (i$ = ((List)entry.getValue()).iterator(); i$.hasNext(); ) { Object part = i$.next();
/* 267 */         if (part != null) {
/* 268 */           writeBoundary(boundary, os);
/* 269 */           HttpEntity entity = getEntity(part);
/* 270 */           writePart(name, entity, os);
/* 271 */           writeNewLine(os); }  } 
/*     */     }
/*     */     String name;
/*     */     Iterator i$;
/*     */   }
/*     */ 
/* 278 */   private void writeBoundary(byte[] boundary, OutputStream os) throws IOException { os.write(45);
/* 279 */     os.write(45);
/* 280 */     os.write(boundary);
/* 281 */     writeNewLine(os);
/*     */   }
/*     */ 
/*     */   private HttpEntity getEntity(Object part)
/*     */   {
/* 286 */     if ((part instanceof HttpEntity)) {
/* 287 */       return (HttpEntity)part;
/*     */     }
/*     */ 
/* 290 */     return new HttpEntity(part);
/*     */   }
/*     */ 
/*     */   private void writePart(String name, HttpEntity partEntity, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 296 */     Object partBody = partEntity.getBody();
/* 297 */     Class partType = partBody.getClass();
/* 298 */     HttpHeaders partHeaders = partEntity.getHeaders();
/* 299 */     MediaType partContentType = partHeaders.getContentType();
/* 300 */     for (HttpMessageConverter messageConverter : this.partConverters) {
/* 301 */       if (messageConverter.canWrite(partType, partContentType)) {
/* 302 */         HttpOutputMessage multipartOutputMessage = new MultipartHttpOutputMessage(os);
/* 303 */         multipartOutputMessage.getHeaders().setContentDispositionFormData(name, getFilename(partBody));
/* 304 */         if (!partHeaders.isEmpty()) {
/* 305 */           multipartOutputMessage.getHeaders().putAll(partHeaders);
/*     */         }
/* 307 */         messageConverter.write(partBody, partContentType, multipartOutputMessage);
/* 308 */         return;
/*     */       }
/*     */     }
/* 311 */     throw new HttpMessageNotWritableException("Could not write request: no suitable HttpMessageConverter found for request type [" + partType.getName() + "]");
/*     */   }
/*     */ 
/*     */   private void writeEnd(byte[] boundary, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 317 */     os.write(45);
/* 318 */     os.write(45);
/* 319 */     os.write(boundary);
/* 320 */     os.write(45);
/* 321 */     os.write(45);
/* 322 */     writeNewLine(os);
/*     */   }
/*     */ 
/*     */   private void writeNewLine(OutputStream os) throws IOException {
/* 326 */     os.write(13);
/* 327 */     os.write(10);
/*     */   }
/*     */ 
/*     */   protected byte[] generateMultipartBoundary()
/*     */   {
/* 336 */     byte[] boundary = new byte[this.rnd.nextInt(11) + 30];
/* 337 */     for (int i = 0; i < boundary.length; i++) {
/* 338 */       boundary[i] = BOUNDARY_CHARS[this.rnd.nextInt(BOUNDARY_CHARS.length)];
/*     */     }
/* 340 */     return boundary;
/*     */   }
/*     */ 
/*     */   protected String getFilename(Object part)
/*     */   {
/* 352 */     if ((part instanceof Resource)) {
/* 353 */       Resource resource = (Resource)part;
/* 354 */       return resource.getFilename();
/*     */     }
/*     */ 
/* 357 */     return null;
/*     */   }
/*     */ 
/*     */   private class MultipartHttpOutputMessage
/*     */     implements HttpOutputMessage
/*     */   {
/* 367 */     private final HttpHeaders headers = new HttpHeaders();
/*     */     private final OutputStream os;
/* 371 */     private boolean headersWritten = false;
/*     */ 
/*     */     public MultipartHttpOutputMessage(OutputStream os) {
/* 374 */       this.os = os;
/*     */     }
/*     */ 
/*     */     public HttpHeaders getHeaders() {
/* 378 */       return this.headersWritten ? HttpHeaders.readOnlyHttpHeaders(this.headers) : this.headers;
/*     */     }
/*     */ 
/*     */     public OutputStream getBody() throws IOException {
/* 382 */       writeHeaders();
/* 383 */       return this.os;
/*     */     }
/*     */ 
/*     */     private void writeHeaders() throws IOException {
/* 387 */       if (!this.headersWritten) {
/* 388 */         for (Map.Entry entry : this.headers.entrySet()) {
/* 389 */           headerName = getAsciiBytes((String)entry.getKey());
/* 390 */           for (String headerValueString : (List)entry.getValue()) {
/* 391 */             byte[] headerValue = getAsciiBytes(headerValueString);
/* 392 */             this.os.write(headerName);
/* 393 */             this.os.write(58);
/* 394 */             this.os.write(32);
/* 395 */             this.os.write(headerValue);
/* 396 */             FormHttpMessageConverter.this.writeNewLine(this.os);
/*     */           }
/*     */         }
/*     */         byte[] headerName;
/* 399 */         FormHttpMessageConverter.this.writeNewLine(this.os);
/* 400 */         this.headersWritten = true;
/*     */       }
/*     */     }
/*     */ 
/*     */     protected byte[] getAsciiBytes(String name) {
/*     */       try {
/* 406 */         return name.getBytes("US-ASCII");
/*     */       }
/*     */       catch (UnsupportedEncodingException ex)
/*     */       {
/* 410 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.FormHttpMessageConverter
 * JD-Core Version:    0.6.1
 */