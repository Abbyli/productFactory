/*    */ package org.springframework.http.converter.feed;
/*    */ 
/*    */ import com.sun.syndication.feed.atom.Feed;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public class AtomFeedHttpMessageConverter extends AbstractWireFeedHttpMessageConverter<Feed>
/*    */ {
/*    */   public AtomFeedHttpMessageConverter()
/*    */   {
/* 38 */     super(new MediaType("application", "atom+xml"));
/*    */   }
/*    */ 
/*    */   protected boolean supports(Class<?> clazz)
/*    */   {
/* 43 */     return Feed.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.feed.AtomFeedHttpMessageConverter
 * JD-Core Version:    0.6.1
 */