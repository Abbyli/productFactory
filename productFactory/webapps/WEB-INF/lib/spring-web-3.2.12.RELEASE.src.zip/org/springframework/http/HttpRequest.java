package org.springframework.http;

import java.net.URI;

public abstract interface HttpRequest extends HttpMessage
{
  public abstract HttpMethod getMethod();

  public abstract URI getURI();
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpRequest
 * JD-Core Version:    0.6.1
 */