/*     */ package org.springframework.http;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class HttpHeaders
/*     */   implements MultiValueMap<String, String>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8578554704772377436L;
/*     */   private static final String ACCEPT = "Accept";
/*     */   private static final String ACCEPT_CHARSET = "Accept-Charset";
/*     */   private static final String ALLOW = "Allow";
/*     */   private static final String CACHE_CONTROL = "Cache-Control";
/*     */   private static final String CONTENT_DISPOSITION = "Content-Disposition";
/*     */   private static final String CONTENT_LENGTH = "Content-Length";
/*     */   private static final String CONTENT_TYPE = "Content-Type";
/*     */   private static final String DATE = "Date";
/*     */   private static final String ETAG = "ETag";
/*     */   private static final String EXPIRES = "Expires";
/*     */   private static final String IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String LAST_MODIFIED = "Last-Modified";
/*     */   private static final String LOCATION = "Location";
/*     */   private static final String PRAGMA = "Pragma";
/*  93 */   private static final String[] DATE_FORMATS = { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM dd HH:mm:ss yyyy" };
/*     */ 
/*  99 */   private static TimeZone GMT = TimeZone.getTimeZone("GMT");
/*     */   private final Map<String, List<String>> headers;
/*     */ 
/*     */   private HttpHeaders(Map<String, List<String>> headers, boolean readOnly)
/*     */   {
/* 108 */     Assert.notNull(headers, "'headers' must not be null");
/* 109 */     if (readOnly) {
/* 110 */       Map map = new LinkedCaseInsensitiveMap(headers.size(), Locale.ENGLISH);
/*     */ 
/* 112 */       for (Map.Entry entry : headers.entrySet()) {
/* 113 */         List values = Collections.unmodifiableList((List)entry.getValue());
/* 114 */         map.put(entry.getKey(), values);
/*     */       }
/* 116 */       this.headers = Collections.unmodifiableMap(map);
/*     */     }
/*     */     else {
/* 119 */       this.headers = headers;
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders()
/*     */   {
/* 127 */     this(new LinkedCaseInsensitiveMap(8, Locale.ENGLISH), false);
/*     */   }
/*     */ 
/*     */   public static HttpHeaders readOnlyHttpHeaders(HttpHeaders headers)
/*     */   {
/* 134 */     return new HttpHeaders(headers, true);
/*     */   }
/*     */ 
/*     */   public void setAccept(List<MediaType> acceptableMediaTypes)
/*     */   {
/* 142 */     set("Accept", MediaType.toString(acceptableMediaTypes));
/*     */   }
/*     */ 
/*     */   public List<MediaType> getAccept()
/*     */   {
/* 151 */     String value = getFirst("Accept");
/* 152 */     List result = value != null ? MediaType.parseMediaTypes(value) : Collections.emptyList();
/*     */ 
/* 155 */     if (result.size() == 1) {
/* 156 */       List acceptHeader = get("Accept");
/* 157 */       if (acceptHeader.size() > 1) {
/* 158 */         value = StringUtils.collectionToCommaDelimitedString(acceptHeader);
/* 159 */         result = MediaType.parseMediaTypes(value);
/*     */       }
/*     */     }
/*     */ 
/* 163 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAcceptCharset(List<Charset> acceptableCharsets)
/*     */   {
/* 171 */     StringBuilder builder = new StringBuilder();
/* 172 */     for (Iterator iterator = acceptableCharsets.iterator(); iterator.hasNext(); ) {
/* 173 */       Charset charset = (Charset)iterator.next();
/* 174 */       builder.append(charset.name().toLowerCase(Locale.ENGLISH));
/* 175 */       if (iterator.hasNext()) {
/* 176 */         builder.append(", ");
/*     */       }
/*     */     }
/* 179 */     set("Accept-Charset", builder.toString());
/*     */   }
/*     */ 
/*     */   public List<Charset> getAcceptCharset()
/*     */   {
/* 188 */     List result = new ArrayList();
/* 189 */     String value = getFirst("Accept-Charset");
/* 190 */     if (value != null) {
/* 191 */       String[] tokens = value.split(",\\s*");
/* 192 */       for (String token : tokens) {
/* 193 */         int paramIdx = token.indexOf(';');
/*     */         String charsetName;
/*     */         String charsetName;
/* 195 */         if (paramIdx == -1) {
/* 196 */           charsetName = token;
/*     */         }
/*     */         else {
/* 199 */           charsetName = token.substring(0, paramIdx);
/*     */         }
/* 201 */         if (!charsetName.equals("*")) {
/* 202 */           result.add(Charset.forName(charsetName));
/*     */         }
/*     */       }
/*     */     }
/* 206 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAllow(Set<HttpMethod> allowedMethods)
/*     */   {
/* 214 */     set("Allow", StringUtils.collectionToCommaDelimitedString(allowedMethods));
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> getAllow()
/*     */   {
/* 223 */     String value = getFirst("Allow");
/* 224 */     if (!StringUtils.isEmpty(value)) {
/* 225 */       List allowedMethod = new ArrayList(5);
/* 226 */       String[] tokens = value.split(",\\s*");
/* 227 */       for (String token : tokens) {
/* 228 */         allowedMethod.add(HttpMethod.valueOf(token));
/*     */       }
/* 230 */       return EnumSet.copyOf(allowedMethod);
/*     */     }
/*     */ 
/* 233 */     return EnumSet.noneOf(HttpMethod.class);
/*     */   }
/*     */ 
/*     */   public void setCacheControl(String cacheControl)
/*     */   {
/* 242 */     set("Cache-Control", cacheControl);
/*     */   }
/*     */ 
/*     */   public String getCacheControl()
/*     */   {
/* 250 */     return getFirst("Cache-Control");
/*     */   }
/*     */ 
/*     */   public void setContentDispositionFormData(String name, String filename)
/*     */   {
/* 259 */     Assert.notNull(name, "'name' must not be null");
/* 260 */     StringBuilder builder = new StringBuilder("form-data; name=\"");
/* 261 */     builder.append(name).append('"');
/* 262 */     if (filename != null) {
/* 263 */       builder.append("; filename=\"");
/* 264 */       builder.append(filename).append('"');
/*     */     }
/* 266 */     set("Content-Disposition", builder.toString());
/*     */   }
/*     */ 
/*     */   public void setContentLength(long contentLength)
/*     */   {
/* 274 */     set("Content-Length", Long.toString(contentLength));
/*     */   }
/*     */ 
/*     */   public long getContentLength()
/*     */   {
/* 283 */     String value = getFirst("Content-Length");
/* 284 */     return value != null ? Long.parseLong(value) : -1L;
/*     */   }
/*     */ 
/*     */   public void setContentType(MediaType mediaType)
/*     */   {
/* 292 */     Assert.isTrue(!mediaType.isWildcardType(), "'Content-Type' cannot contain wildcard type '*'");
/* 293 */     Assert.isTrue(!mediaType.isWildcardSubtype(), "'Content-Type' cannot contain wildcard subtype '*'");
/* 294 */     set("Content-Type", mediaType.toString());
/*     */   }
/*     */ 
/*     */   public MediaType getContentType()
/*     */   {
/* 303 */     String value = getFirst("Content-Type");
/* 304 */     return StringUtils.hasLength(value) ? MediaType.parseMediaType(value) : null;
/*     */   }
/*     */ 
/*     */   public void setDate(long date)
/*     */   {
/* 313 */     setDate("Date", date);
/*     */   }
/*     */ 
/*     */   public long getDate()
/*     */   {
/* 323 */     return getFirstDate("Date");
/*     */   }
/*     */ 
/*     */   public void setETag(String eTag)
/*     */   {
/* 331 */     if (eTag != null) {
/* 332 */       Assert.isTrue((eTag.startsWith("\"")) || (eTag.startsWith("W/")), "Invalid eTag, does not start with W/ or \"");
/* 333 */       Assert.isTrue(eTag.endsWith("\""), "Invalid eTag, does not end with \"");
/*     */     }
/* 335 */     set("ETag", eTag);
/*     */   }
/*     */ 
/*     */   public String getETag()
/*     */   {
/* 343 */     return getFirst("ETag");
/*     */   }
/*     */ 
/*     */   public void setExpires(long expires)
/*     */   {
/* 352 */     setDate("Expires", expires);
/*     */   }
/*     */ 
/*     */   public long getExpires()
/*     */   {
/*     */     try
/*     */     {
/* 365 */       return getFirstDate("Expires");
/*     */     } catch (IllegalArgumentException ex) {
/*     */     }
/* 368 */     return -1L;
/*     */   }
/*     */ 
/*     */   public void setIfModifiedSince(long ifModifiedSince)
/*     */   {
/* 378 */     setDate("If-Modified-Since", ifModifiedSince);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long getIfNotModifiedSince()
/*     */   {
/* 389 */     return getIfModifiedSince();
/*     */   }
/*     */ 
/*     */   public long getIfModifiedSince()
/*     */   {
/* 398 */     return getFirstDate("If-Modified-Since");
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(String ifNoneMatch)
/*     */   {
/* 406 */     set("If-None-Match", ifNoneMatch);
/*     */   }
/*     */ 
/*     */   public void setIfNoneMatch(List<String> ifNoneMatchList)
/*     */   {
/* 414 */     StringBuilder builder = new StringBuilder();
/* 415 */     for (Iterator iterator = ifNoneMatchList.iterator(); iterator.hasNext(); ) {
/* 416 */       String ifNoneMatch = (String)iterator.next();
/* 417 */       builder.append(ifNoneMatch);
/* 418 */       if (iterator.hasNext()) {
/* 419 */         builder.append(", ");
/*     */       }
/*     */     }
/* 422 */     set("If-None-Match", builder.toString());
/*     */   }
/*     */ 
/*     */   public List<String> getIfNoneMatch()
/*     */   {
/* 430 */     List result = new ArrayList();
/* 431 */     String value = getFirst("If-None-Match");
/* 432 */     if (value != null) {
/* 433 */       String[] tokens = value.split(",\\s*");
/* 434 */       for (String token : tokens) {
/* 435 */         result.add(token);
/*     */       }
/*     */     }
/* 438 */     return result;
/*     */   }
/*     */ 
/*     */   public void setLastModified(long lastModified)
/*     */   {
/* 447 */     setDate("Last-Modified", lastModified);
/*     */   }
/*     */ 
/*     */   public long getLastModified()
/*     */   {
/* 456 */     return getFirstDate("Last-Modified");
/*     */   }
/*     */ 
/*     */   public void setLocation(URI location)
/*     */   {
/* 464 */     set("Location", location.toASCIIString());
/*     */   }
/*     */ 
/*     */   public URI getLocation()
/*     */   {
/* 473 */     String value = getFirst("Location");
/* 474 */     return value != null ? URI.create(value) : null;
/*     */   }
/*     */ 
/*     */   public void setPragma(String pragma)
/*     */   {
/* 482 */     set("Pragma", pragma);
/*     */   }
/*     */ 
/*     */   public String getPragma()
/*     */   {
/* 490 */     return getFirst("Pragma");
/*     */   }
/*     */ 
/*     */   public long getFirstDate(String headerName)
/*     */   {
/* 501 */     String headerValue = getFirst(headerName);
/* 502 */     if (headerValue == null) {
/* 503 */       return -1L;
/*     */     }
/* 505 */     for (String dateFormat : DATE_FORMATS) {
/* 506 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat, Locale.US);
/* 507 */       simpleDateFormat.setTimeZone(GMT);
/*     */       try {
/* 509 */         return simpleDateFormat.parse(headerValue).getTime();
/*     */       }
/*     */       catch (ParseException e)
/*     */       {
/*     */       }
/*     */     }
/* 515 */     throw new IllegalArgumentException("Cannot parse date value \"" + headerValue + "\" for \"" + headerName + "\" header");
/*     */   }
/*     */ 
/*     */   public void setDate(String headerName, long date)
/*     */   {
/* 525 */     SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMATS[0], Locale.US);
/* 526 */     dateFormat.setTimeZone(GMT);
/* 527 */     set(headerName, dateFormat.format(new Date(date)));
/*     */   }
/*     */ 
/*     */   public String getFirst(String headerName)
/*     */   {
/* 538 */     List headerValues = (List)this.headers.get(headerName);
/* 539 */     return headerValues != null ? (String)headerValues.get(0) : null;
/*     */   }
/*     */ 
/*     */   public void add(String headerName, String headerValue)
/*     */   {
/* 551 */     List headerValues = (List)this.headers.get(headerName);
/* 552 */     if (headerValues == null) {
/* 553 */       headerValues = new LinkedList();
/* 554 */       this.headers.put(headerName, headerValues);
/*     */     }
/* 556 */     headerValues.add(headerValue);
/*     */   }
/*     */ 
/*     */   public void set(String headerName, String headerValue)
/*     */   {
/* 568 */     List headerValues = new LinkedList();
/* 569 */     headerValues.add(headerValue);
/* 570 */     this.headers.put(headerName, headerValues);
/*     */   }
/*     */ 
/*     */   public void setAll(Map<String, String> values) {
/* 574 */     for (Map.Entry entry : values.entrySet())
/* 575 */       set((String)entry.getKey(), (String)entry.getValue());
/*     */   }
/*     */ 
/*     */   public Map<String, String> toSingleValueMap()
/*     */   {
/* 580 */     LinkedHashMap singleValueMap = new LinkedHashMap(this.headers.size());
/* 581 */     for (Map.Entry entry : this.headers.entrySet()) {
/* 582 */       singleValueMap.put(entry.getKey(), ((List)entry.getValue()).get(0));
/*     */     }
/* 584 */     return singleValueMap;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 590 */     return this.headers.size();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/* 594 */     return this.headers.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key) {
/* 598 */     return this.headers.containsKey(key);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value) {
/* 602 */     return this.headers.containsValue(value);
/*     */   }
/*     */ 
/*     */   public List<String> get(Object key) {
/* 606 */     return (List)this.headers.get(key);
/*     */   }
/*     */ 
/*     */   public List<String> put(String key, List<String> value) {
/* 610 */     return (List)this.headers.put(key, value);
/*     */   }
/*     */ 
/*     */   public List<String> remove(Object key) {
/* 614 */     return (List)this.headers.remove(key);
/*     */   }
/*     */ 
/*     */   public void putAll(Map<? extends String, ? extends List<String>> m) {
/* 618 */     this.headers.putAll(m);
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 622 */     this.headers.clear();
/*     */   }
/*     */ 
/*     */   public Set<String> keySet() {
/* 626 */     return this.headers.keySet();
/*     */   }
/*     */ 
/*     */   public Collection<List<String>> values() {
/* 630 */     return this.headers.values();
/*     */   }
/*     */ 
/*     */   public Set<Map.Entry<String, List<String>>> entrySet() {
/* 634 */     return this.headers.entrySet();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 640 */     if (this == other) {
/* 641 */       return true;
/*     */     }
/* 643 */     if (!(other instanceof HttpHeaders)) {
/* 644 */       return false;
/*     */     }
/* 646 */     HttpHeaders otherHeaders = (HttpHeaders)other;
/* 647 */     return this.headers.equals(otherHeaders.headers);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 652 */     return this.headers.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 657 */     return this.headers.toString();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpHeaders
 * JD-Core Version:    0.6.1
 */