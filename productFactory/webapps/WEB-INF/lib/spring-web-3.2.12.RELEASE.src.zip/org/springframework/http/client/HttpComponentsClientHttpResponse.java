/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.HttpEntity;
/*    */ import org.apache.http.HttpResponse;
/*    */ import org.apache.http.StatusLine;
/*    */ import org.apache.http.util.EntityUtils;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ final class HttpComponentsClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final HttpResponse httpResponse;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   HttpComponentsClientHttpResponse(HttpResponse httpResponse)
/*    */   {
/* 48 */     this.httpResponse = httpResponse;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode() throws IOException
/*    */   {
/* 53 */     return this.httpResponse.getStatusLine().getStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException {
/* 57 */     return this.httpResponse.getStatusLine().getReasonPhrase();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders() {
/* 61 */     if (this.headers == null) {
/* 62 */       this.headers = new HttpHeaders();
/* 63 */       for (Header header : this.httpResponse.getAllHeaders()) {
/* 64 */         this.headers.add(header.getName(), header.getValue());
/*    */       }
/*    */     }
/* 67 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException {
/* 71 */     HttpEntity entity = this.httpResponse.getEntity();
/* 72 */     return entity != null ? entity.getContent() : null;
/*    */   }
/*    */ 
/*    */   public void close() {
/* 76 */     HttpEntity entity = this.httpResponse.getEntity();
/* 77 */     if (entity != null)
/*    */       try
/*    */       {
/* 80 */         EntityUtils.consume(entity);
/*    */       }
/*    */       catch (IOException e)
/*    */       {
/*    */       }
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.HttpComponentsClientHttpResponse
 * JD-Core Version:    0.6.1
 */