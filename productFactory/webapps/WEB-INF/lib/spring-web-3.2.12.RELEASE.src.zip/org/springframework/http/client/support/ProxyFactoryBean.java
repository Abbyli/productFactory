/*    */ package org.springframework.http.client.support;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.Proxy;
/*    */ import java.net.Proxy.Type;
/*    */ import java.net.SocketAddress;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class ProxyFactoryBean
/*    */   implements FactoryBean<Proxy>, InitializingBean
/*    */ {
/* 37 */   private Proxy.Type type = Proxy.Type.HTTP;
/*    */   private String hostname;
/* 41 */   private int port = -1;
/*    */   private Proxy proxy;
/*    */ 
/*    */   public void setType(Proxy.Type type)
/*    */   {
/* 49 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setHostname(String hostname)
/*    */   {
/* 56 */     this.hostname = hostname;
/*    */   }
/*    */ 
/*    */   public void setPort(int port)
/*    */   {
/* 63 */     this.port = port;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() throws IllegalArgumentException {
/* 67 */     Assert.notNull(this.type, "'type' must not be null");
/* 68 */     Assert.hasLength(this.hostname, "'hostname' must not be empty");
/* 69 */     Assert.isTrue((this.port >= 0) && (this.port <= 65535), "'port' out of range: " + this.port);
/*    */ 
/* 71 */     SocketAddress socketAddress = new InetSocketAddress(this.hostname, this.port);
/* 72 */     this.proxy = new Proxy(this.type, socketAddress);
/*    */   }
/*    */ 
/*    */   public Proxy getObject()
/*    */   {
/* 77 */     return this.proxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 81 */     return Proxy.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 85 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.support.ProxyFactoryBean
 * JD-Core Version:    0.6.1
 */