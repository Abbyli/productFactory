/*     */ package org.springframework.http.converter.json;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.codehaus.jackson.JsonGenerator.Feature;
/*     */ import org.codehaus.jackson.JsonParser.Feature;
/*     */ import org.codehaus.jackson.map.AnnotationIntrospector;
/*     */ import org.codehaus.jackson.map.DeserializationConfig;
/*     */ import org.codehaus.jackson.map.DeserializationConfig.Feature;
/*     */ import org.codehaus.jackson.map.ObjectMapper;
/*     */ import org.codehaus.jackson.map.SerializationConfig;
/*     */ import org.codehaus.jackson.map.SerializationConfig.Feature;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class JacksonObjectMapperFactoryBean
/*     */   implements FactoryBean<ObjectMapper>, InitializingBean
/*     */ {
/*     */   private ObjectMapper objectMapper;
/*  90 */   private Map<Object, Boolean> features = new HashMap();
/*     */   private DateFormat dateFormat;
/*     */   private AnnotationIntrospector annotationIntrospector;
/*     */ 
/*     */   public void setObjectMapper(ObjectMapper objectMapper)
/*     */   {
/* 102 */     this.objectMapper = objectMapper;
/*     */   }
/*     */ 
/*     */   public void setDateFormat(DateFormat dateFormat)
/*     */   {
/* 112 */     this.dateFormat = dateFormat;
/*     */   }
/*     */ 
/*     */   public void setSimpleDateFormat(String format)
/*     */   {
/* 122 */     this.dateFormat = new SimpleDateFormat(format);
/*     */   }
/*     */ 
/*     */   public void setAnnotationIntrospector(AnnotationIntrospector annotationIntrospector)
/*     */   {
/* 131 */     this.annotationIntrospector = annotationIntrospector;
/*     */   }
/*     */ 
/*     */   public void setAutoDetectFields(boolean autoDetectFields)
/*     */   {
/* 139 */     this.features.put(SerializationConfig.Feature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/* 140 */     this.features.put(DeserializationConfig.Feature.AUTO_DETECT_FIELDS, Boolean.valueOf(autoDetectFields));
/*     */   }
/*     */ 
/*     */   public void setAutoDetectGettersSetters(boolean autoDetectGettersSetters)
/*     */   {
/* 148 */     this.features.put(SerializationConfig.Feature.AUTO_DETECT_GETTERS, Boolean.valueOf(autoDetectGettersSetters));
/* 149 */     this.features.put(DeserializationConfig.Feature.AUTO_DETECT_SETTERS, Boolean.valueOf(autoDetectGettersSetters));
/*     */   }
/*     */ 
/*     */   public void setFailOnEmptyBeans(boolean failOnEmptyBeans)
/*     */   {
/* 156 */     this.features.put(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, Boolean.valueOf(failOnEmptyBeans));
/*     */   }
/*     */ 
/*     */   public void setIndentOutput(boolean indentOutput)
/*     */   {
/* 163 */     this.features.put(SerializationConfig.Feature.INDENT_OUTPUT, Boolean.valueOf(indentOutput));
/*     */   }
/*     */ 
/*     */   public void setFeaturesToEnable(Object[] featuresToEnable)
/*     */   {
/* 174 */     if (featuresToEnable != null)
/* 175 */       for (Object feature : featuresToEnable)
/* 176 */         this.features.put(feature, Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   public void setFeaturesToDisable(Object[] featuresToDisable)
/*     */   {
/* 189 */     if (featuresToDisable != null)
/* 190 */       for (Object feature : featuresToDisable)
/* 191 */         this.features.put(feature, Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 198 */     if (this.objectMapper == null) {
/* 199 */       this.objectMapper = new ObjectMapper();
/*     */     }
/* 201 */     if (this.annotationIntrospector != null) {
/* 202 */       this.objectMapper.getSerializationConfig().setAnnotationIntrospector(this.annotationIntrospector);
/* 203 */       this.objectMapper.getDeserializationConfig().setAnnotationIntrospector(this.annotationIntrospector);
/*     */     }
/* 205 */     if (this.dateFormat != null)
/*     */     {
/* 207 */       this.objectMapper.getSerializationConfig().setDateFormat(this.dateFormat);
/*     */     }
/* 209 */     for (Map.Entry entry : this.features.entrySet())
/* 210 */       configureFeature(entry.getKey(), ((Boolean)entry.getValue()).booleanValue());
/*     */   }
/*     */ 
/*     */   private void configureFeature(Object feature, boolean enabled)
/*     */   {
/* 215 */     if ((feature instanceof JsonParser.Feature)) {
/* 216 */       this.objectMapper.configure((JsonParser.Feature)feature, enabled);
/*     */     }
/* 218 */     else if ((feature instanceof JsonGenerator.Feature)) {
/* 219 */       this.objectMapper.configure((JsonGenerator.Feature)feature, enabled);
/*     */     }
/* 221 */     else if ((feature instanceof SerializationConfig.Feature)) {
/* 222 */       this.objectMapper.configure((SerializationConfig.Feature)feature, enabled);
/*     */     }
/* 224 */     else if ((feature instanceof DeserializationConfig.Feature)) {
/* 225 */       this.objectMapper.configure((DeserializationConfig.Feature)feature, enabled);
/*     */     }
/*     */     else
/* 228 */       throw new IllegalArgumentException("Unknown feature class: " + feature.getClass().getName());
/*     */   }
/*     */ 
/*     */   public ObjectMapper getObject()
/*     */   {
/* 237 */     return this.objectMapper;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 241 */     return ObjectMapper.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 245 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.json.JacksonObjectMapperFactoryBean
 * JD-Core Version:    0.6.1
 */