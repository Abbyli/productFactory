/*    */ package org.springframework.http.converter.xml;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ 
/*    */ @Deprecated
/*    */ public class XmlAwareFormHttpMessageConverter extends FormHttpMessageConverter
/*    */ {
/*    */   public XmlAwareFormHttpMessageConverter()
/*    */   {
/* 35 */     addPartConverter(new SourceHttpMessageConverter());
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.XmlAwareFormHttpMessageConverter
 * JD-Core Version:    0.6.1
 */