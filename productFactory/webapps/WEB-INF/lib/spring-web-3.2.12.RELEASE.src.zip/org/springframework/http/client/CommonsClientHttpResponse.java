/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.httpclient.Header;
/*    */ import org.apache.commons.httpclient.HttpMethod;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ 
/*    */ @Deprecated
/*    */ final class CommonsClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final HttpMethod httpMethod;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   CommonsClientHttpResponse(HttpMethod httpMethod)
/*    */   {
/* 47 */     this.httpMethod = httpMethod;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode()
/*    */   {
/* 52 */     return this.httpMethod.getStatusCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() {
/* 56 */     return this.httpMethod.getStatusText();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders() {
/* 60 */     if (this.headers == null) {
/* 61 */       this.headers = new HttpHeaders();
/* 62 */       for (Header header : this.httpMethod.getResponseHeaders()) {
/* 63 */         this.headers.add(header.getName(), header.getValue());
/*    */       }
/*    */     }
/* 66 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException {
/* 70 */     return this.httpMethod.getResponseBodyAsStream();
/*    */   }
/*    */ 
/*    */   public void close() {
/* 74 */     this.httpMethod.releaseConnection();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.CommonsClientHttpResponse
 * JD-Core Version:    0.6.1
 */