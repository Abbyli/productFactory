/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.StringReader;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.AbstractHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ import org.springframework.http.converter.HttpMessageNotWritableException;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.XMLReaderFactory;
/*     */ 
/*     */ public class SourceHttpMessageConverter<T extends Source> extends AbstractHttpMessageConverter<T>
/*     */ {
/*  65 */   private static final Set<Class<?>> SUPPORTED_CLASSES = new HashSet(4);
/*     */ 
/*  75 */   private final TransformerFactory transformerFactory = TransformerFactory.newInstance();
/*     */ 
/*  77 */   private boolean processExternalEntities = false;
/*     */ 
/* 225 */   private static final EntityResolver NO_OP_ENTITY_RESOLVER = new EntityResolver()
/*     */   {
/*     */     public InputSource resolveEntity(String publicId, String systemId) {
/* 228 */       return new InputSource(new StringReader(""));
/*     */     }
/* 225 */   };
/*     */ 
/* 232 */   private static final XMLResolver NO_OP_XML_RESOLVER = new XMLResolver()
/*     */   {
/*     */     public Object resolveEntity(String publicID, String systemID, String base, String ns) {
/* 235 */       return new ByteArrayInputStream(new byte[0]);
/*     */     }
/* 232 */   };
/*     */ 
/*     */   public SourceHttpMessageConverter()
/*     */   {
/*  85 */     super(new MediaType[] { MediaType.APPLICATION_XML, MediaType.TEXT_XML, new MediaType("application", "*+xml") });
/*     */   }
/*     */ 
/*     */   public void setProcessExternalEntities(boolean processExternalEntities)
/*     */   {
/*  94 */     this.processExternalEntities = processExternalEntities;
/*     */   }
/*     */ 
/*     */   public boolean isProcessExternalEntities()
/*     */   {
/* 101 */     return this.processExternalEntities;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/* 107 */     return SUPPORTED_CLASSES.contains(clazz);
/*     */   }
/*     */ 
/*     */   protected T readInternal(Class<? extends T> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 115 */     InputStream body = inputMessage.getBody();
/* 116 */     if (DOMSource.class.equals(clazz)) {
/* 117 */       return readDOMSource(body);
/*     */     }
/* 119 */     if (SAXSource.class.equals(clazz)) {
/* 120 */       return readSAXSource(body);
/*     */     }
/* 122 */     if ((StreamSource.class.equals(clazz)) || (Source.class.equals(clazz))) {
/* 123 */       return readStreamSource(body);
/*     */     }
/*     */ 
/* 126 */     throw new HttpMessageConversionException("Could not read class [" + clazz + "]. Only DOMSource, SAXSource, and StreamSource are supported.");
/*     */   }
/*     */ 
/*     */   private DOMSource readDOMSource(InputStream body) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 133 */       DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
/* 134 */       documentBuilderFactory.setNamespaceAware(true);
/* 135 */       documentBuilderFactory.setFeature("http://xml.org/sax/features/external-general-entities", isProcessExternalEntities());
/*     */ 
/* 137 */       DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
/* 138 */       if (!isProcessExternalEntities()) {
/* 139 */         documentBuilder.setEntityResolver(NO_OP_ENTITY_RESOLVER);
/*     */       }
/* 141 */       Document document = documentBuilder.parse(body);
/* 142 */       return new DOMSource(document);
/*     */     }
/*     */     catch (ParserConfigurationException ex) {
/* 145 */       throw new HttpMessageNotReadableException("Could not set feature: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (SAXException ex) {
/* 148 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private SAXSource readSAXSource(InputStream body) throws IOException {
/*     */     try {
/* 154 */       XMLReader reader = XMLReaderFactory.createXMLReader();
/* 155 */       reader.setFeature("http://xml.org/sax/features/external-general-entities", isProcessExternalEntities());
/* 156 */       byte[] bytes = StreamUtils.copyToByteArray(body);
/* 157 */       if (!isProcessExternalEntities()) {
/* 158 */         reader.setEntityResolver(NO_OP_ENTITY_RESOLVER);
/*     */       }
/* 160 */       return new SAXSource(reader, new InputSource(new ByteArrayInputStream(bytes)));
/*     */     }
/*     */     catch (SAXException ex) {
/* 163 */       throw new HttpMessageNotReadableException("Could not parse document: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private StreamSource readStreamSource(InputStream body) throws IOException {
/* 168 */     byte[] bytes = StreamUtils.copyToByteArray(body);
/* 169 */     return new StreamSource(new ByteArrayInputStream(bytes));
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(T t, MediaType contentType)
/*     */   {
/* 174 */     if ((t instanceof DOMSource)) {
/*     */       try {
/* 176 */         CountingOutputStream os = new CountingOutputStream(null);
/* 177 */         transform(t, new StreamResult(os));
/* 178 */         return Long.valueOf(os.count);
/*     */       }
/*     */       catch (TransformerException ex)
/*     */       {
/*     */       }
/*     */     }
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */   protected void writeInternal(T t, HttpOutputMessage outputMessage) throws IOException, HttpMessageNotWritableException
/*     */   {
/*     */     try
/*     */     {
/* 191 */       Result result = new StreamResult(outputMessage.getBody());
/* 192 */       transform(t, result);
/*     */     }
/*     */     catch (TransformerException ex) {
/* 195 */       throw new HttpMessageNotWritableException("Could not transform [" + t + "] to output message", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void transform(Source source, Result result) throws TransformerException {
/* 200 */     this.transformerFactory.newTransformer().transform(source, result);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  68 */     SUPPORTED_CLASSES.add(DOMSource.class);
/*  69 */     SUPPORTED_CLASSES.add(SAXSource.class);
/*  70 */     SUPPORTED_CLASSES.add(StreamSource.class);
/*  71 */     SUPPORTED_CLASSES.add(Source.class);
/*     */   }
/*     */ 
/*     */   private static class CountingOutputStream extends OutputStream
/*     */   {
/* 206 */     long count = 0L;
/*     */ 
/*     */     public void write(int b) throws IOException
/*     */     {
/* 210 */       this.count += 1L;
/*     */     }
/*     */ 
/*     */     public void write(byte[] b) throws IOException
/*     */     {
/* 215 */       this.count += b.length;
/*     */     }
/*     */ 
/*     */     public void write(byte[] b, int off, int len) throws IOException
/*     */     {
/* 220 */       this.count += len;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.SourceHttpMessageConverter
 * JD-Core Version:    0.6.1
 */