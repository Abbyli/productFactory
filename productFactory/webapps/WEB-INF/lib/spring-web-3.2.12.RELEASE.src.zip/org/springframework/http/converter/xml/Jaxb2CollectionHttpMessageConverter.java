/*     */ package org.springframework.http.converter.xml;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.bind.JAXBElement;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.UnmarshalException;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlType;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLResolver;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConversionException;
/*     */ import org.springframework.http.converter.HttpMessageNotReadableException;
/*     */ 
/*     */ public class Jaxb2CollectionHttpMessageConverter<T extends Collection> extends AbstractJaxb2HttpMessageConverter<T>
/*     */   implements GenericHttpMessageConverter<T>
/*     */ {
/*  62 */   private final XMLInputFactory inputFactory = createXmlInputFactory();
/*     */ 
/* 235 */   private static final XMLResolver NO_OP_XML_RESOLVER = new XMLResolver()
/*     */   {
/*     */     public Object resolveEntity(String publicID, String systemID, String base, String ns) {
/* 238 */       return new ByteArrayInputStream(new byte[0]);
/*     */     }
/* 235 */   };
/*     */ 
/*     */   public boolean canRead(Class<?> clazz, MediaType mediaType)
/*     */   {
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean canRead(Type type, Class<?> contextClass, MediaType mediaType)
/*     */   {
/*  81 */     if (!(type instanceof ParameterizedType)) {
/*  82 */       return false;
/*     */     }
/*  84 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/*  85 */     if (!(parameterizedType.getRawType() instanceof Class)) {
/*  86 */       return false;
/*     */     }
/*  88 */     Class rawType = (Class)parameterizedType.getRawType();
/*  89 */     if (!Collection.class.isAssignableFrom(rawType)) {
/*  90 */       return false;
/*     */     }
/*  92 */     if (parameterizedType.getActualTypeArguments().length != 1) {
/*  93 */       return false;
/*     */     }
/*  95 */     Type typeArgument = parameterizedType.getActualTypeArguments()[0];
/*  96 */     if (!(typeArgument instanceof Class)) {
/*  97 */       return false;
/*     */     }
/*  99 */     Class typeArgumentClass = (Class)typeArgument;
/* 100 */     return ((typeArgumentClass.isAnnotationPresent(XmlRootElement.class)) || (typeArgumentClass.isAnnotationPresent(XmlType.class))) && (canRead(mediaType));
/*     */   }
/*     */ 
/*     */   public boolean canWrite(Class<?> clazz, MediaType mediaType)
/*     */   {
/* 110 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/* 116 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected T readFromSource(Class<? extends T> clazz, HttpHeaders headers, Source source)
/*     */     throws IOException
/*     */   {
/* 122 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public T read(Type type, Class<?> contextClass, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/* 129 */     ParameterizedType parameterizedType = (ParameterizedType)type;
/* 130 */     Collection result = createCollection((Class)parameterizedType.getRawType());
/* 131 */     Class elementClass = (Class)parameterizedType.getActualTypeArguments()[0];
/*     */     try
/*     */     {
/* 134 */       Unmarshaller unmarshaller = createUnmarshaller(elementClass);
/* 135 */       XMLStreamReader streamReader = this.inputFactory.createXMLStreamReader(inputMessage.getBody());
/* 136 */       int event = moveToFirstChildOfRootElement(streamReader);
/*     */ 
/* 138 */       while (event != 8) {
/* 139 */         if (elementClass.isAnnotationPresent(XmlRootElement.class)) {
/* 140 */           result.add(unmarshaller.unmarshal(streamReader));
/*     */         }
/* 142 */         else if (elementClass.isAnnotationPresent(XmlType.class)) {
/* 143 */           result.add(unmarshaller.unmarshal(streamReader, elementClass).getValue());
/*     */         }
/*     */         else
/*     */         {
/* 147 */           throw new HttpMessageConversionException("Could not unmarshal to [" + elementClass + "]");
/*     */         }
/* 149 */         event = moveToNextElement(streamReader);
/*     */       }
/* 151 */       return result;
/*     */     }
/*     */     catch (UnmarshalException ex) {
/* 154 */       throw new HttpMessageNotReadableException("Could not unmarshal to [" + elementClass + "]: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (JAXBException ex) {
/* 157 */       throw new HttpMessageConversionException("Could not instantiate JAXBContext: " + ex.getMessage(), ex);
/*     */     }
/*     */     catch (XMLStreamException ex) {
/* 160 */       throw new HttpMessageConversionException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected T createCollection(Class<?> collectionClass)
/*     */   {
/* 172 */     if (!collectionClass.isInterface()) {
/*     */       try {
/* 174 */         return (Collection)collectionClass.newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/* 177 */         throw new IllegalArgumentException("Could not instantiate collection class [" + collectionClass.getName() + "]: " + ex.getMessage());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 182 */     if (List.class.equals(collectionClass)) {
/* 183 */       return new ArrayList();
/*     */     }
/* 185 */     if (SortedSet.class.equals(collectionClass)) {
/* 186 */       return new TreeSet();
/*     */     }
/*     */ 
/* 189 */     return new LinkedHashSet();
/*     */   }
/*     */ 
/*     */   private int moveToFirstChildOfRootElement(XMLStreamReader streamReader)
/*     */     throws XMLStreamException
/*     */   {
/* 195 */     int event = streamReader.next();
/* 196 */     while (event != 1) {
/* 197 */       event = streamReader.next();
/*     */     }
/*     */ 
/* 201 */     event = streamReader.next();
/* 202 */     while ((event != 1) && (event != 8)) {
/* 203 */       event = streamReader.next();
/*     */     }
/* 205 */     return event;
/*     */   }
/*     */ 
/*     */   private int moveToNextElement(XMLStreamReader streamReader) throws XMLStreamException {
/* 209 */     int event = streamReader.getEventType();
/* 210 */     while ((event != 1) && (event != 8)) {
/* 211 */       event = streamReader.next();
/*     */     }
/* 213 */     return event;
/*     */   }
/*     */ 
/*     */   protected void writeToResult(T t, HttpHeaders headers, Result result) throws IOException
/*     */   {
/* 218 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected XMLInputFactory createXmlInputFactory()
/*     */   {
/* 228 */     XMLInputFactory inputFactory = XMLInputFactory.newInstance();
/* 229 */     inputFactory.setProperty("javax.xml.stream.isSupportingExternalEntities", Boolean.valueOf(false));
/* 230 */     inputFactory.setXMLResolver(NO_OP_XML_RESOLVER);
/* 231 */     return inputFactory;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.xml.Jaxb2CollectionHttpMessageConverter
 * JD-Core Version:    0.6.1
 */