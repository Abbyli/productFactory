/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.http.HttpStatus;
/*    */ 
/*    */ public abstract class AbstractClientHttpResponse
/*    */   implements ClientHttpResponse
/*    */ {
/*    */   public HttpStatus getStatusCode()
/*    */     throws IOException
/*    */   {
/* 32 */     return HttpStatus.valueOf(getRawStatusCode());
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.AbstractClientHttpResponse
 * JD-Core Version:    0.6.1
 */