/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import org.apache.commons.httpclient.HttpClient;
/*    */ import org.apache.commons.httpclient.HttpMethodBase;
/*    */ import org.apache.commons.httpclient.URIException;
/*    */ import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
/*    */ import org.apache.commons.httpclient.methods.EntityEnclosingMethod;
/*    */ import org.apache.commons.httpclient.methods.RequestEntity;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.http.HttpMethod;
/*    */ 
/*    */ @Deprecated
/*    */ final class CommonsClientHttpRequest extends AbstractBufferingClientHttpRequest
/*    */ {
/*    */   private final HttpClient httpClient;
/*    */   private final HttpMethodBase httpMethod;
/*    */ 
/*    */   CommonsClientHttpRequest(HttpClient httpClient, HttpMethodBase httpMethod)
/*    */   {
/* 54 */     this.httpClient = httpClient;
/* 55 */     this.httpMethod = httpMethod;
/*    */   }
/*    */ 
/*    */   public HttpMethod getMethod()
/*    */   {
/* 60 */     return HttpMethod.valueOf(this.httpMethod.getName());
/*    */   }
/*    */ 
/*    */   public java.net.URI getURI() {
/*    */     try {
/* 65 */       return java.net.URI.create(this.httpMethod.getURI().getEscapedURI());
/*    */     }
/*    */     catch (URIException ex) {
/* 68 */       throw new IllegalStateException("Could not get HttpMethod URI: " + ex.getMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ClientHttpResponse executeInternal(HttpHeaders headers, byte[] output) throws IOException
/*    */   {
/* 74 */     for (Map.Entry entry : headers.entrySet()) {
/* 75 */       headerName = (String)entry.getKey();
/* 76 */       for (String headerValue : (List)entry.getValue())
/* 77 */         this.httpMethod.addRequestHeader(headerName, headerValue);
/*    */     }
/*    */     String headerName;
/* 80 */     if ((this.httpMethod instanceof EntityEnclosingMethod)) {
/* 81 */       EntityEnclosingMethod entityEnclosingMethod = (EntityEnclosingMethod)this.httpMethod;
/* 82 */       RequestEntity requestEntity = new ByteArrayRequestEntity(output);
/* 83 */       entityEnclosingMethod.setRequestEntity(requestEntity);
/*    */     }
/* 85 */     this.httpClient.executeMethod(this.httpMethod);
/* 86 */     return new CommonsClientHttpResponse(this.httpMethod);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.CommonsClientHttpRequest
 * JD-Core Version:    0.6.1
 */