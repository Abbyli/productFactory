/*     */ package org.springframework.http;
/*     */ 
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class ResponseEntity<T> extends HttpEntity<T>
/*     */ {
/*     */   private final HttpStatus statusCode;
/*     */ 
/*     */   public ResponseEntity(HttpStatus statusCode)
/*     */   {
/*  61 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(T body, HttpStatus statusCode)
/*     */   {
/*  70 */     super(body);
/*  71 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(MultiValueMap<String, String> headers, HttpStatus statusCode)
/*     */   {
/*  80 */     super(headers);
/*  81 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public ResponseEntity(T body, MultiValueMap<String, String> headers, HttpStatus statusCode)
/*     */   {
/*  91 */     super(body, headers);
/*  92 */     this.statusCode = statusCode;
/*     */   }
/*     */ 
/*     */   public HttpStatus getStatusCode()
/*     */   {
/* 101 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 106 */     if (this == other) {
/* 107 */       return true;
/*     */     }
/* 109 */     if ((!(other instanceof ResponseEntity)) || (!super.equals(other))) {
/* 110 */       return false;
/*     */     }
/* 112 */     ResponseEntity otherEntity = (ResponseEntity)other;
/* 113 */     return ObjectUtils.nullSafeEquals(this.statusCode, otherEntity.statusCode);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 118 */     return super.hashCode() * 29 + ObjectUtils.nullSafeHashCode(this.statusCode);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 123 */     StringBuilder builder = new StringBuilder("<");
/* 124 */     builder.append(this.statusCode.toString());
/* 125 */     builder.append(' ');
/* 126 */     builder.append(this.statusCode.getReasonPhrase());
/* 127 */     builder.append(',');
/* 128 */     Object body = getBody();
/* 129 */     HttpHeaders headers = getHeaders();
/* 130 */     if (body != null) {
/* 131 */       builder.append(body);
/* 132 */       if (headers != null) {
/* 133 */         builder.append(',');
/*     */       }
/*     */     }
/* 136 */     if (headers != null) {
/* 137 */       builder.append(headers);
/*     */     }
/* 139 */     builder.append('>');
/* 140 */     return builder.toString();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.ResponseEntity
 * JD-Core Version:    0.6.1
 */