/*     */ package org.springframework.http.converter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import org.springframework.core.io.ByteArrayResource;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.InputStreamResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceHttpMessageConverter extends AbstractHttpMessageConverter<Resource>
/*     */ {
/*  47 */   private static final boolean jafPresent = ClassUtils.isPresent("javax.activation.FileTypeMap", ResourceHttpMessageConverter.class.getClassLoader());
/*     */ 
/*     */   public ResourceHttpMessageConverter()
/*     */   {
/*  52 */     super(MediaType.ALL);
/*     */   }
/*     */ 
/*     */   protected boolean supports(Class<?> clazz)
/*     */   {
/*  58 */     return Resource.class.isAssignableFrom(clazz);
/*     */   }
/*     */ 
/*     */   protected Resource readInternal(Class<? extends Resource> clazz, HttpInputMessage inputMessage)
/*     */     throws IOException, HttpMessageNotReadableException
/*     */   {
/*  65 */     byte[] body = StreamUtils.copyToByteArray(inputMessage.getBody());
/*  66 */     return new ByteArrayResource(body);
/*     */   }
/*     */ 
/*     */   protected MediaType getDefaultContentType(Resource resource)
/*     */   {
/*  71 */     if (jafPresent) {
/*  72 */       return ActivationMediaTypeFactory.getMediaType(resource);
/*     */     }
/*     */ 
/*  75 */     return MediaType.APPLICATION_OCTET_STREAM;
/*     */   }
/*     */ 
/*     */   protected Long getContentLength(Resource resource, MediaType contentType)
/*     */     throws IOException
/*     */   {
/*  83 */     return InputStreamResource.class.equals(resource.getClass()) ? null : Long.valueOf(resource.contentLength());
/*     */   }
/*     */ 
/*     */   protected void writeInternal(Resource resource, HttpOutputMessage outputMessage)
/*     */     throws IOException, HttpMessageNotWritableException
/*     */   {
/*  90 */     InputStream in = resource.getInputStream();
/*     */     try {
/*  92 */       StreamUtils.copy(in, outputMessage.getBody());
/*     */     }
/*     */     finally {
/*     */       try {
/*  96 */         in.close();
/*     */       }
/*     */       catch (IOException ex) {
/*     */       }
/*     */     }
/* 101 */     outputMessage.getBody().flush();
/*     */   }
/*     */ 
/*     */   private static class ActivationMediaTypeFactory
/*     */   {
/* 113 */     private static final FileTypeMap fileTypeMap = loadFileTypeMapFromContextSupportModule();
/*     */ 
/*     */     private static FileTypeMap loadFileTypeMapFromContextSupportModule()
/*     */     {
/* 118 */       Resource mappingLocation = new ClassPathResource("org/springframework/mail/javamail/mime.types");
/* 119 */       if (mappingLocation.exists()) {
/* 120 */         InputStream inputStream = null;
/*     */         try {
/* 122 */           inputStream = mappingLocation.getInputStream();
/* 123 */           return new MimetypesFileTypeMap(inputStream);
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */         finally {
/* 129 */           if (inputStream != null) {
/*     */             try {
/* 131 */               inputStream.close();
/*     */             }
/*     */             catch (IOException ex)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 139 */       return FileTypeMap.getDefaultFileTypeMap();
/*     */     }
/*     */ 
/*     */     public static MediaType getMediaType(Resource resource) {
/* 143 */       if (resource.getFilename() == null) {
/* 144 */         return null;
/*     */       }
/* 146 */       String mediaType = fileTypeMap.getContentType(resource.getFilename());
/* 147 */       return StringUtils.hasText(mediaType) ? MediaType.parseMediaType(mediaType) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.ResourceHttpMessageConverter
 * JD-Core Version:    0.6.1
 */