package org.springframework.http;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface HttpOutputMessage extends HttpMessage
{
  public abstract OutputStream getBody()
    throws IOException;
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpOutputMessage
 * JD-Core Version:    0.6.1
 */