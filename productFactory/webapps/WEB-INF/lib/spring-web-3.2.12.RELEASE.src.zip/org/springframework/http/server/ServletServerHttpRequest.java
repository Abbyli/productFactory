/*     */ package org.springframework.http.server;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ServletServerHttpRequest
/*     */   implements ServerHttpRequest
/*     */ {
/*     */   protected static final String FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
/*     */   protected static final String FORM_CHARSET = "UTF-8";
/*     */   private static final String METHOD_POST = "POST";
/*     */   private final HttpServletRequest servletRequest;
/*     */   private HttpHeaders headers;
/*     */ 
/*     */   public ServletServerHttpRequest(HttpServletRequest servletRequest)
/*     */   {
/*  68 */     Assert.notNull(servletRequest, "HttpServletRequest must not be null");
/*  69 */     this.servletRequest = servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getServletRequest()
/*     */   {
/*  77 */     return this.servletRequest;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod() {
/*  81 */     return HttpMethod.valueOf(this.servletRequest.getMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI() {
/*     */     try {
/*  86 */       return new URI(this.servletRequest.getScheme(), null, this.servletRequest.getServerName(), this.servletRequest.getServerPort(), this.servletRequest.getRequestURI(), this.servletRequest.getQueryString(), null);
/*     */     }
/*     */     catch (URISyntaxException ex)
/*     */     {
/*  91 */       throw new IllegalStateException("Could not get HttpServletRequest URI: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders getHeaders() {
/*  96 */     if (this.headers == null) {
/*  97 */       this.headers = new HttpHeaders();
/*  98 */       for (Enumeration headerNames = this.servletRequest.getHeaderNames(); headerNames.hasMoreElements(); ) {
/*  99 */         String headerName = (String)headerNames.nextElement();
/* 100 */         Enumeration headerValues = this.servletRequest.getHeaders(headerName);
/* 101 */         while (headerValues.hasMoreElements()) {
/* 102 */           String headerValue = (String)headerValues.nextElement();
/* 103 */           this.headers.add(headerName, headerValue);
/*     */         }
/*     */       }
/*     */ 
/* 107 */       MediaType contentType = this.headers.getContentType();
/* 108 */       if (contentType == null) {
/* 109 */         String requestContentType = this.servletRequest.getContentType();
/* 110 */         if (StringUtils.hasLength(requestContentType)) {
/* 111 */           contentType = MediaType.parseMediaType(requestContentType);
/* 112 */           this.headers.setContentType(contentType);
/*     */         }
/*     */       }
/* 115 */       if ((contentType != null) && (contentType.getCharSet() == null)) {
/* 116 */         String requestEncoding = this.servletRequest.getCharacterEncoding();
/* 117 */         if (StringUtils.hasLength(requestEncoding)) {
/* 118 */           Charset charSet = Charset.forName(requestEncoding);
/* 119 */           Map params = new LinkedCaseInsensitiveMap();
/* 120 */           params.putAll(contentType.getParameters());
/* 121 */           params.put("charset", charSet.toString());
/* 122 */           MediaType newContentType = new MediaType(contentType.getType(), contentType.getSubtype(), params);
/* 123 */           this.headers.setContentType(newContentType);
/*     */         }
/*     */       }
/* 126 */       if (this.headers.getContentLength() == -1L) {
/* 127 */         int requestContentLength = this.servletRequest.getContentLength();
/* 128 */         if (requestContentLength != -1) {
/* 129 */           this.headers.setContentLength(requestContentLength);
/*     */         }
/*     */       }
/*     */     }
/* 133 */     return this.headers;
/*     */   }
/*     */ 
/*     */   public InputStream getBody() throws IOException {
/* 137 */     if (isFormPost(this.servletRequest)) {
/* 138 */       return getBodyFromServletRequestParameters(this.servletRequest);
/*     */     }
/*     */ 
/* 141 */     return this.servletRequest.getInputStream();
/*     */   }
/*     */ 
/*     */   private boolean isFormPost(HttpServletRequest request)
/*     */   {
/* 146 */     return (request.getContentType() != null) && (request.getContentType().contains("application/x-www-form-urlencoded")) && ("POST".equalsIgnoreCase(request.getMethod()));
/*     */   }
/*     */ 
/*     */   private InputStream getBodyFromServletRequestParameters(HttpServletRequest request)
/*     */     throws IOException
/*     */   {
/* 157 */     ByteArrayOutputStream bos = new ByteArrayOutputStream(1024);
/* 158 */     Writer writer = new OutputStreamWriter(bos, "UTF-8");
/*     */ 
/* 160 */     Map form = request.getParameterMap();
/* 161 */     for (Iterator nameIterator = form.keySet().iterator(); nameIterator.hasNext(); ) {
/* 162 */       String name = (String)nameIterator.next();
/* 163 */       List values = Arrays.asList((Object[])form.get(name));
/* 164 */       for (Iterator valueIterator = values.iterator(); valueIterator.hasNext(); ) {
/* 165 */         String value = (String)valueIterator.next();
/* 166 */         writer.write(URLEncoder.encode(name, "UTF-8"));
/* 167 */         if (value != null) {
/* 168 */           writer.write(61);
/* 169 */           writer.write(URLEncoder.encode(value, "UTF-8"));
/* 170 */           if (valueIterator.hasNext()) {
/* 171 */             writer.write(38);
/*     */           }
/*     */         }
/*     */       }
/* 175 */       if (nameIterator.hasNext()) {
/* 176 */         writer.append('&');
/*     */       }
/*     */     }
/* 179 */     writer.flush();
/*     */ 
/* 181 */     return new ByteArrayInputStream(bos.toByteArray());
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.server.ServletServerHttpRequest
 * JD-Core Version:    0.6.1
 */