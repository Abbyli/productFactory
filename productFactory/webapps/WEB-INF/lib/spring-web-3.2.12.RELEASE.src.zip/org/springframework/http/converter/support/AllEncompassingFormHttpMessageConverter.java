/*    */ package org.springframework.http.converter.support;
/*    */ 
/*    */ import org.springframework.http.converter.FormHttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*    */ import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*    */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class AllEncompassingFormHttpMessageConverter extends FormHttpMessageConverter
/*    */ {
/* 35 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", AllEncompassingFormHttpMessageConverter.class.getClassLoader());
/*    */ 
/* 38 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", AllEncompassingFormHttpMessageConverter.class.getClassLoader())) && (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", AllEncompassingFormHttpMessageConverter.class.getClassLoader()));
/*    */ 
/* 42 */   private static final boolean jacksonPresent = (ClassUtils.isPresent("org.codehaus.jackson.map.ObjectMapper", AllEncompassingFormHttpMessageConverter.class.getClassLoader())) && (ClassUtils.isPresent("org.codehaus.jackson.JsonGenerator", AllEncompassingFormHttpMessageConverter.class.getClassLoader()));
/*    */ 
/*    */   public AllEncompassingFormHttpMessageConverter()
/*    */   {
/* 48 */     addPartConverter(new SourceHttpMessageConverter());
/* 49 */     if (jaxb2Present) {
/* 50 */       addPartConverter(new Jaxb2RootElementHttpMessageConverter());
/*    */     }
/* 52 */     if (jackson2Present) {
/* 53 */       addPartConverter(new MappingJackson2HttpMessageConverter());
/*    */     }
/* 55 */     else if (jacksonPresent)
/* 56 */       addPartConverter(new MappingJacksonHttpMessageConverter());
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter
 * JD-Core Version:    0.6.1
 */