/*     */ package org.springframework.http.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.StreamUtils;
/*     */ 
/*     */ final class SimpleStreamingClientHttpRequest extends AbstractClientHttpRequest
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   private final int chunkSize;
/*     */   private OutputStream body;
/*     */   private final boolean outputStreaming;
/*     */ 
/*     */   SimpleStreamingClientHttpRequest(HttpURLConnection connection, int chunkSize, boolean outputStreaming)
/*     */   {
/*  49 */     this.connection = connection;
/*  50 */     this.chunkSize = chunkSize;
/*  51 */     this.outputStreaming = outputStreaming;
/*     */   }
/*     */ 
/*     */   public HttpMethod getMethod()
/*     */   {
/*  56 */     return HttpMethod.valueOf(this.connection.getRequestMethod());
/*     */   }
/*     */ 
/*     */   public URI getURI() {
/*     */     try {
/*  61 */       return this.connection.getURL().toURI();
/*     */     }
/*     */     catch (URISyntaxException ex) {
/*  64 */       throw new IllegalStateException("Could not get HttpURLConnection URI: " + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected OutputStream getBodyInternal(HttpHeaders headers) throws IOException
/*     */   {
/*  70 */     if (this.body == null) {
/*  71 */       if (this.outputStreaming) {
/*  72 */         int contentLength = (int)headers.getContentLength();
/*  73 */         if (contentLength >= 0) {
/*  74 */           this.connection.setFixedLengthStreamingMode(contentLength);
/*     */         }
/*     */         else {
/*  77 */           this.connection.setChunkedStreamingMode(this.chunkSize);
/*     */         }
/*     */       }
/*  80 */       SimpleBufferingClientHttpRequest.addHeaders(this.connection, headers);
/*  81 */       this.connection.connect();
/*  82 */       this.body = this.connection.getOutputStream();
/*     */     }
/*  84 */     return StreamUtils.nonClosing(this.body);
/*     */   }
/*     */ 
/*     */   protected ClientHttpResponse executeInternal(HttpHeaders headers) throws IOException
/*     */   {
/*     */     try {
/*  90 */       if (this.body != null) {
/*  91 */         this.body.close();
/*     */       }
/*     */       else {
/*  94 */         SimpleBufferingClientHttpRequest.addHeaders(this.connection, headers);
/*  95 */         this.connection.connect();
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/* 101 */     return new SimpleClientHttpResponse(this.connection);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleStreamingClientHttpRequest
 * JD-Core Version:    0.6.1
 */