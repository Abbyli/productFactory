/*     */ package org.springframework.http;
/*     */ 
/*     */ public enum HttpStatus
/*     */ {
/*  37 */   CONTINUE(100, "Continue"), 
/*     */ 
/*  42 */   SWITCHING_PROTOCOLS(101, "Switching Protocols"), 
/*     */ 
/*  47 */   PROCESSING(102, "Processing"), 
/*     */ 
/*  53 */   CHECKPOINT(103, "Checkpoint"), 
/*     */ 
/*  61 */   OK(200, "OK"), 
/*     */ 
/*  66 */   CREATED(201, "Created"), 
/*     */ 
/*  71 */   ACCEPTED(202, "Accepted"), 
/*     */ 
/*  76 */   NON_AUTHORITATIVE_INFORMATION(203, "Non-Authoritative Information"), 
/*     */ 
/*  81 */   NO_CONTENT(204, "No Content"), 
/*     */ 
/*  86 */   RESET_CONTENT(205, "Reset Content"), 
/*     */ 
/*  91 */   PARTIAL_CONTENT(206, "Partial Content"), 
/*     */ 
/*  96 */   MULTI_STATUS(207, "Multi-Status"), 
/*     */ 
/* 101 */   ALREADY_REPORTED(208, "Already Reported"), 
/*     */ 
/* 106 */   IM_USED(226, "IM Used"), 
/*     */ 
/* 114 */   MULTIPLE_CHOICES(300, "Multiple Choices"), 
/*     */ 
/* 119 */   MOVED_PERMANENTLY(301, "Moved Permanently"), 
/*     */ 
/* 124 */   FOUND(302, "Found"), 
/*     */ 
/* 130 */   MOVED_TEMPORARILY(302, "Moved Temporarily"), 
/*     */ 
/* 136 */   SEE_OTHER(303, "See Other"), 
/*     */ 
/* 141 */   NOT_MODIFIED(304, "Not Modified"), 
/*     */ 
/* 146 */   USE_PROXY(305, "Use Proxy"), 
/*     */ 
/* 151 */   TEMPORARY_REDIRECT(307, "Temporary Redirect"), 
/*     */ 
/* 157 */   RESUME_INCOMPLETE(308, "Resume Incomplete"), 
/*     */ 
/* 165 */   BAD_REQUEST(400, "Bad Request"), 
/*     */ 
/* 170 */   UNAUTHORIZED(401, "Unauthorized"), 
/*     */ 
/* 175 */   PAYMENT_REQUIRED(402, "Payment Required"), 
/*     */ 
/* 180 */   FORBIDDEN(403, "Forbidden"), 
/*     */ 
/* 185 */   NOT_FOUND(404, "Not Found"), 
/*     */ 
/* 190 */   METHOD_NOT_ALLOWED(405, "Method Not Allowed"), 
/*     */ 
/* 195 */   NOT_ACCEPTABLE(406, "Not Acceptable"), 
/*     */ 
/* 200 */   PROXY_AUTHENTICATION_REQUIRED(407, "Proxy Authentication Required"), 
/*     */ 
/* 205 */   REQUEST_TIMEOUT(408, "Request Timeout"), 
/*     */ 
/* 210 */   CONFLICT(409, "Conflict"), 
/*     */ 
/* 215 */   GONE(410, "Gone"), 
/*     */ 
/* 220 */   LENGTH_REQUIRED(411, "Length Required"), 
/*     */ 
/* 225 */   PRECONDITION_FAILED(412, "Precondition Failed"), 
/*     */ 
/* 230 */   REQUEST_ENTITY_TOO_LARGE(413, "Request Entity Too Large"), 
/*     */ 
/* 235 */   REQUEST_URI_TOO_LONG(414, "Request-URI Too Long"), 
/*     */ 
/* 240 */   UNSUPPORTED_MEDIA_TYPE(415, "Unsupported Media Type"), 
/*     */ 
/* 245 */   REQUESTED_RANGE_NOT_SATISFIABLE(416, "Requested range not satisfiable"), 
/*     */ 
/* 250 */   EXPECTATION_FAILED(417, "Expectation Failed"), 
/*     */ 
/* 255 */   I_AM_A_TEAPOT(418, "I'm a teapot"), 
/*     */ 
/* 259 */   INSUFFICIENT_SPACE_ON_RESOURCE(419, "Insufficient Space On Resource"), 
/*     */ 
/* 263 */   METHOD_FAILURE(420, "Method Failure"), 
/*     */ 
/* 267 */   DESTINATION_LOCKED(421, "Destination Locked"), 
/*     */ 
/* 272 */   UNPROCESSABLE_ENTITY(422, "Unprocessable Entity"), 
/*     */ 
/* 277 */   LOCKED(423, "Locked"), 
/*     */ 
/* 282 */   FAILED_DEPENDENCY(424, "Failed Dependency"), 
/*     */ 
/* 287 */   UPGRADE_REQUIRED(426, "Upgrade Required"), 
/*     */ 
/* 292 */   PRECONDITION_REQUIRED(428, "Precondition Required"), 
/*     */ 
/* 297 */   TOO_MANY_REQUESTS(429, "Too Many Requests"), 
/*     */ 
/* 302 */   REQUEST_HEADER_FIELDS_TOO_LARGE(431, "Request Header Fields Too Large"), 
/*     */ 
/* 310 */   INTERNAL_SERVER_ERROR(500, "Internal Server Error"), 
/*     */ 
/* 315 */   NOT_IMPLEMENTED(501, "Not Implemented"), 
/*     */ 
/* 320 */   BAD_GATEWAY(502, "Bad Gateway"), 
/*     */ 
/* 325 */   SERVICE_UNAVAILABLE(503, "Service Unavailable"), 
/*     */ 
/* 330 */   GATEWAY_TIMEOUT(504, "Gateway Timeout"), 
/*     */ 
/* 335 */   HTTP_VERSION_NOT_SUPPORTED(505, "HTTP Version not supported"), 
/*     */ 
/* 340 */   VARIANT_ALSO_NEGOTIATES(506, "Variant Also Negotiates"), 
/*     */ 
/* 345 */   INSUFFICIENT_STORAGE(507, "Insufficient Storage"), 
/*     */ 
/* 350 */   LOOP_DETECTED(508, "Loop Detected"), 
/*     */ 
/* 354 */   BANDWIDTH_LIMIT_EXCEEDED(509, "Bandwidth Limit Exceeded"), 
/*     */ 
/* 359 */   NOT_EXTENDED(510, "Not Extended"), 
/*     */ 
/* 364 */   NETWORK_AUTHENTICATION_REQUIRED(511, "Network Authentication Required");
/*     */ 
/*     */   private final int value;
/*     */   private final String reasonPhrase;
/*     */ 
/*     */   private HttpStatus(int value, String reasonPhrase)
/*     */   {
/* 374 */     this.value = value;
/* 375 */     this.reasonPhrase = reasonPhrase;
/*     */   }
/*     */ 
/*     */   public int value()
/*     */   {
/* 382 */     return this.value;
/*     */   }
/*     */ 
/*     */   public String getReasonPhrase()
/*     */   {
/* 389 */     return this.reasonPhrase;
/*     */   }
/*     */ 
/*     */   public Series series()
/*     */   {
/* 397 */     return Series.valueOf(this);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 405 */     return Integer.toString(this.value);
/*     */   }
/*     */ 
/*     */   public static HttpStatus valueOf(int statusCode)
/*     */   {
/* 416 */     for (HttpStatus status : values()) {
/* 417 */       if (status.value == statusCode) {
/* 418 */         return status;
/*     */       }
/*     */     }
/* 421 */     throw new IllegalArgumentException("No matching constant for [" + statusCode + "]");
/*     */   }
/*     */ 
/*     */   public static enum Series
/*     */   {
/* 431 */     INFORMATIONAL(1), 
/* 432 */     SUCCESSFUL(2), 
/* 433 */     REDIRECTION(3), 
/* 434 */     CLIENT_ERROR(4), 
/* 435 */     SERVER_ERROR(5);
/*     */ 
/*     */     private final int value;
/*     */ 
/*     */     private Series(int value) {
/* 440 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public int value()
/*     */     {
/* 447 */       return this.value;
/*     */     }
/*     */ 
/*     */     public static Series valueOf(int status) {
/* 451 */       int seriesCode = status / 100;
/* 452 */       for (Series series : values()) {
/* 453 */         if (series.value == seriesCode) {
/* 454 */           return series;
/*     */         }
/*     */       }
/* 457 */       throw new IllegalArgumentException("No matching constant for [" + status + "]");
/*     */     }
/*     */ 
/*     */     public static Series valueOf(HttpStatus status) {
/* 461 */       return valueOf(status.value);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpStatus
 * JD-Core Version:    0.6.1
 */