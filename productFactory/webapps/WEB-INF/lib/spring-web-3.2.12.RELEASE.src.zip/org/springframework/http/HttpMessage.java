package org.springframework.http;

public abstract interface HttpMessage
{
  public abstract HttpHeaders getHeaders();
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.HttpMessage
 * JD-Core Version:    0.6.1
 */