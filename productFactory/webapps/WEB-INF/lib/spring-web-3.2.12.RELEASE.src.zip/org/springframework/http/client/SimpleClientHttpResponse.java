/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.HttpURLConnection;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ final class SimpleClientHttpResponse extends AbstractClientHttpResponse
/*    */ {
/*    */   private final HttpURLConnection connection;
/*    */   private HttpHeaders headers;
/*    */ 
/*    */   SimpleClientHttpResponse(HttpURLConnection connection)
/*    */   {
/* 42 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */   public int getRawStatusCode() throws IOException
/*    */   {
/* 47 */     return this.connection.getResponseCode();
/*    */   }
/*    */ 
/*    */   public String getStatusText() throws IOException {
/* 51 */     return this.connection.getResponseMessage();
/*    */   }
/*    */ 
/*    */   public HttpHeaders getHeaders() {
/* 55 */     if (this.headers == null) {
/* 56 */       this.headers = new HttpHeaders();
/*    */ 
/* 58 */       String name = this.connection.getHeaderFieldKey(0);
/* 59 */       if (StringUtils.hasLength(name)) {
/* 60 */         this.headers.add(name, this.connection.getHeaderField(0));
/*    */       }
/* 62 */       int i = 1;
/*    */       while (true) {
/* 64 */         name = this.connection.getHeaderFieldKey(i);
/* 65 */         if (!StringUtils.hasLength(name)) {
/*    */           break;
/*    */         }
/* 68 */         this.headers.add(name, this.connection.getHeaderField(i));
/* 69 */         i++;
/*    */       }
/*    */     }
/* 72 */     return this.headers;
/*    */   }
/*    */ 
/*    */   public InputStream getBody() throws IOException {
/* 76 */     InputStream errorStream = this.connection.getErrorStream();
/* 77 */     return errorStream != null ? errorStream : this.connection.getInputStream();
/*    */   }
/*    */ 
/*    */   public void close() {
/* 81 */     this.connection.disconnect();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.SimpleClientHttpResponse
 * JD-Core Version:    0.6.1
 */