/*    */ package org.springframework.http.converter.feed;
/*    */ 
/*    */ import com.sun.syndication.feed.rss.Channel;
/*    */ import org.springframework.http.MediaType;
/*    */ 
/*    */ public class RssChannelHttpMessageConverter extends AbstractWireFeedHttpMessageConverter<Channel>
/*    */ {
/*    */   public RssChannelHttpMessageConverter()
/*    */   {
/* 38 */     super(new MediaType("application", "rss+xml"));
/*    */   }
/*    */ 
/*    */   protected boolean supports(Class<?> clazz)
/*    */   {
/* 43 */     return Channel.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.converter.feed.RssChannelHttpMessageConverter
 * JD-Core Version:    0.6.1
 */