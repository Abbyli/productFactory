/*    */ package org.springframework.http.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpMethod;
/*    */ 
/*    */ public class BufferingClientHttpRequestFactory extends AbstractClientHttpRequestFactoryWrapper
/*    */ {
/*    */   public BufferingClientHttpRequestFactory(ClientHttpRequestFactory requestFactory)
/*    */   {
/* 35 */     super(requestFactory);
/*    */   }
/*    */ 
/*    */   protected ClientHttpRequest createRequest(URI uri, HttpMethod httpMethod, ClientHttpRequestFactory requestFactory)
/*    */     throws IOException
/*    */   {
/* 41 */     ClientHttpRequest request = requestFactory.createRequest(uri, httpMethod);
/* 42 */     if (shouldBuffer(uri, httpMethod)) {
/* 43 */       return new BufferingClientHttpRequestWrapper(request);
/*    */     }
/*    */ 
/* 46 */     return request;
/*    */   }
/*    */ 
/*    */   protected boolean shouldBuffer(URI uri, HttpMethod httpMethod)
/*    */   {
/* 61 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.http.client.BufferingClientHttpRequestFactory
 * JD-Core Version:    0.6.1
 */