/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.bind.annotation.RequestParam;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class RequestParamMapMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 49 */     RequestParam requestParamAnnot = (RequestParam)parameter.getParameterAnnotation(RequestParam.class);
/* 50 */     if ((requestParamAnnot != null) && 
/* 51 */       (Map.class.isAssignableFrom(parameter.getParameterType()))) {
/* 52 */       return !StringUtils.hasText(requestParamAnnot.value());
/*    */     }
/*    */ 
/* 55 */     return false;
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 63 */     Class paramType = parameter.getParameterType();
/*    */ 
/* 65 */     Map parameterMap = webRequest.getParameterMap();
/* 66 */     if (MultiValueMap.class.isAssignableFrom(paramType)) {
/* 67 */       MultiValueMap result = new LinkedMultiValueMap(parameterMap.size());
/* 68 */       for (Map.Entry entry : parameterMap.entrySet()) {
/* 69 */         for (String value : (String[])entry.getValue()) {
/* 70 */           result.add(entry.getKey(), value);
/*    */         }
/*    */       }
/* 73 */       return result;
/*    */     }
/*    */ 
/* 76 */     Map result = new LinkedHashMap(parameterMap.size());
/* 77 */     for (Map.Entry entry : parameterMap.entrySet()) {
/* 78 */       if (((String[])entry.getValue()).length > 0) {
/* 79 */         result.put(entry.getKey(), ((String[])entry.getValue())[0]);
/*    */       }
/*    */     }
/* 82 */     return result;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestParamMapMethodArgumentResolver
 * JD-Core Version:    0.6.1
 */