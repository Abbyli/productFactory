/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import javax.faces.application.Application;
/*     */ import javax.faces.component.UIViewRoot;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.portlet.PortletSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class FacesRequestAttributes
/*     */   implements RequestAttributes
/*     */ {
/*  55 */   private static final boolean portletApiPresent = ClassUtils.isPresent("javax.portlet.PortletSession", FacesRequestAttributes.class.getClassLoader());
/*     */ 
/*  61 */   private static final Log logger = LogFactory.getLog(FacesRequestAttributes.class);
/*     */   private final FacesContext facesContext;
/*     */ 
/*     */   public FacesRequestAttributes(FacesContext facesContext)
/*     */   {
/*  72 */     Assert.notNull(facesContext, "FacesContext must not be null");
/*  73 */     this.facesContext = facesContext;
/*     */   }
/*     */ 
/*     */   protected final FacesContext getFacesContext()
/*     */   {
/*  81 */     return this.facesContext;
/*     */   }
/*     */ 
/*     */   protected final ExternalContext getExternalContext()
/*     */   {
/*  89 */     return getFacesContext().getExternalContext();
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> getAttributeMap(int scope)
/*     */   {
/* 100 */     if (scope == 0) {
/* 101 */       return getExternalContext().getRequestMap();
/*     */     }
/*     */ 
/* 104 */     return getExternalContext().getSessionMap();
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String name, int scope)
/*     */   {
/* 110 */     if ((scope == 2) && (portletApiPresent)) {
/* 111 */       return PortletSessionAccessor.getAttribute(name, getExternalContext());
/*     */     }
/*     */ 
/* 114 */     return getAttributeMap(scope).get(name);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String name, Object value, int scope)
/*     */   {
/* 119 */     if ((scope == 2) && (portletApiPresent)) {
/* 120 */       PortletSessionAccessor.setAttribute(name, value, getExternalContext());
/*     */     }
/*     */     else
/* 123 */       getAttributeMap(scope).put(name, value);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(String name, int scope)
/*     */   {
/* 128 */     if ((scope == 2) && (portletApiPresent)) {
/* 129 */       PortletSessionAccessor.removeAttribute(name, getExternalContext());
/*     */     }
/*     */     else
/* 132 */       getAttributeMap(scope).remove(name);
/*     */   }
/*     */ 
/*     */   public String[] getAttributeNames(int scope)
/*     */   {
/* 137 */     if ((scope == 2) && (portletApiPresent)) {
/* 138 */       return PortletSessionAccessor.getAttributeNames(getExternalContext());
/*     */     }
/*     */ 
/* 141 */     return StringUtils.toStringArray(getAttributeMap(scope).keySet());
/*     */   }
/*     */ 
/*     */   public void registerDestructionCallback(String name, Runnable callback, int scope)
/*     */   {
/* 146 */     if (logger.isWarnEnabled())
/* 147 */       logger.warn("Could not register destruction callback [" + callback + "] for attribute '" + name + "' because FacesRequestAttributes does not support such callbacks");
/*     */   }
/*     */ 
/*     */   public Object resolveReference(String key)
/*     */   {
/* 153 */     if ("request".equals(key)) {
/* 154 */       return getExternalContext().getRequest();
/*     */     }
/* 156 */     if ("session".equals(key)) {
/* 157 */       return getExternalContext().getSession(true);
/*     */     }
/* 159 */     if ("application".equals(key)) {
/* 160 */       return getExternalContext().getContext();
/*     */     }
/* 162 */     if ("requestScope".equals(key)) {
/* 163 */       return getExternalContext().getRequestMap();
/*     */     }
/* 165 */     if ("sessionScope".equals(key)) {
/* 166 */       return getExternalContext().getSessionMap();
/*     */     }
/* 168 */     if ("applicationScope".equals(key)) {
/* 169 */       return getExternalContext().getApplicationMap();
/*     */     }
/* 171 */     if ("facesContext".equals(key)) {
/* 172 */       return getFacesContext();
/*     */     }
/* 174 */     if ("cookie".equals(key)) {
/* 175 */       return getExternalContext().getRequestCookieMap();
/*     */     }
/* 177 */     if ("header".equals(key)) {
/* 178 */       return getExternalContext().getRequestHeaderMap();
/*     */     }
/* 180 */     if ("headerValues".equals(key)) {
/* 181 */       return getExternalContext().getRequestHeaderValuesMap();
/*     */     }
/* 183 */     if ("param".equals(key)) {
/* 184 */       return getExternalContext().getRequestParameterMap();
/*     */     }
/* 186 */     if ("paramValues".equals(key)) {
/* 187 */       return getExternalContext().getRequestParameterValuesMap();
/*     */     }
/* 189 */     if ("initParam".equals(key)) {
/* 190 */       return getExternalContext().getInitParameterMap();
/*     */     }
/* 192 */     if ("view".equals(key)) {
/* 193 */       return getFacesContext().getViewRoot();
/*     */     }
/* 195 */     if ("viewScope".equals(key)) {
/*     */       try {
/* 197 */         return ReflectionUtils.invokeMethod(UIViewRoot.class.getMethod("getViewMap", new Class[0]), getFacesContext().getViewRoot());
/*     */       }
/*     */       catch (NoSuchMethodException ex) {
/* 200 */         throw new IllegalStateException("JSF 2.0 API not available", ex);
/*     */       }
/*     */     }
/* 203 */     if ("flash".equals(key)) {
/*     */       try {
/* 205 */         return ReflectionUtils.invokeMethod(ExternalContext.class.getMethod("getFlash", new Class[0]), getExternalContext());
/*     */       }
/*     */       catch (NoSuchMethodException ex) {
/* 208 */         throw new IllegalStateException("JSF 2.0 API not available", ex);
/*     */       }
/*     */     }
/* 211 */     if ("resource".equals(key)) {
/*     */       try {
/* 213 */         return ReflectionUtils.invokeMethod(Application.class.getMethod("getResourceHandler", new Class[0]), getFacesContext().getApplication());
/*     */       }
/*     */       catch (NoSuchMethodException ex) {
/* 216 */         throw new IllegalStateException("JSF 2.0 API not available", ex);
/*     */       }
/*     */     }
/*     */ 
/* 220 */     return null;
/*     */   }
/*     */ 
/*     */   public String getSessionId()
/*     */   {
/* 225 */     Object session = getExternalContext().getSession(true);
/*     */     try
/*     */     {
/* 228 */       Method getIdMethod = session.getClass().getMethod("getId", new Class[0]);
/* 229 */       return ReflectionUtils.invokeMethod(getIdMethod, session).toString();
/*     */     } catch (NoSuchMethodException ex) {
/*     */     }
/* 232 */     throw new IllegalStateException("Session object [" + session + "] does not have a getId() method");
/*     */   }
/*     */ 
/*     */   public Object getSessionMutex()
/*     */   {
/* 239 */     Object session = getExternalContext().getSession(true);
/* 240 */     Object mutex = getExternalContext().getSessionMap().get(WebUtils.SESSION_MUTEX_ATTRIBUTE);
/* 241 */     if (mutex == null) {
/* 242 */       mutex = session;
/*     */     }
/* 244 */     return mutex;
/*     */   }
/*     */ 
/*     */   private static class PortletSessionAccessor
/*     */   {
/*     */     public static Object getAttribute(String name, ExternalContext externalContext)
/*     */     {
/* 254 */       Object session = externalContext.getSession(false);
/* 255 */       if ((session instanceof PortletSession)) {
/* 256 */         return ((PortletSession)session).getAttribute(name, 1);
/*     */       }
/* 258 */       if (session != null) {
/* 259 */         return externalContext.getSessionMap().get(name);
/*     */       }
/*     */ 
/* 262 */       return null;
/*     */     }
/*     */ 
/*     */     public static void setAttribute(String name, Object value, ExternalContext externalContext)
/*     */     {
/* 267 */       Object session = externalContext.getSession(true);
/* 268 */       if ((session instanceof PortletSession)) {
/* 269 */         ((PortletSession)session).setAttribute(name, value, 1);
/*     */       }
/*     */       else
/* 272 */         externalContext.getSessionMap().put(name, value);
/*     */     }
/*     */ 
/*     */     public static void removeAttribute(String name, ExternalContext externalContext)
/*     */     {
/* 277 */       Object session = externalContext.getSession(false);
/* 278 */       if ((session instanceof PortletSession)) {
/* 279 */         ((PortletSession)session).removeAttribute(name, 1);
/*     */       }
/* 281 */       else if (session != null)
/* 282 */         externalContext.getSessionMap().remove(name);
/*     */     }
/*     */ 
/*     */     public static String[] getAttributeNames(ExternalContext externalContext)
/*     */     {
/* 287 */       Object session = externalContext.getSession(false);
/* 288 */       if ((session instanceof PortletSession)) {
/* 289 */         return StringUtils.toStringArray(((PortletSession)session).getAttributeNames(1));
/*     */       }
/*     */ 
/* 292 */       if (session != null) {
/* 293 */         return StringUtils.toStringArray(externalContext.getSessionMap().keySet());
/*     */       }
/*     */ 
/* 296 */       return new String[0];
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.FacesRequestAttributes
 * JD-Core Version:    0.6.1
 */