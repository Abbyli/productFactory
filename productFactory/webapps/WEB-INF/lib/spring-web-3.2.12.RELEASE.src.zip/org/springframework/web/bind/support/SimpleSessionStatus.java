/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ public class SimpleSessionStatus
/*    */   implements SessionStatus
/*    */ {
/* 28 */   private boolean complete = false;
/*    */ 
/*    */   public void setComplete()
/*    */   {
/* 32 */     this.complete = true;
/*    */   }
/*    */ 
/*    */   public boolean isComplete() {
/* 36 */     return this.complete;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.SimpleSessionStatus
 * JD-Core Version:    0.6.1
 */