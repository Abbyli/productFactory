/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletConfig;
/*    */ import org.springframework.core.env.EnumerablePropertySource;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class ServletConfigPropertySource extends EnumerablePropertySource<ServletConfig>
/*    */ {
/*    */   public ServletConfigPropertySource(String name, ServletConfig servletConfig)
/*    */   {
/* 35 */     super(name, servletConfig);
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames()
/*    */   {
/* 40 */     return StringUtils.toStringArray(((ServletConfig)this.source).getInitParameterNames());
/*    */   }
/*    */ 
/*    */   public String getProperty(String name)
/*    */   {
/* 45 */     return ((ServletConfig)this.source).getInitParameter(name);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletConfigPropertySource
 * JD-Core Version:    0.6.1
 */