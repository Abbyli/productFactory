/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.springframework.web.context.request.async.WebAsyncManager;
/*     */ import org.springframework.web.context.request.async.WebAsyncUtils;
/*     */ 
/*     */ public abstract class OncePerRequestFilter extends GenericFilterBean
/*     */ {
/*     */   public static final String ALREADY_FILTERED_SUFFIX = ".FILTERED";
/*     */ 
/*     */   public final void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  88 */     if ((!(request instanceof HttpServletRequest)) || (!(response instanceof HttpServletResponse))) {
/*  89 */       throw new ServletException("OncePerRequestFilter just supports HTTP requests");
/*     */     }
/*  91 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/*  92 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */ 
/*  94 */     String alreadyFilteredAttributeName = getAlreadyFilteredAttributeName();
/*  95 */     boolean hasAlreadyFilteredAttribute = request.getAttribute(alreadyFilteredAttributeName) != null;
/*     */ 
/*  97 */     if ((hasAlreadyFilteredAttribute) || (skipDispatch(httpRequest)) || (shouldNotFilter(httpRequest)))
/*     */     {
/* 100 */       filterChain.doFilter(request, response);
/*     */     }
/*     */     else
/*     */     {
/* 104 */       request.setAttribute(alreadyFilteredAttributeName, Boolean.TRUE);
/*     */       try {
/* 106 */         doFilterInternal(httpRequest, httpResponse, filterChain);
/*     */       }
/*     */       finally
/*     */       {
/* 110 */         request.removeAttribute(alreadyFilteredAttributeName);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean skipDispatch(HttpServletRequest request) {
/* 116 */     if ((isAsyncDispatch(request)) && (shouldNotFilterAsyncDispatch())) {
/* 117 */       return true;
/*     */     }
/* 119 */     if ((request.getAttribute("javax.servlet.error.request_uri") != null) && (shouldNotFilterErrorDispatch())) {
/* 120 */       return true;
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isAsyncDispatch(HttpServletRequest request)
/*     */   {
/* 134 */     return WebAsyncUtils.getAsyncManager(request).hasConcurrentResult();
/*     */   }
/*     */ 
/*     */   protected boolean isAsyncStarted(HttpServletRequest request)
/*     */   {
/* 144 */     return WebAsyncUtils.getAsyncManager(request).isConcurrentHandlingStarted();
/*     */   }
/*     */ 
/*     */   protected String getAlreadyFilteredAttributeName()
/*     */   {
/* 157 */     String name = getFilterName();
/* 158 */     if (name == null) {
/* 159 */       name = getClass().getName();
/*     */     }
/* 161 */     return name + ".FILTERED";
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilter(HttpServletRequest request)
/*     */     throws ServletException
/*     */   {
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterErrorDispatch()
/*     */   {
/* 203 */     return true;
/*     */   }
/*     */ 
/*     */   protected abstract void doFilterInternal(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, FilterChain paramFilterChain)
/*     */     throws ServletException, IOException;
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.OncePerRequestFilter
 * JD-Core Version:    0.6.1
 */