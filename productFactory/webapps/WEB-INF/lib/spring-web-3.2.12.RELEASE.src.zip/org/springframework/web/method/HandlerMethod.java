/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class HandlerMethod
/*     */ {
/*  48 */   protected final Log logger = LogFactory.getLog(HandlerMethod.class);
/*     */   private final Object bean;
/*     */   private final BeanFactory beanFactory;
/*     */   private final Method method;
/*     */   private final Method bridgedMethod;
/*     */   private final MethodParameter[] parameters;
/*     */ 
/*     */   public HandlerMethod(Object bean, Method method)
/*     */   {
/*  65 */     Assert.notNull(bean, "Bean is required");
/*  66 */     Assert.notNull(method, "Method is required");
/*  67 */     this.bean = bean;
/*  68 */     this.beanFactory = null;
/*  69 */     this.method = method;
/*  70 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/*  71 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   public HandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  79 */     Assert.notNull(bean, "Bean is required");
/*  80 */     Assert.notNull(methodName, "Method name is required");
/*  81 */     this.bean = bean;
/*  82 */     this.beanFactory = null;
/*  83 */     this.method = bean.getClass().getMethod(methodName, parameterTypes);
/*  84 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(this.method);
/*  85 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   public HandlerMethod(String beanName, BeanFactory beanFactory, Method method)
/*     */   {
/*  94 */     Assert.hasText(beanName, "Bean name is required");
/*  95 */     Assert.notNull(beanFactory, "BeanFactory is required");
/*  96 */     Assert.notNull(method, "Method is required");
/*  97 */     Assert.isTrue(beanFactory.containsBean(beanName), "BeanFactory [" + beanFactory + "] does not contain bean [" + beanName + "]");
/*     */ 
/*  99 */     this.bean = beanName;
/* 100 */     this.beanFactory = beanFactory;
/* 101 */     this.method = method;
/* 102 */     this.bridgedMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 103 */     this.parameters = initMethodParameters();
/*     */   }
/*     */ 
/*     */   protected HandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/* 110 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 111 */     this.bean = handlerMethod.bean;
/* 112 */     this.beanFactory = handlerMethod.beanFactory;
/* 113 */     this.method = handlerMethod.method;
/* 114 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 115 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   private HandlerMethod(HandlerMethod handlerMethod, Object handler)
/*     */   {
/* 122 */     Assert.notNull(handlerMethod, "HandlerMethod is required");
/* 123 */     Assert.notNull(handler, "Handler object is required");
/* 124 */     this.bean = handler;
/* 125 */     this.beanFactory = handlerMethod.beanFactory;
/* 126 */     this.method = handlerMethod.method;
/* 127 */     this.bridgedMethod = handlerMethod.bridgedMethod;
/* 128 */     this.parameters = handlerMethod.parameters;
/*     */   }
/*     */ 
/*     */   private MethodParameter[] initMethodParameters()
/*     */   {
/* 133 */     int count = this.bridgedMethod.getParameterTypes().length;
/* 134 */     MethodParameter[] result = new MethodParameter[count];
/* 135 */     for (int i = 0; i < count; i++) {
/* 136 */       result[i] = new HandlerMethodParameter(i);
/*     */     }
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */   public Object getBean()
/*     */   {
/* 145 */     return this.bean;
/*     */   }
/*     */ 
/*     */   public Method getMethod()
/*     */   {
/* 152 */     return this.method;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/* 160 */     Class clazz = (this.bean instanceof String) ? this.beanFactory.getType((String)this.bean) : this.bean.getClass();
/*     */ 
/* 162 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   protected Method getBridgedMethod()
/*     */   {
/* 170 */     return this.bridgedMethod;
/*     */   }
/*     */ 
/*     */   public MethodParameter[] getMethodParameters()
/*     */   {
/* 177 */     return this.parameters;
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnType()
/*     */   {
/* 184 */     return new HandlerMethodParameter(-1);
/*     */   }
/*     */ 
/*     */   public MethodParameter getReturnValueType(Object returnValue)
/*     */   {
/* 191 */     return new ReturnValueMethodParameter(returnValue);
/*     */   }
/*     */ 
/*     */   public boolean isVoid()
/*     */   {
/* 198 */     return Void.TYPE.equals(getReturnType().getParameterType());
/*     */   }
/*     */ 
/*     */   public <A extends Annotation> A getMethodAnnotation(Class<A> annotationType)
/*     */   {
/* 208 */     return AnnotationUtils.findAnnotation(this.method, annotationType);
/*     */   }
/*     */ 
/*     */   public HandlerMethod createWithResolvedBean()
/*     */   {
/* 216 */     Object handler = this.bean;
/* 217 */     if ((this.bean instanceof String)) {
/* 218 */       String beanName = (String)this.bean;
/* 219 */       handler = this.beanFactory.getBean(beanName);
/*     */     }
/* 221 */     return new HandlerMethod(this, handler);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 226 */     if (this == obj) {
/* 227 */       return true;
/*     */     }
/* 229 */     if ((obj != null) && ((obj instanceof HandlerMethod))) {
/* 230 */       HandlerMethod other = (HandlerMethod)obj;
/* 231 */       return (this.bean.equals(other.bean)) && (this.method.equals(other.method));
/*     */     }
/* 233 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 238 */     return this.bean.hashCode() * 31 + this.method.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 243 */     return this.method.toGenericString();
/*     */   }
/*     */ 
/*     */   private class ReturnValueMethodParameter extends HandlerMethod.HandlerMethodParameter
/*     */   {
/*     */     private final Object returnValue;
/*     */ 
/*     */     public ReturnValueMethodParameter(Object returnValue)
/*     */     {
/* 276 */       super(-1);
/* 277 */       this.returnValue = returnValue;
/*     */     }
/*     */ 
/*     */     public Class<?> getParameterType()
/*     */     {
/* 282 */       return this.returnValue != null ? this.returnValue.getClass() : super.getParameterType();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HandlerMethodParameter extends MethodParameter
/*     */   {
/*     */     public HandlerMethodParameter(int index)
/*     */     {
/* 253 */       super(index);
/*     */     }
/*     */ 
/*     */     public Class<?> getDeclaringClass()
/*     */     {
/* 258 */       return HandlerMethod.this.getBeanType();
/*     */     }
/*     */ 
/*     */     public <T extends Annotation> T getMethodAnnotation(Class<T> annotationType)
/*     */     {
/* 263 */       return HandlerMethod.this.getMethodAnnotation(annotationType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.HandlerMethod
 * JD-Core Version:    0.6.1
 */