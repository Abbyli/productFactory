/*     */ package org.springframework.web;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContainerInitializer;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.annotation.HandlesTypes;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ 
/*     */ @HandlesTypes({WebApplicationInitializer.class})
/*     */ public class SpringServletContainerInitializer
/*     */   implements ServletContainerInitializer
/*     */ {
/*     */   public void onStartup(Set<Class<?>> webAppInitializerClasses, ServletContext servletContext)
/*     */     throws ServletException
/*     */   {
/* 147 */     List initializers = new LinkedList();
/*     */ 
/* 149 */     if (webAppInitializerClasses != null) {
/* 150 */       for (Class waiClass : webAppInitializerClasses)
/*     */       {
/* 153 */         if ((!waiClass.isInterface()) && (!Modifier.isAbstract(waiClass.getModifiers())) && (WebApplicationInitializer.class.isAssignableFrom(waiClass))) {
/*     */           try
/*     */           {
/* 156 */             initializers.add((WebApplicationInitializer)waiClass.newInstance());
/*     */           }
/*     */           catch (Throwable ex) {
/* 159 */             throw new ServletException("Failed to instantiate WebApplicationInitializer class", ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 165 */     if (initializers.isEmpty()) {
/* 166 */       servletContext.log("No Spring WebApplicationInitializer types detected on classpath");
/* 167 */       return;
/*     */     }
/*     */ 
/* 170 */     AnnotationAwareOrderComparator.sort(initializers);
/* 171 */     servletContext.log("Spring WebApplicationInitializers detected on classpath: " + initializers);
/*     */ 
/* 173 */     for (WebApplicationInitializer initializer : initializers)
/* 174 */       initializer.onStartup(servletContext);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.SpringServletContainerInitializer
 * JD-Core Version:    0.6.1
 */