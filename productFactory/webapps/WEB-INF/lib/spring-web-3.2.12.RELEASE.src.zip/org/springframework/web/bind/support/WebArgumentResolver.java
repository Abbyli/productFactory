/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public abstract interface WebArgumentResolver
/*    */ {
/* 51 */   public static final Object UNRESOLVED = new Object();
/*    */ 
/*    */   public abstract Object resolveArgument(MethodParameter paramMethodParameter, NativeWebRequest paramNativeWebRequest)
/*    */     throws Exception;
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebArgumentResolver
 * JD-Core Version:    0.6.1
 */