/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class UriComponentsBuilder
/*     */ {
/*  59 */   private static final Pattern QUERY_PARAM_PATTERN = Pattern.compile("([^&=]+)(=?)([^&]+)?");
/*     */   private static final String SCHEME_PATTERN = "([^:/?#]+):";
/*     */   private static final String HTTP_PATTERN = "(?i)(http|https):";
/*     */   private static final String USERINFO_PATTERN = "([^@\\[/?#]*)";
/*     */   private static final String HOST_PATTERN = "([^/?#:]*)";
/*     */   private static final String PORT_PATTERN = "(\\d*)";
/*     */   private static final String PATH_PATTERN = "([^?#]*)";
/*     */   private static final String QUERY_PATTERN = "([^#]*)";
/*     */   private static final String LAST_PATTERN = "(.*)";
/*  78 */   private static final Pattern URI_PATTERN = Pattern.compile("^(([^:/?#]+):)?(//(([^@\\[/?#]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?([^#]*))?(#(.*))?");
/*     */ 
/*  82 */   private static final Pattern HTTP_URL_PATTERN = Pattern.compile("^(?i)(http|https):(//(([^@\\[/?#]*)@)?([^/?#:]*)(:(\\d*))?)?([^?#]*)(\\?(.*))?");
/*     */   private String scheme;
/*     */   private String ssp;
/*     */   private String userInfo;
/*     */   private String host;
/*  95 */   private int port = -1;
/*     */ 
/*  97 */   private CompositePathComponentBuilder pathBuilder = new CompositePathComponentBuilder();
/*     */ 
/*  99 */   private final MultiValueMap<String, String> queryParams = new LinkedMultiValueMap();
/*     */   private String fragment;
/*     */ 
/*     */   public static UriComponentsBuilder newInstance()
/*     */   {
/* 121 */     return new UriComponentsBuilder();
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromPath(String path)
/*     */   {
/* 130 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 131 */     builder.path(path);
/* 132 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUri(URI uri)
/*     */   {
/* 141 */     UriComponentsBuilder builder = new UriComponentsBuilder();
/* 142 */     builder.uri(uri);
/* 143 */     return builder;
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromUriString(String uri)
/*     */   {
/* 161 */     Assert.hasLength(uri, "'uri' must not be empty");
/* 162 */     Matcher matcher = URI_PATTERN.matcher(uri);
/* 163 */     if (matcher.matches()) {
/* 164 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 165 */       String scheme = matcher.group(2);
/* 166 */       String userInfo = matcher.group(5);
/* 167 */       String host = matcher.group(6);
/* 168 */       String port = matcher.group(8);
/* 169 */       String path = matcher.group(9);
/* 170 */       String query = matcher.group(11);
/* 171 */       String fragment = matcher.group(13);
/* 172 */       boolean opaque = false;
/* 173 */       if (StringUtils.hasLength(scheme)) {
/* 174 */         String rest = uri.substring(scheme.length());
/* 175 */         if (!rest.startsWith(":/")) {
/* 176 */           opaque = true;
/*     */         }
/*     */       }
/* 179 */       builder.scheme(scheme);
/* 180 */       if (opaque) {
/* 181 */         String ssp = uri.substring(scheme.length()).substring(1);
/* 182 */         if (StringUtils.hasLength(fragment)) {
/* 183 */           ssp = ssp.substring(0, ssp.length() - (fragment.length() + 1));
/*     */         }
/* 185 */         builder.schemeSpecificPart(ssp);
/*     */       }
/*     */       else {
/* 188 */         builder.userInfo(userInfo);
/* 189 */         builder.host(host);
/* 190 */         if (StringUtils.hasLength(port)) {
/* 191 */           builder.port(Integer.parseInt(port));
/*     */         }
/* 193 */         builder.path(path);
/* 194 */         builder.query(query);
/*     */       }
/* 196 */       if (StringUtils.hasText(fragment)) {
/* 197 */         builder.fragment(fragment);
/*     */       }
/* 199 */       return builder;
/*     */     }
/*     */ 
/* 202 */     throw new IllegalArgumentException("[" + uri + "] is not a valid URI");
/*     */   }
/*     */ 
/*     */   public static UriComponentsBuilder fromHttpUrl(String httpUrl)
/*     */   {
/* 221 */     Assert.notNull(httpUrl, "'httpUrl' must not be null");
/* 222 */     Matcher matcher = HTTP_URL_PATTERN.matcher(httpUrl);
/* 223 */     if (matcher.matches()) {
/* 224 */       UriComponentsBuilder builder = new UriComponentsBuilder();
/* 225 */       String scheme = matcher.group(1);
/* 226 */       builder.scheme(scheme != null ? scheme.toLowerCase() : null);
/* 227 */       builder.userInfo(matcher.group(4));
/* 228 */       builder.host(matcher.group(5));
/* 229 */       String port = matcher.group(7);
/* 230 */       if (StringUtils.hasLength(port)) {
/* 231 */         builder.port(Integer.parseInt(port));
/*     */       }
/* 233 */       builder.path(matcher.group(8));
/* 234 */       builder.query(matcher.group(10));
/* 235 */       return builder;
/*     */     }
/*     */ 
/* 238 */     throw new IllegalArgumentException("[" + httpUrl + "] is not a valid HTTP URL");
/*     */   }
/*     */ 
/*     */   public UriComponents build()
/*     */   {
/* 250 */     return build(false);
/*     */   }
/*     */ 
/*     */   public UriComponents build(boolean encoded)
/*     */   {
/* 261 */     if (this.ssp != null) {
/* 262 */       return new OpaqueUriComponents(this.scheme, this.ssp, this.fragment);
/*     */     }
/*     */ 
/* 265 */     return new HierarchicalUriComponents(this.scheme, this.userInfo, this.host, this.port, this.pathBuilder.build(), this.queryParams, this.fragment, encoded, true);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Map<String, ?> uriVariables)
/*     */   {
/* 278 */     return build(false).expand(uriVariables);
/*     */   }
/*     */ 
/*     */   public UriComponents buildAndExpand(Object[] uriVariableValues)
/*     */   {
/* 289 */     return build(false).expand(uriVariableValues);
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder uri(URI uri)
/*     */   {
/* 301 */     Assert.notNull(uri, "'uri' must not be null");
/* 302 */     this.scheme = uri.getScheme();
/* 303 */     if (uri.isOpaque()) {
/* 304 */       this.ssp = uri.getRawSchemeSpecificPart();
/* 305 */       resetHierarchicalComponents();
/*     */     }
/*     */     else {
/* 308 */       if (uri.getRawUserInfo() != null) {
/* 309 */         this.userInfo = uri.getRawUserInfo();
/*     */       }
/* 311 */       if (uri.getHost() != null) {
/* 312 */         this.host = uri.getHost();
/*     */       }
/* 314 */       if (uri.getPort() != -1) {
/* 315 */         this.port = uri.getPort();
/*     */       }
/* 317 */       if (StringUtils.hasLength(uri.getRawPath())) {
/* 318 */         this.pathBuilder = new CompositePathComponentBuilder(uri.getRawPath());
/*     */       }
/* 320 */       if (StringUtils.hasLength(uri.getRawQuery())) {
/* 321 */         this.queryParams.clear();
/* 322 */         query(uri.getRawQuery());
/*     */       }
/* 324 */       resetSchemeSpecificPart();
/*     */     }
/* 326 */     if (uri.getRawFragment() != null) {
/* 327 */       this.fragment = uri.getRawFragment();
/*     */     }
/* 329 */     return this;
/*     */   }
/*     */ 
/*     */   private void resetHierarchicalComponents() {
/* 333 */     this.userInfo = null;
/* 334 */     this.host = null;
/* 335 */     this.port = -1;
/* 336 */     this.pathBuilder = new CompositePathComponentBuilder();
/* 337 */     this.queryParams.clear();
/*     */   }
/*     */ 
/*     */   private void resetSchemeSpecificPart() {
/* 341 */     this.ssp = null;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder scheme(String scheme)
/*     */   {
/* 351 */     this.scheme = scheme;
/* 352 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder schemeSpecificPart(String ssp)
/*     */   {
/* 364 */     this.ssp = ssp;
/* 365 */     resetHierarchicalComponents();
/* 366 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder userInfo(String userInfo)
/*     */   {
/* 376 */     this.userInfo = userInfo;
/* 377 */     resetSchemeSpecificPart();
/* 378 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder host(String host)
/*     */   {
/* 388 */     this.host = host;
/* 389 */     resetSchemeSpecificPart();
/* 390 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder port(int port)
/*     */   {
/* 399 */     Assert.isTrue(port >= -1, "'port' must not be < -1");
/* 400 */     this.port = port;
/* 401 */     resetSchemeSpecificPart();
/* 402 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder path(String path)
/*     */   {
/* 412 */     this.pathBuilder.addPath(path);
/* 413 */     resetSchemeSpecificPart();
/* 414 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replacePath(String path)
/*     */   {
/* 423 */     this.pathBuilder = new CompositePathComponentBuilder(path);
/* 424 */     resetSchemeSpecificPart();
/* 425 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder pathSegment(String[] pathSegments)
/*     */     throws IllegalArgumentException
/*     */   {
/* 435 */     Assert.notNull(pathSegments, "'segments' must not be null");
/* 436 */     this.pathBuilder.addPathSegments(pathSegments);
/* 437 */     resetSchemeSpecificPart();
/* 438 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder query(String query)
/*     */   {
/* 457 */     if (query != null) {
/* 458 */       Matcher matcher = QUERY_PARAM_PATTERN.matcher(query);
/* 459 */       while (matcher.find()) {
/* 460 */         String name = matcher.group(1);
/* 461 */         String eq = matcher.group(2);
/* 462 */         String value = matcher.group(3);
/* 463 */         queryParam(name, new Object[] { StringUtils.hasLength(eq) ? "" : value != null ? value : null });
/*     */       }
/*     */     }
/*     */     else {
/* 467 */       this.queryParams.clear();
/*     */     }
/* 469 */     resetSchemeSpecificPart();
/* 470 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQuery(String query)
/*     */   {
/* 479 */     this.queryParams.clear();
/* 480 */     query(query);
/* 481 */     resetSchemeSpecificPart();
/* 482 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder queryParam(String name, Object[] values)
/*     */   {
/* 495 */     Assert.notNull(name, "'name' must not be null");
/* 496 */     if (!ObjectUtils.isEmpty(values)) {
/* 497 */       for (Object value : values) {
/* 498 */         String valueAsString = value != null ? value.toString() : null;
/* 499 */         this.queryParams.add(name, valueAsString);
/*     */       }
/*     */     }
/*     */     else {
/* 503 */       this.queryParams.add(name, null);
/*     */     }
/* 505 */     resetSchemeSpecificPart();
/* 506 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder replaceQueryParam(String name, Object[] values)
/*     */   {
/* 517 */     Assert.notNull(name, "'name' must not be null");
/* 518 */     this.queryParams.remove(name);
/* 519 */     if (!ObjectUtils.isEmpty(values)) {
/* 520 */       queryParam(name, values);
/*     */     }
/* 522 */     resetSchemeSpecificPart();
/* 523 */     return this;
/*     */   }
/*     */ 
/*     */   public UriComponentsBuilder fragment(String fragment)
/*     */   {
/* 533 */     if (fragment != null) {
/* 534 */       Assert.hasLength(fragment, "'fragment' must not be empty");
/* 535 */       this.fragment = fragment;
/*     */     }
/*     */     else {
/* 538 */       this.fragment = null;
/*     */     }
/* 540 */     return this;
/*     */   }
/*     */ 
/*     */   private static class PathSegmentComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 649 */     private final List<String> pathSegments = new LinkedList();
/*     */ 
/*     */     public void append(String[] pathSegments) {
/* 652 */       for (String pathSegment : pathSegments)
/* 653 */         if (StringUtils.hasText(pathSegment))
/* 654 */           this.pathSegments.add(pathSegment);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build()
/*     */     {
/* 660 */       return this.pathSegments.isEmpty() ? null : new HierarchicalUriComponents.PathSegmentComponent(this.pathSegments);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class FullPathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 624 */     private final StringBuilder path = new StringBuilder();
/*     */ 
/*     */     public void append(String path) {
/* 627 */       this.path.append(path);
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build() {
/* 631 */       if (this.path.length() == 0) {
/* 632 */         return null;
/*     */       }
/* 634 */       String path = this.path.toString().replace("//", "/");
/* 635 */       return new HierarchicalUriComponents.FullPathComponent(path);
/*     */     }
/*     */ 
/*     */     public void removeTrailingSlash() {
/* 639 */       int index = this.path.length() - 1;
/* 640 */       if (this.path.charAt(index) == '/')
/* 641 */         this.path.deleteCharAt(index);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CompositePathComponentBuilder
/*     */     implements UriComponentsBuilder.PathComponentBuilder
/*     */   {
/* 552 */     private final LinkedList<UriComponentsBuilder.PathComponentBuilder> componentBuilders = new LinkedList();
/*     */ 
/*     */     public CompositePathComponentBuilder() {
/*     */     }
/*     */ 
/*     */     public CompositePathComponentBuilder(String path) {
/* 558 */       addPath(path);
/*     */     }
/*     */ 
/*     */     public void addPathSegments(String[] pathSegments) {
/* 562 */       if (!ObjectUtils.isEmpty(pathSegments)) {
/* 563 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 564 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 565 */         if (psBuilder == null) {
/* 566 */           psBuilder = new UriComponentsBuilder.PathSegmentComponentBuilder(null);
/* 567 */           this.componentBuilders.add(psBuilder);
/* 568 */           if (fpBuilder != null) {
/* 569 */             fpBuilder.removeTrailingSlash();
/*     */           }
/*     */         }
/* 572 */         psBuilder.append(pathSegments);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void addPath(String path) {
/* 577 */       if (StringUtils.hasText(path)) {
/* 578 */         UriComponentsBuilder.PathSegmentComponentBuilder psBuilder = (UriComponentsBuilder.PathSegmentComponentBuilder)getLastBuilder(UriComponentsBuilder.PathSegmentComponentBuilder.class);
/* 579 */         UriComponentsBuilder.FullPathComponentBuilder fpBuilder = (UriComponentsBuilder.FullPathComponentBuilder)getLastBuilder(UriComponentsBuilder.FullPathComponentBuilder.class);
/* 580 */         if (psBuilder != null) {
/* 581 */           path = "/" + path;
/*     */         }
/* 583 */         if (fpBuilder == null) {
/* 584 */           fpBuilder = new UriComponentsBuilder.FullPathComponentBuilder(null);
/* 585 */           this.componentBuilders.add(fpBuilder);
/*     */         }
/* 587 */         fpBuilder.append(path);
/*     */       }
/*     */     }
/*     */ 
/*     */     private <T> T getLastBuilder(Class<T> builderClass)
/*     */     {
/* 593 */       if (!this.componentBuilders.isEmpty()) {
/* 594 */         UriComponentsBuilder.PathComponentBuilder last = (UriComponentsBuilder.PathComponentBuilder)this.componentBuilders.getLast();
/* 595 */         if (builderClass.isInstance(last)) {
/* 596 */           return last;
/*     */         }
/*     */       }
/* 599 */       return null;
/*     */     }
/*     */ 
/*     */     public HierarchicalUriComponents.PathComponent build() {
/* 603 */       int size = this.componentBuilders.size();
/* 604 */       List components = new ArrayList(size);
/* 605 */       for (UriComponentsBuilder.PathComponentBuilder componentBuilder : this.componentBuilders) {
/* 606 */         HierarchicalUriComponents.PathComponent pathComponent = componentBuilder.build();
/* 607 */         if (pathComponent != null) {
/* 608 */           components.add(pathComponent);
/*     */         }
/*     */       }
/* 611 */       if (components.isEmpty()) {
/* 612 */         return HierarchicalUriComponents.NULL_PATH_COMPONENT;
/*     */       }
/* 614 */       if (components.size() == 1) {
/* 615 */         return (HierarchicalUriComponents.PathComponent)components.get(0);
/*     */       }
/* 617 */       return new HierarchicalUriComponents.PathComponentComposite(components);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface PathComponentBuilder
/*     */   {
/*     */     public abstract HierarchicalUriComponents.PathComponent build();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriComponentsBuilder
 * JD-Core Version:    0.6.1
 */