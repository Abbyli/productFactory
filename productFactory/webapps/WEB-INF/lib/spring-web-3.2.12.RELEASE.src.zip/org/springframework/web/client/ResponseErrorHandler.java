package org.springframework.web.client;

import java.io.IOException;
import org.springframework.http.client.ClientHttpResponse;

public abstract interface ResponseErrorHandler
{
  public abstract boolean hasError(ClientHttpResponse paramClientHttpResponse)
    throws IOException;

  public abstract void handleError(ClientHttpResponse paramClientHttpResponse)
    throws IOException;
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.ResponseErrorHandler
 * JD-Core Version:    0.6.1
 */