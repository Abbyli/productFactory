/*     */ package org.springframework.web.bind;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.FieldError;
/*     */ import org.springframework.validation.ObjectError;
/*     */ import org.springframework.web.util.HtmlUtils;
/*     */ 
/*     */ public class EscapedErrors
/*     */   implements Errors
/*     */ {
/*     */   private final Errors source;
/*     */ 
/*     */   public EscapedErrors(Errors source)
/*     */   {
/*  50 */     if (source == null) {
/*  51 */       throw new IllegalArgumentException("Cannot wrap a null instance");
/*     */     }
/*  53 */     this.source = source;
/*     */   }
/*     */ 
/*     */   public Errors getSource() {
/*  57 */     return this.source;
/*     */   }
/*     */ 
/*     */   public String getObjectName()
/*     */   {
/*  62 */     return this.source.getObjectName();
/*     */   }
/*     */ 
/*     */   public void setNestedPath(String nestedPath) {
/*  66 */     this.source.setNestedPath(nestedPath);
/*     */   }
/*     */ 
/*     */   public String getNestedPath() {
/*  70 */     return this.source.getNestedPath();
/*     */   }
/*     */ 
/*     */   public void pushNestedPath(String subPath) {
/*  74 */     this.source.pushNestedPath(subPath);
/*     */   }
/*     */ 
/*     */   public void popNestedPath() throws IllegalStateException {
/*  78 */     this.source.popNestedPath();
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode)
/*     */   {
/*  83 */     this.source.reject(errorCode);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, String defaultMessage) {
/*  87 */     this.source.reject(errorCode, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, Object[] errorArgs, String defaultMessage) {
/*  91 */     this.source.reject(errorCode, errorArgs, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode) {
/*  95 */     this.source.rejectValue(field, errorCode);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, String defaultMessage) {
/*  99 */     this.source.rejectValue(field, errorCode, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, Object[] errorArgs, String defaultMessage) {
/* 103 */     this.source.rejectValue(field, errorCode, errorArgs, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void addAllErrors(Errors errors) {
/* 107 */     this.source.addAllErrors(errors);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 112 */     return this.source.hasErrors();
/*     */   }
/*     */ 
/*     */   public int getErrorCount() {
/* 116 */     return this.source.getErrorCount();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getAllErrors() {
/* 120 */     return escapeObjectErrors(this.source.getAllErrors());
/*     */   }
/*     */ 
/*     */   public boolean hasGlobalErrors() {
/* 124 */     return this.source.hasGlobalErrors();
/*     */   }
/*     */ 
/*     */   public int getGlobalErrorCount() {
/* 128 */     return this.source.getGlobalErrorCount();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getGlobalErrors() {
/* 132 */     return escapeObjectErrors(this.source.getGlobalErrors());
/*     */   }
/*     */ 
/*     */   public ObjectError getGlobalError() {
/* 136 */     return escapeObjectError(this.source.getGlobalError());
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors() {
/* 140 */     return this.source.hasFieldErrors();
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount() {
/* 144 */     return this.source.getFieldErrorCount();
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors() {
/* 148 */     return this.source.getFieldErrors();
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError() {
/* 152 */     return this.source.getFieldError();
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors(String field) {
/* 156 */     return this.source.hasFieldErrors(field);
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount(String field) {
/* 160 */     return this.source.getFieldErrorCount(field);
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors(String field) {
/* 164 */     return escapeObjectErrors(this.source.getFieldErrors(field));
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError(String field) {
/* 168 */     return (FieldError)escapeObjectError(this.source.getFieldError(field));
/*     */   }
/*     */ 
/*     */   public Object getFieldValue(String field) {
/* 172 */     Object value = this.source.getFieldValue(field);
/* 173 */     return (value instanceof String) ? HtmlUtils.htmlEscape((String)value) : value;
/*     */   }
/*     */ 
/*     */   public Class getFieldType(String field) {
/* 177 */     return this.source.getFieldType(field);
/*     */   }
/*     */ 
/*     */   private <T extends ObjectError> T escapeObjectError(T source)
/*     */   {
/* 182 */     if (source == null) {
/* 183 */       return null;
/*     */     }
/* 185 */     if ((source instanceof FieldError)) {
/* 186 */       FieldError fieldError = (FieldError)source;
/* 187 */       Object value = fieldError.getRejectedValue();
/* 188 */       if ((value instanceof String)) {
/* 189 */         value = HtmlUtils.htmlEscape((String)value);
/*     */       }
/* 191 */       return new FieldError(fieldError.getObjectName(), fieldError.getField(), value, fieldError.isBindingFailure(), fieldError.getCodes(), fieldError.getArguments(), HtmlUtils.htmlEscape(fieldError.getDefaultMessage()));
/*     */     }
/*     */ 
/* 197 */     return new ObjectError(source.getObjectName(), source.getCodes(), source.getArguments(), HtmlUtils.htmlEscape(source.getDefaultMessage()));
/*     */   }
/*     */ 
/*     */   private <T extends ObjectError> List<T> escapeObjectErrors(List<T> source)
/*     */   {
/* 204 */     List escaped = new ArrayList(source.size());
/* 205 */     for (ObjectError objectError : source) {
/* 206 */       escaped.add(escapeObjectError(objectError));
/*     */     }
/* 208 */     return escaped;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.EscapedErrors
 * JD-Core Version:    0.6.1
 */