/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class UriTemplate
/*     */   implements Serializable
/*     */ {
/*  48 */   private static final Pattern NAMES_PATTERN = Pattern.compile("\\{([^/]+?)\\}");
/*     */   private static final String DEFAULT_VARIABLE_PATTERN = "(.*)";
/*     */   private final UriComponents uriComponents;
/*     */   private final List<String> variableNames;
/*     */   private final Pattern matchPattern;
/*     */   private final String uriTemplate;
/*     */ 
/*     */   public UriTemplate(String uriTemplate)
/*     */   {
/*  67 */     Parser parser = new Parser(uriTemplate, null);
/*  68 */     this.uriTemplate = uriTemplate;
/*  69 */     this.variableNames = parser.getVariableNames();
/*  70 */     this.matchPattern = parser.getMatchPattern();
/*  71 */     this.uriComponents = UriComponentsBuilder.fromUriString(uriTemplate).build();
/*     */   }
/*     */ 
/*     */   public List<String> getVariableNames()
/*     */   {
/*  80 */     return this.variableNames;
/*     */   }
/*     */ 
/*     */   public URI expand(Map<String, ?> uriVariables)
/*     */   {
/* 101 */     UriComponents expandedComponents = this.uriComponents.expand(uriVariables);
/* 102 */     UriComponents encodedComponents = expandedComponents.encode();
/* 103 */     return encodedComponents.toUri();
/*     */   }
/*     */ 
/*     */   public URI expand(Object[] uriVariableValues)
/*     */   {
/* 121 */     UriComponents expandedComponents = this.uriComponents.expand(uriVariableValues);
/* 122 */     UriComponents encodedComponents = expandedComponents.encode();
/* 123 */     return encodedComponents.toUri();
/*     */   }
/*     */ 
/*     */   public boolean matches(String uri)
/*     */   {
/* 132 */     if (uri == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     Matcher matcher = this.matchPattern.matcher(uri);
/* 136 */     return matcher.matches();
/*     */   }
/*     */ 
/*     */   public Map<String, String> match(String uri)
/*     */   {
/* 152 */     Assert.notNull(uri, "'uri' must not be null");
/* 153 */     Map result = new LinkedHashMap(this.variableNames.size());
/* 154 */     Matcher matcher = this.matchPattern.matcher(uri);
/* 155 */     if (matcher.find()) {
/* 156 */       for (int i = 1; i <= matcher.groupCount(); i++) {
/* 157 */         String name = (String)this.variableNames.get(i - 1);
/* 158 */         String value = matcher.group(i);
/* 159 */         result.put(name, value);
/*     */       }
/*     */     }
/* 162 */     return result;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected URI encodeUri(String uri)
/*     */   {
/*     */     try
/*     */     {
/* 175 */       String encoded = UriUtils.encodeUri(uri, "UTF-8");
/* 176 */       return new URI(encoded);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 180 */       throw new IllegalStateException(ex);
/*     */     }
/*     */     catch (URISyntaxException ex) {
/* 183 */       throw new IllegalArgumentException("Could not create URI from [" + uri + "]: " + ex, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 189 */     return this.uriTemplate;
/*     */   }
/*     */ 
/*     */   private static class Parser
/*     */   {
/* 198 */     private final List<String> variableNames = new LinkedList();
/*     */ 
/* 200 */     private final StringBuilder patternBuilder = new StringBuilder();
/*     */ 
/*     */     private Parser(String uriTemplate) {
/* 203 */       Assert.hasText(uriTemplate, "'uriTemplate' must not be null");
/* 204 */       Matcher matcher = UriTemplate.NAMES_PATTERN.matcher(uriTemplate);
/* 205 */       int end = 0;
/* 206 */       while (matcher.find()) {
/* 207 */         this.patternBuilder.append(quote(uriTemplate, end, matcher.start()));
/* 208 */         String match = matcher.group(1);
/* 209 */         int colonIdx = match.indexOf(':');
/* 210 */         if (colonIdx == -1) {
/* 211 */           this.patternBuilder.append("(.*)");
/* 212 */           this.variableNames.add(match);
/*     */         }
/*     */         else {
/* 215 */           if (colonIdx + 1 == match.length()) {
/* 216 */             throw new IllegalArgumentException("No custom regular expression specified after ':' in \"" + match + "\"");
/*     */           }
/*     */ 
/* 219 */           String variablePattern = match.substring(colonIdx + 1, match.length());
/* 220 */           this.patternBuilder.append('(');
/* 221 */           this.patternBuilder.append(variablePattern);
/* 222 */           this.patternBuilder.append(')');
/* 223 */           String variableName = match.substring(0, colonIdx);
/* 224 */           this.variableNames.add(variableName);
/*     */         }
/* 226 */         end = matcher.end();
/*     */       }
/* 228 */       this.patternBuilder.append(quote(uriTemplate, end, uriTemplate.length()));
/* 229 */       int lastIdx = this.patternBuilder.length() - 1;
/* 230 */       if ((lastIdx >= 0) && (this.patternBuilder.charAt(lastIdx) == '/'))
/* 231 */         this.patternBuilder.deleteCharAt(lastIdx);
/*     */     }
/*     */ 
/*     */     private String quote(String fullPath, int start, int end)
/*     */     {
/* 236 */       if (start == end) {
/* 237 */         return "";
/*     */       }
/* 239 */       return Pattern.quote(fullPath.substring(start, end));
/*     */     }
/*     */ 
/*     */     private List<String> getVariableNames() {
/* 243 */       return Collections.unmodifiableList(this.variableNames);
/*     */     }
/*     */ 
/*     */     private Pattern getMatchPattern() {
/* 247 */       return Pattern.compile(this.patternBuilder.toString());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.UriTemplate
 * JD-Core Version:    0.6.1
 */