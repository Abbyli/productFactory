/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ public class ServletContextAttributeFactoryBean
/*    */   implements FactoryBean<Object>, ServletContextAware
/*    */ {
/*    */   private String attributeName;
/*    */   private Object attribute;
/*    */ 
/*    */   public void setAttributeName(String attributeName)
/*    */   {
/* 55 */     this.attributeName = attributeName;
/*    */   }
/*    */ 
/*    */   public void setServletContext(ServletContext servletContext) {
/* 59 */     if (this.attributeName == null) {
/* 60 */       throw new IllegalArgumentException("Property 'attributeName' is required");
/*    */     }
/* 62 */     this.attribute = servletContext.getAttribute(this.attributeName);
/* 63 */     if (this.attribute == null)
/* 64 */       throw new IllegalStateException("No ServletContext attribute '" + this.attributeName + "' found");
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */     throws Exception
/*    */   {
/* 70 */     return this.attribute;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 74 */     return this.attribute != null ? this.attribute.getClass() : null;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 78 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextAttributeFactoryBean
 * JD-Core Version:    0.6.1
 */