/*    */ package org.springframework.web.filter;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.NDC;
/*    */ 
/*    */ public class Log4jNestedDiagnosticContextFilter extends AbstractRequestLoggingFilter
/*    */ {
/* 43 */   protected final Logger log4jLogger = Logger.getLogger(getClass());
/*    */ 
/*    */   protected void beforeRequest(HttpServletRequest request, String message)
/*    */   {
/* 52 */     if (this.log4jLogger.isDebugEnabled()) {
/* 53 */       this.log4jLogger.debug(message);
/*    */     }
/* 55 */     NDC.push(getNestedDiagnosticContextMessage(request));
/*    */   }
/*    */ 
/*    */   protected String getNestedDiagnosticContextMessage(HttpServletRequest request)
/*    */   {
/* 66 */     return createMessage(request, "", "");
/*    */   }
/*    */ 
/*    */   protected void afterRequest(HttpServletRequest request, String message)
/*    */   {
/* 75 */     NDC.pop();
/* 76 */     if (NDC.getDepth() == 0) {
/* 77 */       NDC.remove();
/*    */     }
/* 79 */     if (this.log4jLogger.isDebugEnabled())
/* 80 */       this.log4jLogger.debug(message);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.Log4jNestedDiagnosticContextFilter
 * JD-Core Version:    0.6.1
 */