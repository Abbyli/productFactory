/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItem;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class CommonsMultipartFile
/*     */   implements MultipartFile, Serializable
/*     */ {
/*  43 */   protected static final Log logger = LogFactory.getLog(CommonsMultipartFile.class);
/*     */   private final FileItem fileItem;
/*     */   private final long size;
/*     */ 
/*     */   public CommonsMultipartFile(FileItem fileItem)
/*     */   {
/*  55 */     this.fileItem = fileItem;
/*  56 */     this.size = this.fileItem.getSize();
/*     */   }
/*     */ 
/*     */   public final FileItem getFileItem()
/*     */   {
/*  64 */     return this.fileItem;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  69 */     return this.fileItem.getFieldName();
/*     */   }
/*     */ 
/*     */   public String getOriginalFilename() {
/*  73 */     String filename = this.fileItem.getName();
/*  74 */     if (filename == null)
/*     */     {
/*  76 */       return "";
/*     */     }
/*     */ 
/*  79 */     int pos = filename.lastIndexOf("/");
/*  80 */     if (pos == -1)
/*     */     {
/*  82 */       pos = filename.lastIndexOf("\\");
/*     */     }
/*  84 */     if (pos != -1)
/*     */     {
/*  86 */       return filename.substring(pos + 1);
/*     */     }
/*     */ 
/*  90 */     return filename;
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*  95 */     return this.fileItem.getContentType();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty() {
/*  99 */     return this.size == 0L;
/*     */   }
/*     */ 
/*     */   public long getSize() {
/* 103 */     return this.size;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes() {
/* 107 */     if (!isAvailable()) {
/* 108 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 110 */     byte[] bytes = this.fileItem.get();
/* 111 */     return bytes != null ? bytes : new byte[0];
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream() throws IOException {
/* 115 */     if (!isAvailable()) {
/* 116 */       throw new IllegalStateException("File has been moved - cannot be read again");
/*     */     }
/* 118 */     InputStream inputStream = this.fileItem.getInputStream();
/* 119 */     return inputStream != null ? inputStream : new ByteArrayInputStream(new byte[0]);
/*     */   }
/*     */ 
/*     */   public void transferTo(File dest) throws IOException, IllegalStateException {
/* 123 */     if (!isAvailable()) {
/* 124 */       throw new IllegalStateException("File has already been moved - cannot be transferred again");
/*     */     }
/*     */ 
/* 127 */     if ((dest.exists()) && (!dest.delete())) {
/* 128 */       throw new IOException("Destination file [" + dest.getAbsolutePath() + "] already exists and could not be deleted");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 133 */       this.fileItem.write(dest);
/* 134 */       if (logger.isDebugEnabled()) {
/* 135 */         String action = "transferred";
/* 136 */         if (!this.fileItem.isInMemory()) {
/* 137 */           action = isAvailable() ? "copied" : "moved";
/*     */         }
/* 139 */         logger.debug("Multipart file '" + getName() + "' with original filename [" + getOriginalFilename() + "], stored " + getStorageDescription() + ": " + action + " to [" + dest.getAbsolutePath() + "]");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (FileUploadException ex)
/*     */     {
/* 145 */       throw new IllegalStateException(ex.getMessage());
/*     */     }
/*     */     catch (IOException ex) {
/* 148 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/* 151 */       logger.error("Could not transfer to file", ex);
/* 152 */       throw new IOException("Could not transfer to file: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isAvailable()
/*     */   {
/* 162 */     if (this.fileItem.isInMemory()) {
/* 163 */       return true;
/*     */     }
/*     */ 
/* 166 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 167 */       return ((DiskFileItem)this.fileItem).getStoreLocation().exists();
/*     */     }
/*     */ 
/* 170 */     return this.fileItem.getSize() == this.size;
/*     */   }
/*     */ 
/*     */   public String getStorageDescription()
/*     */   {
/* 179 */     if (this.fileItem.isInMemory()) {
/* 180 */       return "in memory";
/*     */     }
/* 182 */     if ((this.fileItem instanceof DiskFileItem)) {
/* 183 */       return "at [" + ((DiskFileItem)this.fileItem).getStoreLocation().getAbsolutePath() + "]";
/*     */     }
/*     */ 
/* 186 */     return "on disk";
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.commons.CommonsMultipartFile
 * JD-Core Version:    0.6.1
 */