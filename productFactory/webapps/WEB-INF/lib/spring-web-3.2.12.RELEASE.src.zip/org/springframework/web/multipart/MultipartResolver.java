package org.springframework.web.multipart;

import javax.servlet.http.HttpServletRequest;

public abstract interface MultipartResolver
{
  public abstract boolean isMultipart(HttpServletRequest paramHttpServletRequest);

  public abstract MultipartHttpServletRequest resolveMultipart(HttpServletRequest paramHttpServletRequest)
    throws MultipartException;

  public abstract void cleanupMultipart(MultipartHttpServletRequest paramMultipartHttpServletRequest);
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.MultipartResolver
 * JD-Core Version:    0.6.1
 */