/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ 
/*     */ public abstract class AbstractMultipartHttpServletRequest extends HttpServletRequestWrapper
/*     */   implements MultipartHttpServletRequest
/*     */ {
/*     */   private MultiValueMap<String, MultipartFile> multipartFiles;
/*     */ 
/*     */   protected AbstractMultipartHttpServletRequest(HttpServletRequest request)
/*     */   {
/*  53 */     super(request);
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getRequest()
/*     */   {
/*  59 */     return (HttpServletRequest)super.getRequest();
/*     */   }
/*     */ 
/*     */   public HttpMethod getRequestMethod() {
/*  63 */     return HttpMethod.valueOf(getRequest().getMethod());
/*     */   }
/*     */ 
/*     */   public HttpHeaders getRequestHeaders() {
/*  67 */     HttpHeaders headers = new HttpHeaders();
/*  68 */     Enumeration headerNames = getHeaderNames();
/*  69 */     while (headerNames.hasMoreElements()) {
/*  70 */       String headerName = (String)headerNames.nextElement();
/*  71 */       headers.put(headerName, Collections.list(getHeaders(headerName)));
/*     */     }
/*  73 */     return headers;
/*     */   }
/*     */ 
/*     */   public Iterator<String> getFileNames() {
/*  77 */     return getMultipartFiles().keySet().iterator();
/*     */   }
/*     */ 
/*     */   public MultipartFile getFile(String name) {
/*  81 */     return (MultipartFile)getMultipartFiles().getFirst(name);
/*     */   }
/*     */ 
/*     */   public List<MultipartFile> getFiles(String name) {
/*  85 */     List multipartFiles = (List)getMultipartFiles().get(name);
/*  86 */     if (multipartFiles != null) {
/*  87 */       return multipartFiles;
/*     */     }
/*     */ 
/*  90 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   public Map<String, MultipartFile> getFileMap()
/*     */   {
/*  95 */     return getMultipartFiles().toSingleValueMap();
/*     */   }
/*     */ 
/*     */   public MultiValueMap<String, MultipartFile> getMultiFileMap() {
/*  99 */     return getMultipartFiles();
/*     */   }
/*     */ 
/*     */   protected final void setMultipartFiles(MultiValueMap<String, MultipartFile> multipartFiles)
/*     */   {
/* 108 */     this.multipartFiles = new LinkedMultiValueMap(Collections.unmodifiableMap(multipartFiles));
/*     */   }
/*     */ 
/*     */   protected MultiValueMap<String, MultipartFile> getMultipartFiles()
/*     */   {
/* 118 */     if (this.multipartFiles == null) {
/* 119 */       initializeMultipart();
/*     */     }
/* 121 */     return this.multipartFiles;
/*     */   }
/*     */ 
/*     */   protected void initializeMultipart()
/*     */   {
/* 129 */     throw new IllegalStateException("Multipart request not initialized");
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.AbstractMultipartHttpServletRequest
 * JD-Core Version:    0.6.1
 */