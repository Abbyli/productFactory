/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ public class ServletContextAttributeExporter
/*    */   implements ServletContextAware
/*    */ {
/* 49 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   private Map<String, Object> attributes;
/*    */ 
/*    */   public void setAttributes(Map<String, Object> attributes)
/*    */   {
/* 63 */     this.attributes = attributes;
/*    */   }
/*    */ 
/*    */   public void setServletContext(ServletContext servletContext) {
/* 67 */     for (Map.Entry entry : this.attributes.entrySet()) {
/* 68 */       String attributeName = (String)entry.getKey();
/* 69 */       if ((this.logger.isWarnEnabled()) && 
/* 70 */         (servletContext.getAttribute(attributeName) != null)) {
/* 71 */         this.logger.warn("Replacing existing ServletContext attribute with name '" + attributeName + "'");
/*    */       }
/*    */ 
/* 74 */       servletContext.setAttribute(attributeName, entry.getValue());
/* 75 */       if (this.logger.isInfoEnabled())
/* 76 */         this.logger.info("Exported ServletContext attribute with name '" + attributeName + "'");
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextAttributeExporter
 * JD-Core Version:    0.6.1
 */