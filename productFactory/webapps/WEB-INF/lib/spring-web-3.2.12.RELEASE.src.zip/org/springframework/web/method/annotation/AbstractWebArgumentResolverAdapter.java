/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*     */ import org.springframework.web.method.support.ModelAndViewContainer;
/*     */ 
/*     */ public abstract class AbstractWebArgumentResolverAdapter
/*     */   implements HandlerMethodArgumentResolver
/*     */ {
/*  50 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   private final WebArgumentResolver adaptee;
/*     */ 
/*     */   public AbstractWebArgumentResolverAdapter(WebArgumentResolver adaptee)
/*     */   {
/*  58 */     Assert.notNull(adaptee, "'adaptee' must not be null");
/*  59 */     this.adaptee = adaptee;
/*     */   }
/*     */ 
/*     */   public boolean supportsParameter(MethodParameter parameter)
/*     */   {
/*     */     try
/*     */     {
/*  68 */       NativeWebRequest webRequest = getWebRequest();
/*  69 */       Object result = this.adaptee.resolveArgument(parameter, webRequest);
/*  70 */       if (result == WebArgumentResolver.UNRESOLVED) {
/*  71 */         return false;
/*     */       }
/*     */ 
/*  74 */       return ClassUtils.isAssignableValue(parameter.getParameterType(), result);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  79 */       this.logger.debug("Error in checking support for parameter [" + parameter + "], message: " + ex.getMessage());
/*  80 */     }return false;
/*     */   }
/*     */ 
/*     */   protected abstract NativeWebRequest getWebRequest();
/*     */ 
/*     */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*     */     throws Exception
/*     */   {
/*  99 */     Class paramType = parameter.getParameterType();
/* 100 */     Object result = this.adaptee.resolveArgument(parameter, webRequest);
/* 101 */     if ((result == WebArgumentResolver.UNRESOLVED) || (!ClassUtils.isAssignableValue(paramType, result))) {
/* 102 */       throw new IllegalStateException("Standard argument type [" + paramType.getName() + "] in method " + parameter.getMethod() + "resolved to incompatible value of type [" + (result != null ? result.getClass() : null) + "]. Consider declaring the argument type in a less specific fashion.");
/*     */     }
/*     */ 
/* 107 */     return result;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.AbstractWebArgumentResolverAdapter
 * JD-Core Version:    0.6.1
 */