/*     */ package org.springframework.web.bind;
/*     */ 
/*     */ import javax.servlet.ServletRequest;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletRequestDataBinder extends WebDataBinder
/*     */ {
/*     */   public ServletRequestDataBinder(Object target)
/*     */   {
/*  73 */     super(target);
/*     */   }
/*     */ 
/*     */   public ServletRequestDataBinder(Object target, String objectName)
/*     */   {
/*  83 */     super(target, objectName);
/*     */   }
/*     */ 
/*     */   public void bind(ServletRequest request)
/*     */   {
/* 106 */     MutablePropertyValues mpvs = new ServletRequestParameterPropertyValues(request);
/* 107 */     MultipartRequest multipartRequest = (MultipartRequest)WebUtils.getNativeRequest(request, MultipartRequest.class);
/* 108 */     if (multipartRequest != null) {
/* 109 */       bindMultipart(multipartRequest.getMultiFileMap(), mpvs);
/*     */     }
/* 111 */     addBindValues(mpvs, request);
/* 112 */     doBind(mpvs);
/*     */   }
/*     */ 
/*     */   protected void addBindValues(MutablePropertyValues mpvs, ServletRequest request)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void closeNoCatch()
/*     */     throws ServletRequestBindingException
/*     */   {
/* 132 */     if (getBindingResult().hasErrors())
/* 133 */       throw new ServletRequestBindingException("Errors binding onto object '" + getBindingResult().getObjectName() + "'", new BindException(getBindingResult()));
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.ServletRequestDataBinder
 * JD-Core Version:    0.6.1
 */