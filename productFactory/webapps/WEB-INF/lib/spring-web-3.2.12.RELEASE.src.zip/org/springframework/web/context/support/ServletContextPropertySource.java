/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.core.env.EnumerablePropertySource;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class ServletContextPropertySource extends EnumerablePropertySource<ServletContext>
/*    */ {
/*    */   public ServletContextPropertySource(String name, ServletContext servletContext)
/*    */   {
/* 35 */     super(name, servletContext);
/*    */   }
/*    */ 
/*    */   public String[] getPropertyNames()
/*    */   {
/* 40 */     return StringUtils.toStringArray(((ServletContext)this.source).getInitParameterNames());
/*    */   }
/*    */ 
/*    */   public String getProperty(String name)
/*    */   {
/* 45 */     return ((ServletContext)this.source).getInitParameter(name);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextPropertySource
 * JD-Core Version:    0.6.1
 */