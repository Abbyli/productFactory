/*     */ package org.springframework.web.bind.annotation.support;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.web.bind.annotation.InitBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.RequestMapping;
/*     */ import org.springframework.web.bind.annotation.SessionAttributes;
/*     */ 
/*     */ public class HandlerMethodResolver
/*     */ {
/*  54 */   private final Set<Method> handlerMethods = new LinkedHashSet();
/*     */ 
/*  56 */   private final Set<Method> initBinderMethods = new LinkedHashSet();
/*     */ 
/*  58 */   private final Set<Method> modelAttributeMethods = new LinkedHashSet();
/*     */   private RequestMapping typeLevelMapping;
/*     */   private boolean sessionAttributesFound;
/*  64 */   private final Set<String> sessionAttributeNames = new HashSet();
/*     */ 
/*  66 */   private final Set<Class> sessionAttributeTypes = new HashSet();
/*     */ 
/*  69 */   private final Map<String, Boolean> actualSessionAttributeNames = new ConcurrentHashMap(4);
/*     */ 
/*     */   public void init(Class<?> handlerType)
/*     */   {
/*  77 */     Set handlerTypes = new LinkedHashSet();
/*  78 */     Class specificHandlerType = null;
/*  79 */     if (!Proxy.isProxyClass(handlerType)) {
/*  80 */       handlerTypes.add(handlerType);
/*  81 */       specificHandlerType = handlerType;
/*     */     }
/*  83 */     handlerTypes.addAll(Arrays.asList(handlerType.getInterfaces()));
/*  84 */     for (Class currentHandlerType : handlerTypes) {
/*  85 */       final Class targetClass = specificHandlerType != null ? specificHandlerType : currentHandlerType;
/*  86 */       ReflectionUtils.doWithMethods(currentHandlerType, new ReflectionUtils.MethodCallback() {
/*     */         public void doWith(Method method) {
/*  88 */           Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/*  89 */           Method bridgedMethod = BridgeMethodResolver.findBridgedMethod(specificMethod);
/*  90 */           if ((HandlerMethodResolver.this.isHandlerMethod(specificMethod)) && ((bridgedMethod == specificMethod) || (!HandlerMethodResolver.this.isHandlerMethod(bridgedMethod))))
/*     */           {
/*  92 */             HandlerMethodResolver.this.handlerMethods.add(specificMethod);
/*     */           }
/*  94 */           else if ((HandlerMethodResolver.this.isInitBinderMethod(specificMethod)) && ((bridgedMethod == specificMethod) || (!HandlerMethodResolver.this.isInitBinderMethod(bridgedMethod))))
/*     */           {
/*  96 */             HandlerMethodResolver.this.initBinderMethods.add(specificMethod);
/*     */           }
/*  98 */           else if ((HandlerMethodResolver.this.isModelAttributeMethod(specificMethod)) && ((bridgedMethod == specificMethod) || (!HandlerMethodResolver.this.isModelAttributeMethod(bridgedMethod))))
/*     */           {
/* 100 */             HandlerMethodResolver.this.modelAttributeMethods.add(specificMethod);
/*     */           }
/*     */         }
/*     */       }
/*     */       , ReflectionUtils.USER_DECLARED_METHODS);
/*     */     }
/*     */ 
/* 105 */     this.typeLevelMapping = ((RequestMapping)AnnotationUtils.findAnnotation(handlerType, RequestMapping.class));
/* 106 */     SessionAttributes sessionAttributes = (SessionAttributes)AnnotationUtils.findAnnotation(handlerType, SessionAttributes.class);
/* 107 */     this.sessionAttributesFound = (sessionAttributes != null);
/* 108 */     if (this.sessionAttributesFound) {
/* 109 */       this.sessionAttributeNames.addAll(Arrays.asList(sessionAttributes.value()));
/* 110 */       this.sessionAttributeTypes.addAll(Arrays.asList(sessionAttributes.types()));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isHandlerMethod(Method method) {
/* 115 */     return AnnotationUtils.findAnnotation(method, RequestMapping.class) != null;
/*     */   }
/*     */ 
/*     */   protected boolean isInitBinderMethod(Method method) {
/* 119 */     return AnnotationUtils.findAnnotation(method, InitBinder.class) != null;
/*     */   }
/*     */ 
/*     */   protected boolean isModelAttributeMethod(Method method) {
/* 123 */     return AnnotationUtils.findAnnotation(method, ModelAttribute.class) != null;
/*     */   }
/*     */ 
/*     */   public final boolean hasHandlerMethods()
/*     */   {
/* 128 */     return !this.handlerMethods.isEmpty();
/*     */   }
/*     */ 
/*     */   public final Set<Method> getHandlerMethods() {
/* 132 */     return this.handlerMethods;
/*     */   }
/*     */ 
/*     */   public final Set<Method> getInitBinderMethods() {
/* 136 */     return this.initBinderMethods;
/*     */   }
/*     */ 
/*     */   public final Set<Method> getModelAttributeMethods() {
/* 140 */     return this.modelAttributeMethods;
/*     */   }
/*     */ 
/*     */   public boolean hasTypeLevelMapping() {
/* 144 */     return this.typeLevelMapping != null;
/*     */   }
/*     */ 
/*     */   public RequestMapping getTypeLevelMapping() {
/* 148 */     return this.typeLevelMapping;
/*     */   }
/*     */ 
/*     */   public boolean hasSessionAttributes() {
/* 152 */     return this.sessionAttributesFound;
/*     */   }
/*     */ 
/*     */   public boolean isSessionAttribute(String attrName, Class attrType) {
/* 156 */     if ((this.sessionAttributeNames.contains(attrName)) || (this.sessionAttributeTypes.contains(attrType))) {
/* 157 */       this.actualSessionAttributeNames.put(attrName, Boolean.TRUE);
/* 158 */       return true;
/*     */     }
/*     */ 
/* 161 */     return false;
/*     */   }
/*     */ 
/*     */   public Set<String> getActualSessionAttributeNames()
/*     */   {
/* 166 */     return this.actualSessionAttributeNames.keySet();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.support.HandlerMethodResolver
 * JD-Core Version:    0.6.1
 */