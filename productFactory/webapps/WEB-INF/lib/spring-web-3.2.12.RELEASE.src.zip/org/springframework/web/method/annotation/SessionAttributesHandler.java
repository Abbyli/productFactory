/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.bind.annotation.SessionAttributes;
/*     */ import org.springframework.web.bind.support.SessionAttributeStore;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ 
/*     */ public class SessionAttributesHandler
/*     */ {
/*  49 */   private final Set<String> attributeNames = new HashSet();
/*     */ 
/*  51 */   private final Set<Class<?>> attributeTypes = new HashSet();
/*     */ 
/*  54 */   private final Map<String, Boolean> knownAttributeNames = new ConcurrentHashMap(4);
/*     */   private final SessionAttributeStore sessionAttributeStore;
/*     */ 
/*     */   public SessionAttributesHandler(Class<?> handlerType, SessionAttributeStore sessionAttributeStore)
/*     */   {
/*  67 */     Assert.notNull(sessionAttributeStore, "SessionAttributeStore may not be null.");
/*  68 */     this.sessionAttributeStore = sessionAttributeStore;
/*     */ 
/*  70 */     SessionAttributes annotation = (SessionAttributes)AnnotationUtils.findAnnotation(handlerType, SessionAttributes.class);
/*  71 */     if (annotation != null) {
/*  72 */       this.attributeNames.addAll(Arrays.asList(annotation.value()));
/*  73 */       this.attributeTypes.addAll(Arrays.asList(annotation.types()));
/*     */     }
/*     */ 
/*  76 */     for (String attributeName : this.attributeNames)
/*  77 */       this.knownAttributeNames.put(attributeName, Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   public boolean hasSessionAttributes()
/*     */   {
/*  86 */     return (this.attributeNames.size() > 0) || (this.attributeTypes.size() > 0);
/*     */   }
/*     */ 
/*     */   public boolean isHandlerSessionAttribute(String attributeName, Class<?> attributeType)
/*     */   {
/* 101 */     Assert.notNull(attributeName, "Attribute name must not be null");
/* 102 */     if ((this.attributeNames.contains(attributeName)) || (this.attributeTypes.contains(attributeType))) {
/* 103 */       this.knownAttributeNames.put(attributeName, Boolean.TRUE);
/* 104 */       return true;
/*     */     }
/*     */ 
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   public void storeAttributes(WebRequest request, Map<String, ?> attributes)
/*     */   {
/* 118 */     for (String name : attributes.keySet()) {
/* 119 */       Object value = attributes.get(name);
/* 120 */       Class attrType = value != null ? value.getClass() : null;
/*     */ 
/* 122 */       if (isHandlerSessionAttribute(name, attrType))
/* 123 */         this.sessionAttributeStore.storeAttribute(request, name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map<String, Object> retrieveAttributes(WebRequest request)
/*     */   {
/* 136 */     Map attributes = new HashMap();
/* 137 */     for (String name : this.knownAttributeNames.keySet()) {
/* 138 */       Object value = this.sessionAttributeStore.retrieveAttribute(request, name);
/* 139 */       if (value != null) {
/* 140 */         attributes.put(name, value);
/*     */       }
/*     */     }
/* 143 */     return attributes;
/*     */   }
/*     */ 
/*     */   public void cleanupAttributes(WebRequest request)
/*     */   {
/* 153 */     for (String attributeName : this.knownAttributeNames.keySet())
/* 154 */       this.sessionAttributeStore.cleanupAttribute(request, attributeName);
/*     */   }
/*     */ 
/*     */   Object retrieveAttribute(WebRequest request, String attributeName)
/*     */   {
/* 165 */     return this.sessionAttributeStore.retrieveAttribute(request, attributeName);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.SessionAttributesHandler
 * JD-Core Version:    0.6.1
 */