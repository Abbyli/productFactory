/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.request.WebRequest;
/*    */ 
/*    */ public class DefaultSessionAttributeStore
/*    */   implements SessionAttributeStore
/*    */ {
/* 36 */   private String attributeNamePrefix = "";
/*    */ 
/*    */   public void setAttributeNamePrefix(String attributeNamePrefix)
/*    */   {
/* 45 */     this.attributeNamePrefix = (attributeNamePrefix != null ? attributeNamePrefix : "");
/*    */   }
/*    */ 
/*    */   public void storeAttribute(WebRequest request, String attributeName, Object attributeValue)
/*    */   {
/* 50 */     Assert.notNull(request, "WebRequest must not be null");
/* 51 */     Assert.notNull(attributeName, "Attribute name must not be null");
/* 52 */     Assert.notNull(attributeValue, "Attribute value must not be null");
/* 53 */     String storeAttributeName = getAttributeNameInSession(request, attributeName);
/* 54 */     request.setAttribute(storeAttributeName, attributeValue, 1);
/*    */   }
/*    */ 
/*    */   public Object retrieveAttribute(WebRequest request, String attributeName) {
/* 58 */     Assert.notNull(request, "WebRequest must not be null");
/* 59 */     Assert.notNull(attributeName, "Attribute name must not be null");
/* 60 */     String storeAttributeName = getAttributeNameInSession(request, attributeName);
/* 61 */     return request.getAttribute(storeAttributeName, 1);
/*    */   }
/*    */ 
/*    */   public void cleanupAttribute(WebRequest request, String attributeName) {
/* 65 */     Assert.notNull(request, "WebRequest must not be null");
/* 66 */     Assert.notNull(attributeName, "Attribute name must not be null");
/* 67 */     String storeAttributeName = getAttributeNameInSession(request, attributeName);
/* 68 */     request.removeAttribute(storeAttributeName, 1);
/*    */   }
/*    */ 
/*    */   protected String getAttributeNameInSession(WebRequest request, String attributeName)
/*    */   {
/* 81 */     return this.attributeNamePrefix + attributeName;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.DefaultSessionAttributeStore
 * JD-Core Version:    0.6.1
 */