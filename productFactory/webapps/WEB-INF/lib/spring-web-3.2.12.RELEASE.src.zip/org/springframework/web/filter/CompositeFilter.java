/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ 
/*     */ public class CompositeFilter
/*     */   implements Filter
/*     */ {
/*     */   private List<? extends Filter> filters;
/*     */ 
/*     */   public CompositeFilter()
/*     */   {
/*  44 */     this.filters = new ArrayList();
/*     */   }
/*     */ 
/*     */   public void setFilters(List<? extends Filter> filters) {
/*  48 */     this.filters = new ArrayList(filters);
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig config)
/*     */     throws ServletException
/*     */   {
/*  57 */     for (Filter filter : this.filters)
/*  58 */       filter.init(config);
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
/*     */     throws IOException, ServletException
/*     */   {
/*  71 */     new VirtualFilterChain(chain, this.filters).doFilter(request, response);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  79 */     for (int i = this.filters.size(); i-- > 0; ) {
/*  80 */       Filter filter = (Filter)this.filters.get(i);
/*  81 */       filter.destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class VirtualFilterChain
/*     */     implements FilterChain
/*     */   {
/*     */     private final FilterChain originalChain;
/*     */     private final List<? extends Filter> additionalFilters;
/*  92 */     private int currentPosition = 0;
/*     */ 
/*     */     public VirtualFilterChain(FilterChain chain, List<? extends Filter> additionalFilters) {
/*  95 */       this.originalChain = chain;
/*  96 */       this.additionalFilters = additionalFilters;
/*     */     }
/*     */ 
/*     */     public void doFilter(ServletRequest request, ServletResponse response)
/*     */       throws IOException, ServletException
/*     */     {
/* 102 */       if (this.currentPosition == this.additionalFilters.size()) {
/* 103 */         this.originalChain.doFilter(request, response);
/*     */       }
/*     */       else {
/* 106 */         this.currentPosition += 1;
/* 107 */         Filter nextFilter = (Filter)this.additionalFilters.get(this.currentPosition - 1);
/* 108 */         nextFilter.doFilter(request, response, this);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.CompositeFilter
 * JD-Core Version:    0.6.1
 */