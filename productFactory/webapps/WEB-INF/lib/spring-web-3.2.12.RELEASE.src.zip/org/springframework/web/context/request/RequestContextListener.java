/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletRequestEvent;
/*    */ import javax.servlet.ServletRequestListener;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ 
/*    */ public class RequestContextListener
/*    */   implements ServletRequestListener
/*    */ {
/* 48 */   private static final String REQUEST_ATTRIBUTES_ATTRIBUTE = RequestContextListener.class.getName() + ".REQUEST_ATTRIBUTES";
/*    */ 
/*    */   public void requestInitialized(ServletRequestEvent requestEvent)
/*    */   {
/* 53 */     if (!(requestEvent.getServletRequest() instanceof HttpServletRequest)) {
/* 54 */       throw new IllegalArgumentException("Request is not an HttpServletRequest: " + requestEvent.getServletRequest());
/*    */     }
/*    */ 
/* 57 */     HttpServletRequest request = (HttpServletRequest)requestEvent.getServletRequest();
/* 58 */     ServletRequestAttributes attributes = new ServletRequestAttributes(request);
/* 59 */     request.setAttribute(REQUEST_ATTRIBUTES_ATTRIBUTE, attributes);
/* 60 */     LocaleContextHolder.setLocale(request.getLocale());
/* 61 */     RequestContextHolder.setRequestAttributes(attributes);
/*    */   }
/*    */ 
/*    */   public void requestDestroyed(ServletRequestEvent requestEvent) {
/* 65 */     ServletRequestAttributes attributes = null;
/* 66 */     Object reqAttr = requestEvent.getServletRequest().getAttribute(REQUEST_ATTRIBUTES_ATTRIBUTE);
/* 67 */     if ((reqAttr instanceof ServletRequestAttributes)) {
/* 68 */       attributes = (ServletRequestAttributes)reqAttr;
/*    */     }
/* 70 */     RequestAttributes threadAttributes = RequestContextHolder.getRequestAttributes();
/* 71 */     if (threadAttributes != null)
/*    */     {
/* 73 */       LocaleContextHolder.resetLocaleContext();
/* 74 */       RequestContextHolder.resetRequestAttributes();
/* 75 */       if ((attributes == null) && ((threadAttributes instanceof ServletRequestAttributes))) {
/* 76 */         attributes = (ServletRequestAttributes)threadAttributes;
/*    */       }
/*    */     }
/* 79 */     if (attributes != null)
/* 80 */       attributes.requestCompleted();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.RequestContextListener
 * JD-Core Version:    0.6.1
 */