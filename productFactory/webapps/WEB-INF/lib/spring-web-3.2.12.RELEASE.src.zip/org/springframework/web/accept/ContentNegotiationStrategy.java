package org.springframework.web.accept;

import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.context.request.NativeWebRequest;

public abstract interface ContentNegotiationStrategy
{
  public abstract List<MediaType> resolveMediaTypes(NativeWebRequest paramNativeWebRequest)
    throws HttpMediaTypeNotAcceptableException;
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ContentNegotiationStrategy
 * JD-Core Version:    0.6.1
 */