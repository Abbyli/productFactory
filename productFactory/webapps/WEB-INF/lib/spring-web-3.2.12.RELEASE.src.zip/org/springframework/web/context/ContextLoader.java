/*     */ package org.springframework.web.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.access.BeanFactoryLocator;
/*     */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ApplicationContextInitializer;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.access.ContextSingletonBeanFactoryLocator;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ContextLoader
/*     */ {
/*     */   public static final String CONTEXT_ID_PARAM = "contextId";
/*     */   public static final String CONFIG_LOCATION_PARAM = "contextConfigLocation";
/*     */   public static final String CONTEXT_CLASS_PARAM = "contextClass";
/*     */   public static final String CONTEXT_INITIALIZER_CLASSES_PARAM = "contextInitializerClasses";
/*     */   public static final String GLOBAL_INITIALIZER_CLASSES_PARAM = "globalInitializerClasses";
/*     */   public static final String LOCATOR_FACTORY_SELECTOR_PARAM = "locatorFactorySelector";
/*     */   public static final String LOCATOR_FACTORY_KEY_PARAM = "parentContextKey";
/*     */   private static final String INIT_PARAM_DELIMITERS = ",; \t\n";
/*     */   private static final String DEFAULT_STRATEGIES_PATH = "ContextLoader.properties";
/*     */   private static final Properties defaultStrategies;
/* 188 */   private static final Map<ClassLoader, WebApplicationContext> currentContextPerThread = new ConcurrentHashMap(1);
/*     */   private static volatile WebApplicationContext currentContext;
/*     */   private WebApplicationContext context;
/*     */   private BeanFactoryReference parentContextRef;
/*     */ 
/*     */   public ContextLoader()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContextLoader(WebApplicationContext context)
/*     */   {
/* 261 */     this.context = context;
/*     */   }
/*     */ 
/*     */   public WebApplicationContext initWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 276 */     if (servletContext.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE) != null) {
/* 277 */       throw new IllegalStateException("Cannot initialize context because there is already a root application context present - check whether you have multiple ContextLoader* definitions in your web.xml!");
/*     */     }
/*     */ 
/* 282 */     Log logger = LogFactory.getLog(ContextLoader.class);
/* 283 */     servletContext.log("Initializing Spring root WebApplicationContext");
/* 284 */     if (logger.isInfoEnabled()) {
/* 285 */       logger.info("Root WebApplicationContext: initialization started");
/*     */     }
/* 287 */     long startTime = System.currentTimeMillis();
/*     */     try
/*     */     {
/* 292 */       if (this.context == null) {
/* 293 */         this.context = createWebApplicationContext(servletContext);
/*     */       }
/* 295 */       if ((this.context instanceof ConfigurableWebApplicationContext)) {
/* 296 */         ConfigurableWebApplicationContext cwac = (ConfigurableWebApplicationContext)this.context;
/* 297 */         if (!cwac.isActive())
/*     */         {
/* 300 */           if (cwac.getParent() == null)
/*     */           {
/* 303 */             ApplicationContext parent = loadParentContext(servletContext);
/* 304 */             cwac.setParent(parent);
/*     */           }
/* 306 */           configureAndRefreshWebApplicationContext(cwac, servletContext);
/*     */         }
/*     */       }
/* 309 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, this.context);
/*     */ 
/* 311 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 312 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 313 */         currentContext = this.context;
/*     */       }
/* 315 */       else if (ccl != null) {
/* 316 */         currentContextPerThread.put(ccl, this.context);
/*     */       }
/*     */ 
/* 319 */       if (logger.isDebugEnabled()) {
/* 320 */         logger.debug("Published root WebApplicationContext as ServletContext attribute with name [" + WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE + "]");
/*     */       }
/*     */ 
/* 323 */       if (logger.isInfoEnabled()) {
/* 324 */         long elapsedTime = System.currentTimeMillis() - startTime;
/* 325 */         logger.info("Root WebApplicationContext: initialization completed in " + elapsedTime + " ms");
/*     */       }
/*     */ 
/* 328 */       return this.context;
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 331 */       logger.error("Context initialization failed", ex);
/* 332 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, ex);
/* 333 */       throw ex;
/*     */     }
/*     */     catch (Error err) {
/* 336 */       logger.error("Context initialization failed", err);
/* 337 */       servletContext.setAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE, err);
/* 338 */       throw err;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc)
/*     */   {
/* 355 */     Class contextClass = determineContextClass(sc);
/* 356 */     if (!ConfigurableWebApplicationContext.class.isAssignableFrom(contextClass)) {
/* 357 */       throw new ApplicationContextException("Custom context class [" + contextClass.getName() + "] is not of type [" + ConfigurableWebApplicationContext.class.getName() + "]");
/*     */     }
/*     */ 
/* 360 */     return (ConfigurableWebApplicationContext)BeanUtils.instantiateClass(contextClass);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected WebApplicationContext createWebApplicationContext(ServletContext sc, ApplicationContext parent)
/*     */   {
/* 370 */     return createWebApplicationContext(sc);
/*     */   }
/*     */ 
/*     */   protected void configureAndRefreshWebApplicationContext(ConfigurableWebApplicationContext wac, ServletContext sc) {
/* 374 */     if (ObjectUtils.identityToString(wac).equals(wac.getId()))
/*     */     {
/* 377 */       String idParam = sc.getInitParameter("contextId");
/* 378 */       if (idParam != null) {
/* 379 */         wac.setId(idParam);
/*     */       }
/* 383 */       else if ((sc.getMajorVersion() == 2) && (sc.getMinorVersion() < 5))
/*     */       {
/* 385 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + ObjectUtils.getDisplayString(sc.getServletContextName()));
/*     */       }
/*     */       else
/*     */       {
/* 389 */         wac.setId(ConfigurableWebApplicationContext.APPLICATION_CONTEXT_ID_PREFIX + ObjectUtils.getDisplayString(sc.getContextPath()));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 395 */     wac.setServletContext(sc);
/* 396 */     String configLocationParam = sc.getInitParameter("contextConfigLocation");
/* 397 */     if (configLocationParam != null) {
/* 398 */       wac.setConfigLocation(configLocationParam);
/*     */     }
/*     */ 
/* 404 */     ConfigurableEnvironment env = wac.getEnvironment();
/* 405 */     if ((env instanceof ConfigurableWebEnvironment)) {
/* 406 */       ((ConfigurableWebEnvironment)env).initPropertySources(sc, null);
/*     */     }
/*     */ 
/* 409 */     customizeContext(sc, wac);
/* 410 */     wac.refresh();
/*     */   }
/*     */ 
/*     */   protected void customizeContext(ServletContext sc, ConfigurableWebApplicationContext wac)
/*     */   {
/* 432 */     List initializerClasses = determineContextInitializerClasses(sc);
/*     */ 
/* 434 */     if (initializerClasses.isEmpty())
/*     */     {
/* 436 */       return;
/*     */     }
/*     */ 
/* 439 */     ArrayList initializerInstances = new ArrayList();
/*     */ 
/* 442 */     for (Class initializerClass : initializerClasses) {
/* 443 */       Class initializerContextClass = GenericTypeResolver.resolveTypeArgument(initializerClass, ApplicationContextInitializer.class);
/*     */ 
/* 445 */       if (initializerContextClass != null) {
/* 446 */         Assert.isAssignable(initializerContextClass, wac.getClass(), String.format("Could not add context initializer [%s] since its generic parameter [%s] is not assignable from the type of application context used by this context loader [%s]: ", new Object[] { initializerClass.getName(), initializerContextClass.getName(), wac.getClass().getName() }));
/*     */       }
/*     */ 
/* 452 */       initializerInstances.add(BeanUtils.instantiateClass(initializerClass));
/*     */     }
/*     */ 
/* 455 */     AnnotationAwareOrderComparator.sort(initializerInstances);
/* 456 */     for (ApplicationContextInitializer initializer : initializerInstances)
/* 457 */       initializer.initialize(wac);
/*     */   }
/*     */ 
/*     */   protected Class<?> determineContextClass(ServletContext servletContext)
/*     */   {
/* 470 */     String contextClassName = servletContext.getInitParameter("contextClass");
/* 471 */     if (contextClassName != null) {
/*     */       try {
/* 473 */         return ClassUtils.forName(contextClassName, ClassUtils.getDefaultClassLoader());
/*     */       }
/*     */       catch (ClassNotFoundException ex) {
/* 476 */         throw new ApplicationContextException("Failed to load custom context class [" + contextClassName + "]", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 481 */     contextClassName = defaultStrategies.getProperty(WebApplicationContext.class.getName());
/*     */     try {
/* 483 */       return ClassUtils.forName(contextClassName, ContextLoader.class.getClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 486 */       throw new ApplicationContextException("Failed to load default context class [" + contextClassName + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<Class<ApplicationContextInitializer<ConfigurableApplicationContext>>> determineContextInitializerClasses(ServletContext servletContext)
/*     */   {
/* 501 */     List classes = new ArrayList();
/*     */ 
/* 504 */     String globalClassNames = servletContext.getInitParameter("globalInitializerClasses");
/* 505 */     if (globalClassNames != null) {
/* 506 */       for (String className : StringUtils.tokenizeToStringArray(globalClassNames, ",; \t\n")) {
/* 507 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */ 
/* 511 */     String localClassNames = servletContext.getInitParameter("contextInitializerClasses");
/* 512 */     if (localClassNames != null) {
/* 513 */       for (String className : StringUtils.tokenizeToStringArray(localClassNames, ",; \t\n")) {
/* 514 */         classes.add(loadInitializerClass(className));
/*     */       }
/*     */     }
/*     */ 
/* 518 */     return classes;
/*     */   }
/*     */ 
/*     */   private Class<ApplicationContextInitializer<ConfigurableApplicationContext>> loadInitializerClass(String className)
/*     */   {
/*     */     try {
/* 524 */       Class clazz = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
/* 525 */       Assert.isAssignable(ApplicationContextInitializer.class, clazz);
/* 526 */       return clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 529 */       throw new ApplicationContextException("Failed to load context initializer class [" + className + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ApplicationContext loadParentContext(ServletContext servletContext)
/*     */   {
/* 554 */     ApplicationContext parentContext = null;
/* 555 */     String locatorFactorySelector = servletContext.getInitParameter("locatorFactorySelector");
/* 556 */     String parentContextKey = servletContext.getInitParameter("parentContextKey");
/*     */ 
/* 558 */     if (parentContextKey != null)
/*     */     {
/* 560 */       BeanFactoryLocator locator = ContextSingletonBeanFactoryLocator.getInstance(locatorFactorySelector);
/* 561 */       Log logger = LogFactory.getLog(ContextLoader.class);
/* 562 */       if (logger.isDebugEnabled()) {
/* 563 */         logger.debug("Getting parent context definition: using parent context key of '" + parentContextKey + "' with BeanFactoryLocator");
/*     */       }
/*     */ 
/* 566 */       this.parentContextRef = locator.useBeanFactory(parentContextKey);
/* 567 */       parentContext = (ApplicationContext)this.parentContextRef.getFactory();
/*     */     }
/*     */ 
/* 570 */     return parentContext;
/*     */   }
/*     */ 
/*     */   public void closeWebApplicationContext(ServletContext servletContext)
/*     */   {
/* 583 */     servletContext.log("Closing Spring root WebApplicationContext");
/*     */     try {
/* 585 */       if ((this.context instanceof ConfigurableWebApplicationContext))
/* 586 */         ((ConfigurableWebApplicationContext)this.context).close();
/*     */     }
/*     */     finally
/*     */     {
/*     */       ClassLoader ccl;
/* 590 */       ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 591 */       if (ccl == ContextLoader.class.getClassLoader()) {
/* 592 */         currentContext = null;
/*     */       }
/* 594 */       else if (ccl != null) {
/* 595 */         currentContextPerThread.remove(ccl);
/*     */       }
/* 597 */       servletContext.removeAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/* 598 */       if (this.parentContextRef != null)
/* 599 */         this.parentContextRef.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getCurrentWebApplicationContext()
/*     */   {
/* 614 */     ClassLoader ccl = Thread.currentThread().getContextClassLoader();
/* 615 */     if (ccl != null) {
/* 616 */       WebApplicationContext ccpt = (WebApplicationContext)currentContextPerThread.get(ccl);
/* 617 */       if (ccpt != null) {
/* 618 */         return ccpt;
/*     */       }
/*     */     }
/* 621 */     return currentContext;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 176 */       ClassPathResource resource = new ClassPathResource("ContextLoader.properties", ContextLoader.class);
/* 177 */       defaultStrategies = PropertiesLoaderUtils.loadProperties(resource);
/*     */     }
/*     */     catch (IOException ex) {
/* 180 */       throw new IllegalStateException("Could not load 'ContextLoader.properties': " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.ContextLoader
 * JD-Core Version:    0.6.1
 */