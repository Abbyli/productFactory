/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.HttpMediaTypeNotAcceptableException;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class HeaderContentNegotiationStrategy
/*    */   implements ContentNegotiationStrategy
/*    */ {
/*    */   private static final String ACCEPT_HEADER = "Accept";
/*    */ 
/*    */   public List<MediaType> resolveMediaTypes(NativeWebRequest webRequest)
/*    */     throws HttpMediaTypeNotAcceptableException
/*    */   {
/* 42 */     String acceptHeader = webRequest.getHeader("Accept");
/*    */     try {
/* 44 */       if (StringUtils.hasText(acceptHeader)) {
/* 45 */         List mediaTypes = MediaType.parseMediaTypes(acceptHeader);
/* 46 */         MediaType.sortBySpecificityAndQuality(mediaTypes);
/* 47 */         return mediaTypes;
/*    */       }
/*    */     }
/*    */     catch (IllegalArgumentException ex) {
/* 51 */       throw new HttpMediaTypeNotAcceptableException("Could not parse accept header [" + acceptHeader + "]: " + ex.getMessage());
/*    */     }
/*    */ 
/* 54 */     return Collections.emptyList();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.HeaderContentNegotiationStrategy
 * JD-Core Version:    0.6.1
 */