/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.ParameterizedTypeReference;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpMethod;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.ResponseEntity;
/*     */ import org.springframework.http.client.ClientHttpRequest;
/*     */ import org.springframework.http.client.ClientHttpRequestFactory;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.client.support.InterceptingHttpAccessor;
/*     */ import org.springframework.http.converter.ByteArrayHttpMessageConverter;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.http.converter.ResourceHttpMessageConverter;
/*     */ import org.springframework.http.converter.StringHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.AtomFeedHttpMessageConverter;
/*     */ import org.springframework.http.converter.feed.RssChannelHttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
/*     */ import org.springframework.http.converter.json.MappingJacksonHttpMessageConverter;
/*     */ import org.springframework.http.converter.support.AllEncompassingFormHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
/*     */ import org.springframework.http.converter.xml.SourceHttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.util.UriTemplate;
/*     */ 
/*     */ public class RestTemplate extends InterceptingHttpAccessor
/*     */   implements RestOperations
/*     */ {
/* 127 */   private static boolean romePresent = ClassUtils.isPresent("com.sun.syndication.feed.WireFeed", RestTemplate.class.getClassLoader());
/*     */ 
/* 130 */   private static final boolean jaxb2Present = ClassUtils.isPresent("javax.xml.bind.Binder", RestTemplate.class.getClassLoader());
/*     */ 
/* 133 */   private static final boolean jackson2Present = (ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", RestTemplate.class.getClassLoader())) && (ClassUtils.isPresent("com.fasterxml.jackson.core.JsonGenerator", RestTemplate.class.getClassLoader()));
/*     */ 
/* 137 */   private static final boolean jacksonPresent = (ClassUtils.isPresent("org.codehaus.jackson.map.ObjectMapper", RestTemplate.class.getClassLoader())) && (ClassUtils.isPresent("org.codehaus.jackson.JsonGenerator", RestTemplate.class.getClassLoader()));
/*     */ 
/* 142 */   private final List<HttpMessageConverter<?>> messageConverters = new ArrayList();
/*     */ 
/* 144 */   private ResponseErrorHandler errorHandler = new DefaultResponseErrorHandler();
/*     */ 
/* 146 */   private final ResponseExtractor<HttpHeaders> headersExtractor = new HeadersExtractor(null);
/*     */ 
/*     */   public RestTemplate()
/*     */   {
/* 154 */     this.messageConverters.add(new ByteArrayHttpMessageConverter());
/* 155 */     this.messageConverters.add(new StringHttpMessageConverter());
/* 156 */     this.messageConverters.add(new ResourceHttpMessageConverter());
/* 157 */     this.messageConverters.add(new SourceHttpMessageConverter());
/* 158 */     this.messageConverters.add(new AllEncompassingFormHttpMessageConverter());
/*     */ 
/* 160 */     if (romePresent) {
/* 161 */       this.messageConverters.add(new AtomFeedHttpMessageConverter());
/* 162 */       this.messageConverters.add(new RssChannelHttpMessageConverter());
/*     */     }
/* 164 */     if (jaxb2Present) {
/* 165 */       this.messageConverters.add(new Jaxb2RootElementHttpMessageConverter());
/*     */     }
/* 167 */     if (jackson2Present) {
/* 168 */       this.messageConverters.add(new MappingJackson2HttpMessageConverter());
/*     */     }
/* 170 */     else if (jacksonPresent)
/* 171 */       this.messageConverters.add(new MappingJacksonHttpMessageConverter());
/*     */   }
/*     */ 
/*     */   public RestTemplate(ClientHttpRequestFactory requestFactory)
/*     */   {
/* 182 */     this();
/* 183 */     setRequestFactory(requestFactory);
/*     */   }
/*     */ 
/*     */   public RestTemplate(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 193 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/* 194 */     this.messageConverters.addAll(messageConverters);
/*     */   }
/*     */ 
/*     */   public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/* 203 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/*     */ 
/* 205 */     if (this.messageConverters != messageConverters) {
/* 206 */       this.messageConverters.clear();
/* 207 */       this.messageConverters.addAll(messageConverters);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<HttpMessageConverter<?>> getMessageConverters()
/*     */   {
/* 215 */     return this.messageConverters;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ResponseErrorHandler errorHandler)
/*     */   {
/* 223 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/* 224 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public ResponseErrorHandler getErrorHandler()
/*     */   {
/* 231 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 238 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 239 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 241 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(String url, Class<T> responseType, Map<String, ?> urlVariables) throws RestClientException {
/* 245 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 246 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 248 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> T getForObject(URI url, Class<T> responseType) throws RestClientException {
/* 252 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 253 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 255 */     return execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 261 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 262 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 264 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(String url, Class<T> responseType, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 270 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 271 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 273 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> getForEntity(URI url, Class<T> responseType) throws RestClientException {
/* 277 */     AcceptHeaderRequestCallback requestCallback = new AcceptHeaderRequestCallback(responseType, null);
/* 278 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 280 */     return (ResponseEntity)execute(url, HttpMethod.GET, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 287 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, this.headersExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(String url, Map<String, ?> urlVariables) throws RestClientException {
/* 291 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, this.headersExtractor, urlVariables);
/*     */   }
/*     */ 
/*     */   public HttpHeaders headForHeaders(URI url) throws RestClientException {
/* 295 */     return (HttpHeaders)execute(url, HttpMethod.HEAD, null, this.headersExtractor);
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 302 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 303 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor, urlVariables);
/* 304 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(String url, Object request, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 310 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 311 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor, urlVariables);
/* 312 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public URI postForLocation(URI url, Object request) throws RestClientException {
/* 316 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 317 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.POST, requestCallback, this.headersExtractor);
/* 318 */     return headers.getLocation();
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 324 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 325 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 327 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 333 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 334 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters(), this.logger);
/*     */ 
/* 336 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> T postForObject(URI url, Object request, Class<T> responseType) throws RestClientException {
/* 340 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 341 */     HttpMessageConverterExtractor responseExtractor = new HttpMessageConverterExtractor(responseType, getMessageConverters());
/*     */ 
/* 343 */     return execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 349 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 350 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 352 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(String url, Object request, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 358 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 359 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 361 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> postForEntity(URI url, Object request, Class<T> responseType) throws RestClientException {
/* 365 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, responseType, null);
/* 366 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/*     */ 
/* 368 */     return (ResponseEntity)execute(url, HttpMethod.POST, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 375 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 376 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(String url, Object request, Map<String, ?> urlVariables) throws RestClientException {
/* 380 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 381 */     execute(url, HttpMethod.PUT, requestCallback, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void put(URI url, Object request) throws RestClientException {
/* 385 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(request, null);
/* 386 */     execute(url, HttpMethod.PUT, requestCallback, null);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 393 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(String url, Map<String, ?> urlVariables) throws RestClientException {
/* 397 */     execute(url, HttpMethod.DELETE, null, null, urlVariables);
/*     */   }
/*     */ 
/*     */   public void delete(URI url) throws RestClientException {
/* 401 */     execute(url, HttpMethod.DELETE, null, null);
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 408 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, this.headersExtractor, urlVariables);
/* 409 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(String url, Map<String, ?> urlVariables) throws RestClientException {
/* 413 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, this.headersExtractor, urlVariables);
/* 414 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public Set<HttpMethod> optionsForAllow(URI url) throws RestClientException {
/* 418 */     HttpHeaders headers = (HttpHeaders)execute(url, HttpMethod.OPTIONS, null, this.headersExtractor);
/* 419 */     return headers.getAllow();
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 428 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, responseType, null);
/* 429 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/* 430 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 436 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, responseType, null);
/* 437 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/* 438 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 444 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, responseType, null);
/* 445 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(responseType);
/* 446 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Object[] uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 452 */     Type type = responseType.getType();
/* 453 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, type, null);
/* 454 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(type);
/* 455 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType, Map<String, ?> uriVariables)
/*     */     throws RestClientException
/*     */   {
/* 461 */     Type type = responseType.getType();
/* 462 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, type, null);
/* 463 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(type);
/* 464 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor, uriVariables);
/*     */   }
/*     */ 
/*     */   public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, ParameterizedTypeReference<T> responseType)
/*     */     throws RestClientException
/*     */   {
/* 470 */     Type type = responseType.getType();
/* 471 */     HttpEntityRequestCallback requestCallback = new HttpEntityRequestCallback(requestEntity, type, null);
/* 472 */     ResponseEntityResponseExtractor responseExtractor = new ResponseEntityResponseExtractor(type);
/* 473 */     return (ResponseEntity)execute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Object[] urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 481 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 482 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor, Map<String, ?> urlVariables)
/*     */     throws RestClientException
/*     */   {
/* 488 */     URI expanded = new UriTemplate(url).expand(urlVariables);
/* 489 */     return doExecute(expanded, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   public <T> T execute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 495 */     return doExecute(url, method, requestCallback, responseExtractor);
/*     */   }
/*     */ 
/*     */   protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor)
/*     */     throws RestClientException
/*     */   {
/* 511 */     Assert.notNull(url, "'url' must not be null");
/* 512 */     Assert.notNull(method, "'method' must not be null");
/* 513 */     ClientHttpResponse response = null;
/*     */     try {
/* 515 */       ClientHttpRequest request = createRequest(url, method);
/* 516 */       if (requestCallback != null) {
/* 517 */         requestCallback.doWithRequest(request);
/*     */       }
/* 519 */       response = request.execute();
/* 520 */       if (!getErrorHandler().hasError(response)) {
/* 521 */         logResponseStatus(method, url, response);
/*     */       }
/*     */       else
/* 524 */         handleResponseError(method, url, response);
/*     */       Object localObject1;
/* 526 */       if (responseExtractor != null) {
/* 527 */         return responseExtractor.extractData(response);
/*     */       }
/*     */ 
/* 530 */       return null;
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 534 */       throw new ResourceAccessException("I/O error on " + method.name() + " request for \"" + url + "\": " + ex.getMessage(), ex);
/*     */     }
/*     */     finally
/*     */     {
/* 538 */       if (response != null)
/* 539 */         response.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void logResponseStatus(HttpMethod method, URI url, ClientHttpResponse response)
/*     */   {
/* 545 */     if (this.logger.isDebugEnabled())
/*     */       try {
/* 547 */         this.logger.debug(method.name() + " request for \"" + url + "\" resulted in " + response.getStatusCode() + " (" + response.getStatusText() + ")");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   private void handleResponseError(HttpMethod method, URI url, ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/* 557 */     if (this.logger.isWarnEnabled()) {
/*     */       try {
/* 559 */         this.logger.warn(method.name() + " request for \"" + url + "\" resulted in " + response.getStatusCode() + " (" + response.getStatusText() + "); invoking error handler");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */       }
/*     */     }
/*     */ 
/* 566 */     getErrorHandler().handleError(response);
/*     */   }
/*     */ 
/*     */   private static class HeadersExtractor
/*     */     implements ResponseExtractor<HttpHeaders>
/*     */   {
/*     */     public HttpHeaders extractData(ClientHttpResponse response)
/*     */       throws IOException
/*     */     {
/* 740 */       return response.getHeaders();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResponseEntityResponseExtractor<T>
/*     */     implements ResponseExtractor<ResponseEntity<T>>
/*     */   {
/*     */     private final HttpMessageConverterExtractor<T> delegate;
/*     */ 
/*     */     public ResponseEntityResponseExtractor(Type responseType)
/*     */     {
/* 714 */       if ((responseType != null) && (!Void.class.equals(responseType))) {
/* 715 */         this.delegate = new HttpMessageConverterExtractor(responseType, RestTemplate.this.getMessageConverters(), RestTemplate.this.logger);
/*     */       }
/*     */       else
/* 718 */         this.delegate = null;
/*     */     }
/*     */ 
/*     */     public ResponseEntity<T> extractData(ClientHttpResponse response) throws IOException
/*     */     {
/* 723 */       if (this.delegate != null) {
/* 724 */         Object body = this.delegate.extractData(response);
/* 725 */         return new ResponseEntity(body, response.getHeaders(), response.getStatusCode());
/*     */       }
/*     */ 
/* 728 */       return new ResponseEntity(response.getHeaders(), response.getStatusCode());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HttpEntityRequestCallback extends RestTemplate.AcceptHeaderRequestCallback
/*     */   {
/*     */     private final HttpEntity<?> requestEntity;
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody)
/*     */     {
/* 639 */       this(requestBody, null);
/*     */     }
/*     */ 
/*     */     private HttpEntityRequestCallback(Object requestBody, Type responseType)
/*     */     {
/* 644 */       super(responseType, null);
/* 645 */       if ((requestBody instanceof HttpEntity)) {
/* 646 */         this.requestEntity = ((HttpEntity)requestBody);
/*     */       }
/* 648 */       else if (requestBody != null) {
/* 649 */         this.requestEntity = new HttpEntity(requestBody);
/*     */       }
/*     */       else
/* 652 */         this.requestEntity = HttpEntity.EMPTY;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest httpRequest)
/*     */       throws IOException
/*     */     {
/* 659 */       super.doWithRequest(httpRequest);
/* 660 */       if (!this.requestEntity.hasBody()) {
/* 661 */         HttpHeaders httpHeaders = httpRequest.getHeaders();
/* 662 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 663 */         if (!requestHeaders.isEmpty()) {
/* 664 */           httpHeaders.putAll(requestHeaders);
/*     */         }
/* 666 */         if (httpHeaders.getContentLength() == -1L)
/* 667 */           httpHeaders.setContentLength(0L);
/*     */       }
/*     */       else
/*     */       {
/* 671 */         Object requestBody = this.requestEntity.getBody();
/* 672 */         Class requestType = requestBody.getClass();
/* 673 */         HttpHeaders requestHeaders = this.requestEntity.getHeaders();
/* 674 */         MediaType requestContentType = requestHeaders.getContentType();
/* 675 */         for (HttpMessageConverter messageConverter : RestTemplate.this.getMessageConverters()) {
/* 676 */           if (messageConverter.canWrite(requestType, requestContentType)) {
/* 677 */             if (!requestHeaders.isEmpty()) {
/* 678 */               httpRequest.getHeaders().putAll(requestHeaders);
/*     */             }
/* 680 */             if (RestTemplate.this.logger.isDebugEnabled()) {
/* 681 */               if (requestContentType != null) {
/* 682 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] as \"" + requestContentType + "\" using [" + messageConverter + "]");
/*     */               }
/*     */               else
/*     */               {
/* 686 */                 RestTemplate.this.logger.debug("Writing [" + requestBody + "] using [" + messageConverter + "]");
/*     */               }
/*     */             }
/*     */ 
/* 690 */             messageConverter.write(requestBody, requestContentType, httpRequest);
/*     */ 
/* 692 */             return;
/*     */           }
/*     */         }
/* 695 */         String message = "Could not write request: no suitable HttpMessageConverter found for request type [" + requestType.getName() + "]";
/*     */ 
/* 697 */         if (requestContentType != null) {
/* 698 */           message = message + " and content type [" + requestContentType + "]";
/*     */         }
/* 700 */         throw new RestClientException(message);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AcceptHeaderRequestCallback
/*     */     implements RequestCallback
/*     */   {
/*     */     private final Type responseType;
/*     */ 
/*     */     private AcceptHeaderRequestCallback(Type responseType)
/*     */     {
/* 578 */       this.responseType = responseType;
/*     */     }
/*     */ 
/*     */     public void doWithRequest(ClientHttpRequest request) throws IOException
/*     */     {
/* 583 */       if (this.responseType != null) {
/* 584 */         Class responseClass = null;
/* 585 */         if ((this.responseType instanceof Class)) {
/* 586 */           responseClass = (Class)this.responseType;
/*     */         }
/*     */ 
/* 589 */         List allSupportedMediaTypes = new ArrayList();
/* 590 */         for (HttpMessageConverter converter : RestTemplate.this.getMessageConverters()) {
/* 591 */           if (responseClass != null) {
/* 592 */             if (converter.canRead(responseClass, null)) {
/* 593 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/* 596 */           else if ((converter instanceof GenericHttpMessageConverter))
/*     */           {
/* 598 */             GenericHttpMessageConverter genericConverter = (GenericHttpMessageConverter)converter;
/* 599 */             if (genericConverter.canRead(this.responseType, null, null)) {
/* 600 */               allSupportedMediaTypes.addAll(getSupportedMediaTypes(converter));
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 605 */         if (!allSupportedMediaTypes.isEmpty()) {
/* 606 */           MediaType.sortBySpecificity(allSupportedMediaTypes);
/* 607 */           if (RestTemplate.this.logger.isDebugEnabled()) {
/* 608 */             RestTemplate.this.logger.debug("Setting request Accept header to " + allSupportedMediaTypes);
/*     */           }
/*     */ 
/* 611 */           request.getHeaders().setAccept(allSupportedMediaTypes);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private List<MediaType> getSupportedMediaTypes(HttpMessageConverter<?> messageConverter) {
/* 617 */       List supportedMediaTypes = messageConverter.getSupportedMediaTypes();
/* 618 */       List result = new ArrayList(supportedMediaTypes.size());
/* 619 */       for (MediaType supportedMediaType : supportedMediaTypes) {
/* 620 */         if (supportedMediaType.getCharSet() != null) {
/* 621 */           supportedMediaType = new MediaType(supportedMediaType.getType(), supportedMediaType.getSubtype());
/*     */         }
/*     */ 
/* 624 */         result.add(supportedMediaType);
/*     */       }
/* 626 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.RestTemplate
 * JD-Core Version:    0.6.1
 */