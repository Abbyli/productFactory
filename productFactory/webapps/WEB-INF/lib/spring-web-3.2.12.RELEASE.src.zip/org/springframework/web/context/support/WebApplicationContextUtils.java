/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.faces.context.ExternalContext;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource.StubPropertySource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.request.RequestAttributes;
/*     */ import org.springframework.web.context.request.RequestContextHolder;
/*     */ import org.springframework.web.context.request.RequestScope;
/*     */ import org.springframework.web.context.request.ServletRequestAttributes;
/*     */ import org.springframework.web.context.request.ServletWebRequest;
/*     */ import org.springframework.web.context.request.SessionScope;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ 
/*     */ public abstract class WebApplicationContextUtils
/*     */ {
/*  65 */   private static final boolean jsfPresent = ClassUtils.isPresent("javax.faces.context.FacesContext", RequestContextHolder.class.getClassLoader());
/*     */ 
/*     */   public static WebApplicationContext getRequiredWebApplicationContext(ServletContext sc)
/*     */     throws IllegalStateException
/*     */   {
/*  80 */     WebApplicationContext wac = getWebApplicationContext(sc);
/*  81 */     if (wac == null) {
/*  82 */       throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */     }
/*  84 */     return wac;
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc)
/*     */   {
/*  97 */     return getWebApplicationContext(sc, WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
/*     */   }
/*     */ 
/*     */   public static WebApplicationContext getWebApplicationContext(ServletContext sc, String attrName)
/*     */   {
/* 107 */     Assert.notNull(sc, "ServletContext must not be null");
/* 108 */     Object attr = sc.getAttribute(attrName);
/* 109 */     if (attr == null) {
/* 110 */       return null;
/*     */     }
/* 112 */     if ((attr instanceof RuntimeException)) {
/* 113 */       throw ((RuntimeException)attr);
/*     */     }
/* 115 */     if ((attr instanceof Error)) {
/* 116 */       throw ((Error)attr);
/*     */     }
/* 118 */     if ((attr instanceof Exception)) {
/* 119 */       throw new IllegalStateException((Exception)attr);
/*     */     }
/* 121 */     if (!(attr instanceof WebApplicationContext)) {
/* 122 */       throw new IllegalStateException("Context attribute is not of type WebApplicationContext: " + attr);
/*     */     }
/* 124 */     return (WebApplicationContext)attr;
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 134 */     registerWebApplicationScopes(beanFactory, null);
/*     */   }
/*     */ 
/*     */   public static void registerWebApplicationScopes(ConfigurableListableBeanFactory beanFactory, ServletContext sc)
/*     */   {
/* 144 */     beanFactory.registerScope("request", new RequestScope());
/* 145 */     beanFactory.registerScope("session", new SessionScope(false));
/* 146 */     beanFactory.registerScope("globalSession", new SessionScope(true));
/* 147 */     if (sc != null) {
/* 148 */       ServletContextScope appScope = new ServletContextScope(sc);
/* 149 */       beanFactory.registerScope("application", appScope);
/*     */ 
/* 151 */       sc.setAttribute(ServletContextScope.class.getName(), appScope);
/*     */     }
/*     */ 
/* 154 */     beanFactory.registerResolvableDependency(ServletRequest.class, new RequestObjectFactory(null));
/* 155 */     beanFactory.registerResolvableDependency(HttpSession.class, new SessionObjectFactory(null));
/* 156 */     beanFactory.registerResolvableDependency(WebRequest.class, new WebRequestObjectFactory(null));
/* 157 */     if (jsfPresent)
/* 158 */       FacesDependencyRegistrar.registerFacesDependencies(beanFactory);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext sc)
/*     */   {
/* 169 */     registerEnvironmentBeans(bf, sc, null);
/*     */   }
/*     */ 
/*     */   public static void registerEnvironmentBeans(ConfigurableListableBeanFactory bf, ServletContext servletContext, ServletConfig servletConfig)
/*     */   {
/* 182 */     if ((servletContext != null) && (!bf.containsBean("servletContext"))) {
/* 183 */       bf.registerSingleton("servletContext", servletContext);
/*     */     }
/*     */ 
/* 186 */     if ((servletConfig != null) && (!bf.containsBean("servletConfig"))) {
/* 187 */       bf.registerSingleton("servletConfig", servletConfig);
/*     */     }
/*     */ 
/* 190 */     if (!bf.containsBean("contextParameters")) {
/* 191 */       Map parameterMap = new HashMap();
/* 192 */       if (servletContext != null) {
/* 193 */         Enumeration paramNameEnum = servletContext.getInitParameterNames();
/* 194 */         while (paramNameEnum.hasMoreElements()) {
/* 195 */           String paramName = (String)paramNameEnum.nextElement();
/* 196 */           parameterMap.put(paramName, servletContext.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 199 */       if (servletConfig != null) {
/* 200 */         Enumeration paramNameEnum = servletConfig.getInitParameterNames();
/* 201 */         while (paramNameEnum.hasMoreElements()) {
/* 202 */           String paramName = (String)paramNameEnum.nextElement();
/* 203 */           parameterMap.put(paramName, servletConfig.getInitParameter(paramName));
/*     */         }
/*     */       }
/* 206 */       bf.registerSingleton("contextParameters", Collections.unmodifiableMap(parameterMap));
/*     */     }
/*     */ 
/* 210 */     if (!bf.containsBean("contextAttributes")) {
/* 211 */       Map attributeMap = new HashMap();
/* 212 */       if (servletContext != null) {
/* 213 */         Enumeration attrNameEnum = servletContext.getAttributeNames();
/* 214 */         while (attrNameEnum.hasMoreElements()) {
/* 215 */           String attrName = (String)attrNameEnum.nextElement();
/* 216 */           attributeMap.put(attrName, servletContext.getAttribute(attrName));
/*     */         }
/*     */       }
/* 219 */       bf.registerSingleton("contextAttributes", Collections.unmodifiableMap(attributeMap));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext)
/*     */   {
/* 231 */     initServletPropertySources(propertySources, servletContext, null);
/*     */   }
/*     */ 
/*     */   public static void initServletPropertySources(MutablePropertySources propertySources, ServletContext servletContext, ServletConfig servletConfig)
/*     */   {
/* 255 */     Assert.notNull(propertySources, "propertySources must not be null");
/* 256 */     if ((servletContext != null) && (propertySources.contains("servletContextInitParams")) && ((propertySources.get("servletContextInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 258 */       propertySources.replace("servletContextInitParams", new ServletContextPropertySource("servletContextInitParams", servletContext));
/*     */     }
/*     */ 
/* 261 */     if ((servletConfig != null) && (propertySources.contains("servletConfigInitParams")) && ((propertySources.get("servletConfigInitParams") instanceof PropertySource.StubPropertySource)))
/*     */     {
/* 263 */       propertySources.replace("servletConfigInitParams", new ServletConfigPropertySource("servletConfigInitParams", servletConfig));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static ServletRequestAttributes currentRequestAttributes()
/*     */   {
/* 273 */     RequestAttributes requestAttr = RequestContextHolder.currentRequestAttributes();
/* 274 */     if (!(requestAttr instanceof ServletRequestAttributes)) {
/* 275 */       throw new IllegalStateException("Current request is not a servlet request");
/*     */     }
/* 277 */     return (ServletRequestAttributes)requestAttr;
/*     */   }
/*     */ 
/*     */   private static class FacesDependencyRegistrar
/*     */   {
/*     */     public static void registerFacesDependencies(ConfigurableListableBeanFactory beanFactory)
/*     */     {
/* 338 */       beanFactory.registerResolvableDependency(FacesContext.class, new ObjectFactory() {
/*     */         public FacesContext getObject() {
/* 340 */           return FacesContext.getCurrentInstance();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 344 */           return "Current JSF FacesContext";
/*     */         }
/*     */       });
/* 347 */       beanFactory.registerResolvableDependency(ExternalContext.class, new ObjectFactory() {
/*     */         public ExternalContext getObject() {
/* 349 */           return FacesContext.getCurrentInstance().getExternalContext();
/*     */         }
/*     */ 
/*     */         public String toString() {
/* 353 */           return "Current JSF ExternalContext";
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class WebRequestObjectFactory
/*     */     implements ObjectFactory<WebRequest>, Serializable
/*     */   {
/*     */     public WebRequest getObject()
/*     */     {
/* 322 */       return new ServletWebRequest(WebApplicationContextUtils.access$300().getRequest());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 327 */       return "Current ServletWebRequest";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SessionObjectFactory
/*     */     implements ObjectFactory<HttpSession>, Serializable
/*     */   {
/*     */     public HttpSession getObject()
/*     */     {
/* 305 */       return WebApplicationContextUtils.access$300().getRequest().getSession();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 310 */       return "Current HttpSession";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RequestObjectFactory
/*     */     implements ObjectFactory<ServletRequest>, Serializable
/*     */   {
/*     */     public ServletRequest getObject()
/*     */     {
/* 288 */       return WebApplicationContextUtils.access$300().getRequest();
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 293 */       return "Current HttpServletRequest";
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationContextUtils
 * JD-Core Version:    0.6.1
 */