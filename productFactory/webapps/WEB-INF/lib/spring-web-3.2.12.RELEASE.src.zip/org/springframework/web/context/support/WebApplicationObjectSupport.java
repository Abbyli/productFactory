/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.support.ApplicationObjectSupport;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public abstract class WebApplicationObjectSupport extends ApplicationObjectSupport
/*     */   implements ServletContextAware
/*     */ {
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public final void setServletContext(ServletContext servletContext)
/*     */   {
/*  47 */     if (servletContext != this.servletContext) {
/*  48 */       this.servletContext = servletContext;
/*  49 */       if (servletContext != null)
/*  50 */         initServletContext(servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isContextRequired()
/*     */   {
/*  66 */     return true;
/*     */   }
/*     */ 
/*     */   protected void initApplicationContext(ApplicationContext context)
/*     */   {
/*  75 */     super.initApplicationContext(context);
/*  76 */     if ((this.servletContext == null) && ((context instanceof WebApplicationContext))) {
/*  77 */       this.servletContext = ((WebApplicationContext)context).getServletContext();
/*  78 */       if (this.servletContext != null)
/*  79 */         initServletContext(this.servletContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initServletContext(ServletContext servletContext)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected final WebApplicationContext getWebApplicationContext()
/*     */     throws IllegalStateException
/*     */   {
/* 106 */     ApplicationContext ctx = getApplicationContext();
/* 107 */     if ((ctx instanceof WebApplicationContext)) {
/* 108 */       return (WebApplicationContext)getApplicationContext();
/*     */     }
/* 110 */     if (isContextRequired()) {
/* 111 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run in a WebApplicationContext but in: " + ctx);
/*     */     }
/*     */ 
/* 115 */     return null;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */     throws IllegalStateException
/*     */   {
/* 124 */     if (this.servletContext != null) {
/* 125 */       return this.servletContext;
/*     */     }
/* 127 */     ServletContext servletContext = getWebApplicationContext().getServletContext();
/* 128 */     if ((servletContext == null) && (isContextRequired())) {
/* 129 */       throw new IllegalStateException("WebApplicationObjectSupport instance [" + this + "] does not run within a ServletContext. Make sure the object is fully configured!");
/*     */     }
/*     */ 
/* 132 */     return servletContext;
/*     */   }
/*     */ 
/*     */   protected final File getTempDir()
/*     */     throws IllegalStateException
/*     */   {
/* 143 */     return WebUtils.getTempDir(getServletContext());
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.WebApplicationObjectSupport
 * JD-Core Version:    0.6.1
 */