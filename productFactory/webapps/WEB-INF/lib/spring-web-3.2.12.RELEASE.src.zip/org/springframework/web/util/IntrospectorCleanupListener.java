/*    */ package org.springframework.web.util;
/*    */ 
/*    */ import java.beans.Introspector;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.springframework.beans.CachedIntrospectionResults;
/*    */ 
/*    */ public class IntrospectorCleanupListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   public void contextInitialized(ServletContextEvent event)
/*    */   {
/* 75 */     CachedIntrospectionResults.acceptClassLoader(Thread.currentThread().getContextClassLoader());
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent event) {
/* 79 */     CachedIntrospectionResults.clearClassLoader(Thread.currentThread().getContextClassLoader());
/* 80 */     Introspector.flushCaches();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.IntrospectorCleanupListener
 * JD-Core Version:    0.6.1
 */