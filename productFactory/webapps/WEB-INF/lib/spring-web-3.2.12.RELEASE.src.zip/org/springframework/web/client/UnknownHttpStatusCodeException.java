/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ 
/*     */ public class UnknownHttpStatusCodeException extends RestClientException
/*     */ {
/*     */   private static final long serialVersionUID = 4702443689088991600L;
/*     */   private static final String DEFAULT_CHARSET = "ISO-8859-1";
/*     */   private final int rawStatusCode;
/*     */   private final String statusText;
/*     */   private final byte[] responseBody;
/*     */   private final HttpHeaders responseHeaders;
/*     */   private final String responseCharset;
/*     */ 
/*     */   public UnknownHttpStatusCodeException(int rawStatusCode, String statusText, HttpHeaders responseHeaders, byte[] responseBody, Charset responseCharset)
/*     */   {
/*  60 */     super("Unknown status code [" + String.valueOf(rawStatusCode) + "]" + " " + statusText);
/*  61 */     this.rawStatusCode = rawStatusCode;
/*  62 */     this.statusText = statusText;
/*  63 */     this.responseHeaders = responseHeaders;
/*  64 */     this.responseBody = (responseBody != null ? responseBody : new byte[0]);
/*  65 */     this.responseCharset = (responseCharset != null ? responseCharset.name() : "ISO-8859-1");
/*     */   }
/*     */ 
/*     */   public int getRawStatusCode()
/*     */   {
/*  73 */     return this.rawStatusCode;
/*     */   }
/*     */ 
/*     */   public String getStatusText()
/*     */   {
/*  80 */     return this.statusText;
/*     */   }
/*     */ 
/*     */   public HttpHeaders getResponseHeaders()
/*     */   {
/*  87 */     return this.responseHeaders;
/*     */   }
/*     */ 
/*     */   public byte[] getResponseBodyAsByteArray()
/*     */   {
/*  94 */     return this.responseBody;
/*     */   }
/*     */ 
/*     */   public String getResponseBodyAsString()
/*     */   {
/*     */     try
/*     */     {
/* 102 */       return new String(this.responseBody, this.responseCharset);
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 106 */       throw new IllegalStateException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.UnknownHttpStatusCodeException
 * JD-Core Version:    0.6.1
 */