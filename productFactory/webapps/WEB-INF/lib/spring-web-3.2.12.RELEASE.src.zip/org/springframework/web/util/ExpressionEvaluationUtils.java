/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.el.ELException;
/*     */ import javax.servlet.jsp.el.ExpressionEvaluator;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class ExpressionEvaluationUtils
/*     */ {
/*     */   public static final String EXPRESSION_SUPPORT_CONTEXT_PARAM = "springJspExpressionSupport";
/*     */   public static final String EXPRESSION_PREFIX = "${";
/*     */   public static final String EXPRESSION_SUFFIX = "}";
/*     */ 
/*     */   public static boolean isSpringJspExpressionSupportActive(PageContext pageContext)
/*     */   {
/*  79 */     ServletContext sc = pageContext.getServletContext();
/*  80 */     String springJspExpressionSupport = sc.getInitParameter("springJspExpressionSupport");
/*  81 */     if (springJspExpressionSupport != null) {
/*  82 */       return Boolean.valueOf(springJspExpressionSupport).booleanValue();
/*     */     }
/*  84 */     if (sc.getMajorVersion() >= 3)
/*     */     {
/*  86 */       if ((sc.getEffectiveMajorVersion() == 2) && (sc.getEffectiveMinorVersion() < 4))
/*     */       {
/*  89 */         return true;
/*     */       }
/*     */     }
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isExpressionLanguage(String value)
/*     */   {
/* 102 */     return (value != null) && (value.contains("${"));
/*     */   }
/*     */ 
/*     */   public static Object evaluate(String attrName, String attrValue, Class resultClass, PageContext pageContext)
/*     */     throws JspException
/*     */   {
/* 120 */     if ((isSpringJspExpressionSupportActive(pageContext)) && (isExpressionLanguage(attrValue))) {
/* 121 */       return doEvaluate(attrName, attrValue, resultClass, pageContext);
/*     */     }
/* 123 */     if ((attrValue != null) && (resultClass != null) && (!resultClass.isInstance(attrValue))) {
/* 124 */       throw new JspException("Attribute value \"" + attrValue + "\" is neither a JSP EL expression nor " + "assignable to result class [" + resultClass.getName() + "]");
/*     */     }
/*     */ 
/* 128 */     return attrValue;
/*     */   }
/*     */ 
/*     */   public static Object evaluate(String attrName, String attrValue, PageContext pageContext)
/*     */     throws JspException
/*     */   {
/* 143 */     if ((isSpringJspExpressionSupportActive(pageContext)) && (isExpressionLanguage(attrValue))) {
/* 144 */       return doEvaluate(attrName, attrValue, Object.class, pageContext);
/*     */     }
/*     */ 
/* 147 */     return attrValue;
/*     */   }
/*     */ 
/*     */   public static String evaluateString(String attrName, String attrValue, PageContext pageContext)
/*     */     throws JspException
/*     */   {
/* 162 */     if ((isSpringJspExpressionSupportActive(pageContext)) && (isExpressionLanguage(attrValue))) {
/* 163 */       return (String)doEvaluate(attrName, attrValue, String.class, pageContext);
/*     */     }
/*     */ 
/* 166 */     return attrValue;
/*     */   }
/*     */ 
/*     */   public static int evaluateInteger(String attrName, String attrValue, PageContext pageContext)
/*     */     throws JspException
/*     */   {
/* 181 */     if ((isSpringJspExpressionSupportActive(pageContext)) && (isExpressionLanguage(attrValue))) {
/* 182 */       return ((Integer)doEvaluate(attrName, attrValue, Integer.class, pageContext)).intValue();
/*     */     }
/*     */ 
/* 185 */     return Integer.parseInt(attrValue);
/*     */   }
/*     */ 
/*     */   public static boolean evaluateBoolean(String attrName, String attrValue, PageContext pageContext)
/*     */     throws JspException
/*     */   {
/* 200 */     if ((isSpringJspExpressionSupportActive(pageContext)) && (isExpressionLanguage(attrValue))) {
/* 201 */       return ((Boolean)doEvaluate(attrName, attrValue, Boolean.class, pageContext)).booleanValue();
/*     */     }
/*     */ 
/* 204 */     return Boolean.valueOf(attrValue).booleanValue();
/*     */   }
/*     */ 
/*     */   private static Object doEvaluate(String attrName, String attrValue, Class resultClass, PageContext pageContext)
/*     */     throws JspException
/*     */   {
/* 222 */     Assert.notNull(attrValue, "Attribute value must not be null");
/* 223 */     Assert.notNull(resultClass, "Result class must not be null");
/* 224 */     Assert.notNull(pageContext, "PageContext must not be null");
/*     */     try
/*     */     {
/* 227 */       if (resultClass.isAssignableFrom(String.class)) { StringBuilder resultValue = null;
/*     */ 
/* 230 */         int exprSuffixIndex = 0;
/*     */         int exprPrefixIndex;
/*     */         do { exprPrefixIndex = attrValue.indexOf("${", exprSuffixIndex);
/* 233 */           if (exprPrefixIndex != -1) {
/* 234 */             int prevExprSuffixIndex = exprSuffixIndex;
/* 235 */             exprSuffixIndex = attrValue.indexOf("}", exprPrefixIndex + "${".length());
/*     */             String expr;
/*     */             String expr;
/* 237 */             if (exprSuffixIndex != -1) {
/* 238 */               exprSuffixIndex += "}".length();
/* 239 */               expr = attrValue.substring(exprPrefixIndex, exprSuffixIndex);
/*     */             }
/*     */             else {
/* 242 */               expr = attrValue.substring(exprPrefixIndex);
/*     */             }
/* 244 */             if (expr.length() == attrValue.length())
/*     */             {
/* 247 */               return evaluateExpression(attrValue, resultClass, pageContext);
/*     */             }
/*     */ 
/* 251 */             if (resultValue == null) {
/* 252 */               resultValue = new StringBuilder();
/*     */             }
/* 254 */             resultValue.append(attrValue.substring(prevExprSuffixIndex, exprPrefixIndex));
/* 255 */             resultValue.append(evaluateExpression(expr, String.class, pageContext));
/*     */           }
/*     */           else
/*     */           {
/* 259 */             if (resultValue == null) {
/* 260 */               resultValue = new StringBuilder();
/*     */             }
/* 262 */             resultValue.append(attrValue.substring(exprSuffixIndex));
/*     */           }
/*     */         }
/* 265 */         while ((exprPrefixIndex != -1) && (exprSuffixIndex != -1));
/* 266 */         return resultValue.toString();
/*     */       }
/*     */ 
/* 269 */       return evaluateExpression(attrValue, resultClass, pageContext);
/*     */     }
/*     */     catch (ELException ex)
/*     */     {
/* 273 */       throw new JspException("Parsing of JSP EL expression failed for attribute '" + attrName + "'", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Object evaluateExpression(String exprValue, Class resultClass, PageContext pageContext)
/*     */     throws ELException
/*     */   {
/* 280 */     return pageContext.getExpressionEvaluator().evaluate(exprValue, resultClass, pageContext.getVariableResolver(), null);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.ExpressionEvaluationUtils
 * JD-Core Version:    0.6.1
 */