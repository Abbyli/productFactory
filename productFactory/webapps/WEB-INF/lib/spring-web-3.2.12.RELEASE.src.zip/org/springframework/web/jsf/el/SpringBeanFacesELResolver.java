/*    */ package org.springframework.web.jsf.el;
/*    */ 
/*    */ import javax.el.ELContext;
/*    */ import javax.faces.context.FacesContext;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.access.el.SpringBeanELResolver;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.jsf.FacesContextUtils;
/*    */ 
/*    */ public class SpringBeanFacesELResolver extends SpringBeanELResolver
/*    */ {
/*    */   protected BeanFactory getBeanFactory(ELContext elContext)
/*    */   {
/* 79 */     return getWebApplicationContext(elContext);
/*    */   }
/*    */ 
/*    */   protected WebApplicationContext getWebApplicationContext(ELContext elContext)
/*    */   {
/* 90 */     FacesContext facesContext = FacesContext.getCurrentInstance();
/* 91 */     return FacesContextUtils.getRequiredWebApplicationContext(facesContext);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.el.SpringBeanFacesELResolver
 * JD-Core Version:    0.6.1
 */