/*     */ package org.springframework.web.multipart.support;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.Part;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartFile;
/*     */ 
/*     */ public class StandardMultipartHttpServletRequest extends AbstractMultipartHttpServletRequest
/*     */ {
/*     */   private static final String CONTENT_DISPOSITION = "content-disposition";
/*     */   private static final String FILENAME_KEY = "filename=";
/*     */   private Set<String> multipartParameterNames;
/*     */ 
/*     */   public StandardMultipartHttpServletRequest(HttpServletRequest request)
/*     */     throws MultipartException
/*     */   {
/*  64 */     this(request, false);
/*     */   }
/*     */ 
/*     */   public StandardMultipartHttpServletRequest(HttpServletRequest request, boolean lazyParsing)
/*     */     throws MultipartException
/*     */   {
/*  75 */     super(request);
/*  76 */     if (!lazyParsing)
/*  77 */       parseRequest(request);
/*     */   }
/*     */ 
/*     */   private void parseRequest(HttpServletRequest request)
/*     */   {
/*     */     try
/*     */     {
/*  84 */       Collection parts = request.getParts();
/*  85 */       this.multipartParameterNames = new LinkedHashSet(parts.size());
/*  86 */       MultiValueMap files = new LinkedMultiValueMap(parts.size());
/*  87 */       for (Part part : parts) {
/*  88 */         String filename = extractFilename(part.getHeader("content-disposition"));
/*  89 */         if (filename != null) {
/*  90 */           files.add(part.getName(), new StandardMultipartFile(part, filename));
/*     */         }
/*     */         else {
/*  93 */           this.multipartParameterNames.add(part.getName());
/*     */         }
/*     */       }
/*  96 */       setMultipartFiles(files);
/*     */     }
/*     */     catch (Exception ex) {
/*  99 */       throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String extractFilename(String contentDisposition) {
/* 104 */     if (contentDisposition == null) {
/* 105 */       return null;
/*     */     }
/*     */ 
/* 108 */     int startIndex = contentDisposition.indexOf("filename=");
/* 109 */     if (startIndex == -1) {
/* 110 */       return null;
/*     */     }
/* 112 */     String filename = contentDisposition.substring(startIndex + "filename=".length());
/* 113 */     if (filename.startsWith("\"")) {
/* 114 */       int endIndex = filename.indexOf("\"", 1);
/* 115 */       if (endIndex != -1)
/* 116 */         return filename.substring(1, endIndex);
/*     */     }
/*     */     else
/*     */     {
/* 120 */       int endIndex = filename.indexOf(";");
/* 121 */       if (endIndex != -1) {
/* 122 */         return filename.substring(0, endIndex);
/*     */       }
/*     */     }
/* 125 */     return filename;
/*     */   }
/*     */ 
/*     */   protected void initializeMultipart()
/*     */   {
/* 131 */     parseRequest(getRequest());
/*     */   }
/*     */ 
/*     */   public Enumeration<String> getParameterNames()
/*     */   {
/* 136 */     if (this.multipartParameterNames == null) {
/* 137 */       initializeMultipart();
/*     */     }
/* 139 */     if (this.multipartParameterNames.isEmpty()) {
/* 140 */       return super.getParameterNames();
/*     */     }
/*     */ 
/* 145 */     Set paramNames = new LinkedHashSet();
/* 146 */     Enumeration paramEnum = super.getParameterNames();
/* 147 */     while (paramEnum.hasMoreElements()) {
/* 148 */       paramNames.add(paramEnum.nextElement());
/*     */     }
/* 150 */     paramNames.addAll(this.multipartParameterNames);
/* 151 */     return Collections.enumeration(paramNames);
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap()
/*     */   {
/* 156 */     if (this.multipartParameterNames == null) {
/* 157 */       initializeMultipart();
/*     */     }
/* 159 */     if (this.multipartParameterNames.isEmpty()) {
/* 160 */       return super.getParameterMap();
/*     */     }
/*     */ 
/* 165 */     Map paramMap = new LinkedHashMap();
/* 166 */     paramMap.putAll(super.getParameterMap());
/* 167 */     for (String paramName : this.multipartParameterNames) {
/* 168 */       if (!paramMap.containsKey(paramName)) {
/* 169 */         paramMap.put(paramName, getParameterValues(paramName));
/*     */       }
/*     */     }
/* 172 */     return paramMap;
/*     */   }
/*     */ 
/*     */   public String getMultipartContentType(String paramOrFileName)
/*     */   {
/*     */     try {
/* 178 */       Part part = getPart(paramOrFileName);
/* 179 */       return part != null ? part.getContentType() : null;
/*     */     }
/*     */     catch (Exception ex) {
/* 182 */       throw new MultipartException("Could not access multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public HttpHeaders getMultipartHeaders(String paramOrFileName) {
/*     */     try {
/* 188 */       Part part = getPart(paramOrFileName);
/* 189 */       if (part != null) {
/* 190 */         HttpHeaders headers = new HttpHeaders();
/* 191 */         for (String headerName : part.getHeaderNames()) {
/* 192 */           headers.put(headerName, new ArrayList(part.getHeaders(headerName)));
/*     */         }
/* 194 */         return headers;
/*     */       }
/*     */ 
/* 197 */       return null;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 201 */       throw new MultipartException("Could not access multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StandardMultipartFile
/*     */     implements MultipartFile
/*     */   {
/*     */     private final Part part;
/*     */     private final String filename;
/*     */ 
/*     */     public StandardMultipartFile(Part part, String filename)
/*     */     {
/* 216 */       this.part = part;
/* 217 */       this.filename = filename;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 221 */       return this.part.getName();
/*     */     }
/*     */ 
/*     */     public String getOriginalFilename() {
/* 225 */       return this.filename;
/*     */     }
/*     */ 
/*     */     public String getContentType() {
/* 229 */       return this.part.getContentType();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 233 */       return this.part.getSize() == 0L;
/*     */     }
/*     */ 
/*     */     public long getSize() {
/* 237 */       return this.part.getSize();
/*     */     }
/*     */ 
/*     */     public byte[] getBytes() throws IOException {
/* 241 */       return FileCopyUtils.copyToByteArray(this.part.getInputStream());
/*     */     }
/*     */ 
/*     */     public InputStream getInputStream() throws IOException {
/* 245 */       return this.part.getInputStream();
/*     */     }
/*     */ 
/*     */     public void transferTo(File dest) throws IOException, IllegalStateException {
/* 249 */       this.part.write(dest.getPath());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.support.StandardMultipartHttpServletRequest
 * JD-Core Version:    0.6.1
 */