/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class WebAsyncTask<V>
/*     */ {
/*     */   private final Callable<V> callable;
/*     */   private final Long timeout;
/*     */   private final String executorName;
/*     */   private final AsyncTaskExecutor executor;
/*     */   private Callable<V> timeoutCallback;
/*     */   private Runnable completionCallback;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public WebAsyncTask(Callable<V> callable)
/*     */   {
/*  53 */     this(null, null, null, callable);
/*     */   }
/*     */ 
/*     */   public WebAsyncTask(long timeout, Callable<V> callable)
/*     */   {
/*  62 */     this(Long.valueOf(timeout), null, null, callable);
/*     */   }
/*     */ 
/*     */   public WebAsyncTask(Long timeout, String executorName, Callable<V> callable)
/*     */   {
/*  71 */     this(timeout, null, executorName, callable);
/*  72 */     Assert.notNull(this.executor, "Executor name must not be null");
/*     */   }
/*     */ 
/*     */   public WebAsyncTask(Long timeout, AsyncTaskExecutor executor, Callable<V> callable)
/*     */   {
/*  81 */     this(timeout, executor, null, callable);
/*  82 */     Assert.notNull(executor, "Executor must not be null");
/*     */   }
/*     */ 
/*     */   private WebAsyncTask(Long timeout, AsyncTaskExecutor executor, String executorName, Callable<V> callable) {
/*  86 */     Assert.notNull(callable, "Callable must not be null");
/*  87 */     this.callable = callable;
/*  88 */     this.timeout = timeout;
/*  89 */     this.executor = executor;
/*  90 */     this.executorName = executorName;
/*     */   }
/*     */ 
/*     */   public Callable<?> getCallable()
/*     */   {
/*  98 */     return this.callable;
/*     */   }
/*     */ 
/*     */   public Long getTimeout()
/*     */   {
/* 105 */     return this.timeout;
/*     */   }
/*     */ 
/*     */   public AsyncTaskExecutor getExecutor()
/*     */   {
/* 112 */     if (this.executor != null) {
/* 113 */       return this.executor;
/*     */     }
/* 115 */     if (this.executorName != null) {
/* 116 */       Assert.state(this.beanFactory != null, "A BeanFactory is required to look up a task executor bean");
/* 117 */       return (AsyncTaskExecutor)this.beanFactory.getBean(this.executorName, AsyncTaskExecutor.class);
/*     */     }
/*     */ 
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 130 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void onTimeout(Callable<V> callback)
/*     */   {
/* 143 */     this.timeoutCallback = callback;
/*     */   }
/*     */ 
/*     */   public void onCompletion(Runnable callback)
/*     */   {
/* 152 */     this.completionCallback = callback;
/*     */   }
/*     */ 
/*     */   CallableProcessingInterceptor getInterceptor() {
/* 156 */     return new CallableProcessingInterceptorAdapter()
/*     */     {
/*     */       public <T> Object handleTimeout(NativeWebRequest request, Callable<T> task) throws Exception
/*     */       {
/* 160 */         return WebAsyncTask.this.timeoutCallback != null ? WebAsyncTask.this.timeoutCallback.call() : CallableProcessingInterceptor.RESULT_NONE;
/*     */       }
/*     */ 
/*     */       public <T> void afterCompletion(NativeWebRequest request, Callable<T> task) throws Exception
/*     */       {
/* 165 */         if (WebAsyncTask.this.completionCallback != null)
/* 166 */           WebAsyncTask.this.completionCallback.run();
/*     */       }
/*     */     };
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.WebAsyncTask
 * JD-Core Version:    0.6.1
 */