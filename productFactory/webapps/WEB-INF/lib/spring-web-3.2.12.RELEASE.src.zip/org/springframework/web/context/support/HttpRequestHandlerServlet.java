/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.springframework.context.i18n.LocaleContextHolder;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.web.HttpRequestHandler;
/*    */ import org.springframework.web.HttpRequestMethodNotSupportedException;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ public class HttpRequestHandlerServlet extends HttpServlet
/*    */ {
/*    */   private HttpRequestHandler target;
/*    */ 
/*    */   public void init()
/*    */     throws ServletException
/*    */   {
/* 57 */     WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
/* 58 */     this.target = ((HttpRequestHandler)wac.getBean(getServletName(), HttpRequestHandler.class));
/*    */   }
/*    */ 
/*    */   protected void service(HttpServletRequest request, HttpServletResponse response)
/*    */     throws ServletException, IOException
/*    */   {
/* 66 */     LocaleContextHolder.setLocale(request.getLocale());
/*    */     try {
/* 68 */       this.target.handleRequest(request, response);
/*    */     }
/*    */     catch (HttpRequestMethodNotSupportedException ex) {
/* 71 */       String[] supportedMethods = ex.getSupportedMethods();
/* 72 */       if (supportedMethods != null) {
/* 73 */         response.setHeader("Allow", StringUtils.arrayToDelimitedString(supportedMethods, ", "));
/*    */       }
/* 75 */       response.sendError(405, ex.getMessage());
/*    */     }
/*    */     finally {
/* 78 */       LocaleContextHolder.resetLocaleContext();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.HttpRequestHandlerServlet
 * JD-Core Version:    0.6.1
 */