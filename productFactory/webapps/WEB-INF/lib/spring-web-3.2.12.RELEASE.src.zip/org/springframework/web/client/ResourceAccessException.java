/*    */ package org.springframework.web.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class ResourceAccessException extends RestClientException
/*    */ {
/*    */   private static final long serialVersionUID = -8513182514355844870L;
/*    */ 
/*    */   public ResourceAccessException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public ResourceAccessException(String msg, IOException ex)
/*    */   {
/* 46 */     super(msg, ex);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.ResourceAccessException
 * JD-Core Version:    0.6.1
 */