/*    */ package org.springframework.web.util;
/*    */ 
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ 
/*    */ public class Log4jConfigListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   public void contextInitialized(ServletContextEvent event)
/*    */   {
/* 45 */     Log4jWebConfigurer.initLogging(event.getServletContext());
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent event) {
/* 49 */     Log4jWebConfigurer.shutdownLogging(event.getServletContext());
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.Log4jConfigListener
 * JD-Core Version:    0.6.1
 */