/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ public class ServletRequestHandledEvent extends RequestHandledEvent
/*     */ {
/*     */   private final String requestUrl;
/*     */   private final String clientAddress;
/*     */   private final String method;
/*     */   private final String servletName;
/*     */ 
/*     */   public ServletRequestHandledEvent(Object source, String requestUrl, String clientAddress, String method, String servletName, String sessionId, String userName, long processingTimeMillis)
/*     */   {
/*  60 */     super(source, sessionId, userName, processingTimeMillis);
/*  61 */     this.requestUrl = requestUrl;
/*  62 */     this.clientAddress = clientAddress;
/*  63 */     this.method = method;
/*  64 */     this.servletName = servletName;
/*     */   }
/*     */ 
/*     */   public ServletRequestHandledEvent(Object source, String requestUrl, String clientAddress, String method, String servletName, String sessionId, String userName, long processingTimeMillis, Throwable failureCause)
/*     */   {
/*  84 */     super(source, sessionId, userName, processingTimeMillis, failureCause);
/*  85 */     this.requestUrl = requestUrl;
/*  86 */     this.clientAddress = clientAddress;
/*  87 */     this.method = method;
/*  88 */     this.servletName = servletName;
/*     */   }
/*     */ 
/*     */   public String getRequestUrl()
/*     */   {
/*  96 */     return this.requestUrl;
/*     */   }
/*     */ 
/*     */   public String getClientAddress()
/*     */   {
/* 103 */     return this.clientAddress;
/*     */   }
/*     */ 
/*     */   public String getMethod()
/*     */   {
/* 110 */     return this.method;
/*     */   }
/*     */ 
/*     */   public String getServletName()
/*     */   {
/* 117 */     return this.servletName;
/*     */   }
/*     */ 
/*     */   public String getShortDescription()
/*     */   {
/* 123 */     StringBuilder sb = new StringBuilder();
/* 124 */     sb.append("url=[").append(getRequestUrl()).append("]; ");
/* 125 */     sb.append("client=[").append(getClientAddress()).append("]; ");
/* 126 */     sb.append(super.getShortDescription());
/* 127 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 132 */     StringBuilder sb = new StringBuilder();
/* 133 */     sb.append("url=[").append(getRequestUrl()).append("]; ");
/* 134 */     sb.append("client=[").append(getClientAddress()).append("]; ");
/* 135 */     sb.append("method=[").append(getMethod()).append("]; ");
/* 136 */     sb.append("servlet=[").append(getServletName()).append("]; ");
/* 137 */     sb.append(super.getDescription());
/* 138 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 143 */     return "ServletRequestHandledEvent: " + getDescription();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletRequestHandledEvent
 * JD-Core Version:    0.6.1
 */