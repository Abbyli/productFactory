/*     */ package org.springframework.web.jsf;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.event.PhaseEvent;
/*     */ import javax.faces.event.PhaseId;
/*     */ import javax.faces.event.PhaseListener;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ public class DelegatingPhaseListenerMulticaster
/*     */   implements PhaseListener
/*     */ {
/*     */   public PhaseId getPhaseId()
/*     */   {
/*  66 */     return PhaseId.ANY_PHASE;
/*     */   }
/*     */ 
/*     */   public void beforePhase(PhaseEvent event) {
/*  70 */     for (PhaseListener listener : getDelegates(event.getFacesContext()))
/*  71 */       listener.beforePhase(event);
/*     */   }
/*     */ 
/*     */   public void afterPhase(PhaseEvent event)
/*     */   {
/*  76 */     for (PhaseListener listener : getDelegates(event.getFacesContext()))
/*  77 */       listener.afterPhase(event);
/*     */   }
/*     */ 
/*     */   protected Collection<PhaseListener> getDelegates(FacesContext facesContext)
/*     */   {
/*  90 */     ListableBeanFactory bf = getBeanFactory(facesContext);
/*  91 */     return BeanFactoryUtils.beansOfTypeIncludingAncestors(bf, PhaseListener.class, true, false).values();
/*     */   }
/*     */ 
/*     */   protected ListableBeanFactory getBeanFactory(FacesContext facesContext)
/*     */   {
/* 104 */     return getWebApplicationContext(facesContext);
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext getWebApplicationContext(FacesContext facesContext)
/*     */   {
/* 115 */     return FacesContextUtils.getRequiredWebApplicationContext(facesContext);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.DelegatingPhaseListenerMulticaster
 * JD-Core Version:    0.6.1
 */