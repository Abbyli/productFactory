/*    */ package org.springframework.web.util;
/*    */ 
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ 
/*    */ public class WebAppRootListener
/*    */   implements ServletContextListener
/*    */ {
/*    */   public void contextInitialized(ServletContextEvent event)
/*    */   {
/* 56 */     WebUtils.setWebAppRootSystemProperty(event.getServletContext());
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent event) {
/* 60 */     WebUtils.removeWebAppRootSystemProperty(event.getServletContext());
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.WebAppRootListener
 * JD-Core Version:    0.6.1
 */