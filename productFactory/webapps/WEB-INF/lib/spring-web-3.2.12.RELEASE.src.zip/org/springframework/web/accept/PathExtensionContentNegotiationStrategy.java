/*     */ package org.springframework.web.accept;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class PathExtensionContentNegotiationStrategy extends AbstractMappingContentNegotiationStrategy
/*     */ {
/*  55 */   private static final boolean JAF_PRESENT = ClassUtils.isPresent("javax.activation.FileTypeMap", PathExtensionContentNegotiationStrategy.class.getClassLoader());
/*     */ 
/*  58 */   private static final Log logger = LogFactory.getLog(PathExtensionContentNegotiationStrategy.class);
/*     */ 
/*  60 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  66 */   private boolean useJaf = JAF_PRESENT;
/*     */ 
/*     */   public PathExtensionContentNegotiationStrategy(Map<String, MediaType> mediaTypes)
/*     */   {
/*  74 */     super(mediaTypes);
/*     */   }
/*     */ 
/*     */   public PathExtensionContentNegotiationStrategy()
/*     */   {
/*  82 */     super(null);
/*     */   }
/*     */ 
/*     */   public void setUseJaf(boolean useJaf)
/*     */   {
/*  90 */     this.useJaf = useJaf;
/*     */   }
/*     */ 
/*     */   protected String getMediaTypeKey(NativeWebRequest webRequest)
/*     */   {
/*  95 */     HttpServletRequest servletRequest = (HttpServletRequest)webRequest.getNativeRequest(HttpServletRequest.class);
/*  96 */     if (servletRequest == null) {
/*  97 */       logger.warn("An HttpServletRequest is required to determine the media type key");
/*  98 */       return null;
/*     */     }
/* 100 */     String path = urlPathHelper.getLookupPathForRequest(servletRequest);
/* 101 */     String filename = WebUtils.extractFullFilenameFromUrlPath(path);
/* 102 */     String extension = StringUtils.getFilenameExtension(filename);
/* 103 */     return StringUtils.hasText(extension) ? extension.toLowerCase(Locale.ENGLISH) : null;
/*     */   }
/*     */ 
/*     */   protected void handleMatch(String extension, MediaType mediaType)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected MediaType handleNoMatch(NativeWebRequest webRequest, String extension)
/*     */   {
/* 112 */     if (this.useJaf) {
/* 113 */       MediaType jafMediaType = JafMediaTypeFactory.getMediaType("file." + extension);
/* 114 */       if ((jafMediaType != null) && (!MediaType.APPLICATION_OCTET_STREAM.equals(jafMediaType))) {
/* 115 */         return jafMediaType;
/*     */       }
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  63 */     urlPathHelper.setUrlDecode(false);
/*     */   }
/*     */ 
/*     */   private static class JafMediaTypeFactory
/*     */   {
/* 130 */     private static final FileTypeMap fileTypeMap = initFileTypeMap();
/*     */ 
/*     */     private static FileTypeMap initFileTypeMap()
/*     */     {
/* 137 */       Resource resource = new ClassPathResource("org/springframework/mail/javamail/mime.types");
/* 138 */       if (resource.exists()) {
/* 139 */         if (PathExtensionContentNegotiationStrategy.logger.isTraceEnabled()) {
/* 140 */           PathExtensionContentNegotiationStrategy.logger.trace("Loading Java Activation Framework FileTypeMap from " + resource);
/*     */         }
/* 142 */         InputStream inputStream = null;
/*     */         try {
/* 144 */           inputStream = resource.getInputStream();
/* 145 */           return new MimetypesFileTypeMap(inputStream);
/*     */         }
/*     */         catch (IOException ex)
/*     */         {
/*     */         }
/*     */         finally {
/* 151 */           if (inputStream != null) {
/*     */             try {
/* 153 */               inputStream.close();
/*     */             }
/*     */             catch (IOException ex)
/*     */             {
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 161 */       if (PathExtensionContentNegotiationStrategy.logger.isTraceEnabled()) {
/* 162 */         PathExtensionContentNegotiationStrategy.logger.trace("Loading default Java Activation Framework FileTypeMap");
/*     */       }
/* 164 */       return FileTypeMap.getDefaultFileTypeMap();
/*     */     }
/*     */ 
/*     */     public static MediaType getMediaType(String filename) {
/* 168 */       String mediaType = fileTypeMap.getContentType(filename);
/* 169 */       return StringUtils.hasText(mediaType) ? MediaType.parseMediaType(mediaType) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.PathExtensionContentNegotiationStrategy
 * JD-Core Version:    0.6.1
 */