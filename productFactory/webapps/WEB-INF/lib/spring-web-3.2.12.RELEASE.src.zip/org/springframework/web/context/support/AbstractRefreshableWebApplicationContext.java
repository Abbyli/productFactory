/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.support.AbstractRefreshableConfigApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ import org.springframework.ui.context.support.UiApplicationContextUtils;
/*     */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*     */ import org.springframework.web.context.ConfigurableWebEnvironment;
/*     */ import org.springframework.web.context.ServletConfigAware;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public abstract class AbstractRefreshableWebApplicationContext extends AbstractRefreshableConfigApplicationContext
/*     */   implements ConfigurableWebApplicationContext, ThemeSource
/*     */ {
/*     */   private ServletContext servletContext;
/*     */   private ServletConfig servletConfig;
/*     */   private String namespace;
/*     */   private ThemeSource themeSource;
/*     */ 
/*     */   public AbstractRefreshableWebApplicationContext()
/*     */   {
/*  96 */     setDisplayName("Root WebApplicationContext");
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext)
/*     */   {
/* 101 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public ServletContext getServletContext() {
/* 105 */     return this.servletContext;
/*     */   }
/*     */ 
/*     */   public void setServletConfig(ServletConfig servletConfig) {
/* 109 */     this.servletConfig = servletConfig;
/* 110 */     if ((servletConfig != null) && (this.servletContext == null))
/* 111 */       setServletContext(servletConfig.getServletContext());
/*     */   }
/*     */ 
/*     */   public ServletConfig getServletConfig()
/*     */   {
/* 116 */     return this.servletConfig;
/*     */   }
/*     */ 
/*     */   public void setNamespace(String namespace) {
/* 120 */     this.namespace = namespace;
/* 121 */     if (namespace != null)
/* 122 */       setDisplayName("WebApplicationContext for namespace '" + namespace + "'");
/*     */   }
/*     */ 
/*     */   public String getNamespace()
/*     */   {
/* 127 */     return this.namespace;
/*     */   }
/*     */ 
/*     */   public String[] getConfigLocations()
/*     */   {
/* 132 */     return super.getConfigLocations();
/*     */   }
/*     */ 
/*     */   public String getApplicationName()
/*     */   {
/* 137 */     if (this.servletContext == null) {
/* 138 */       return "";
/*     */     }
/* 140 */     if ((this.servletContext.getMajorVersion() == 2) && (this.servletContext.getMinorVersion() < 5)) {
/* 141 */       String name = this.servletContext.getServletContextName();
/* 142 */       return name != null ? name : "";
/*     */     }
/*     */ 
/* 146 */     return this.servletContext.getContextPath();
/*     */   }
/*     */ 
/*     */   protected ConfigurableEnvironment createEnvironment()
/*     */   {
/* 156 */     return new StandardServletEnvironment();
/*     */   }
/*     */ 
/*     */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 164 */     beanFactory.addBeanPostProcessor(new ServletContextAwareProcessor(this.servletContext, this.servletConfig));
/* 165 */     beanFactory.ignoreDependencyInterface(ServletContextAware.class);
/* 166 */     beanFactory.ignoreDependencyInterface(ServletConfigAware.class);
/*     */ 
/* 168 */     WebApplicationContextUtils.registerWebApplicationScopes(beanFactory, this.servletContext);
/* 169 */     WebApplicationContextUtils.registerEnvironmentBeans(beanFactory, this.servletContext, this.servletConfig);
/*     */   }
/*     */ 
/*     */   protected Resource getResourceByPath(String path)
/*     */   {
/* 178 */     return new ServletContextResource(this.servletContext, path);
/*     */   }
/*     */ 
/*     */   protected ResourcePatternResolver getResourcePatternResolver()
/*     */   {
/* 187 */     return new ServletContextResourcePatternResolver(this);
/*     */   }
/*     */ 
/*     */   protected void onRefresh()
/*     */   {
/* 195 */     this.themeSource = UiApplicationContextUtils.initThemeSource(this);
/*     */   }
/*     */ 
/*     */   protected void initPropertySources()
/*     */   {
/* 204 */     ConfigurableEnvironment env = getEnvironment();
/* 205 */     if ((env instanceof ConfigurableWebEnvironment))
/* 206 */       ((ConfigurableWebEnvironment)env).initPropertySources(this.servletContext, this.servletConfig);
/*     */   }
/*     */ 
/*     */   public Theme getTheme(String themeName)
/*     */   {
/* 211 */     return this.themeSource.getTheme(themeName);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.AbstractRefreshableWebApplicationContext
 * JD-Core Version:    0.6.1
 */