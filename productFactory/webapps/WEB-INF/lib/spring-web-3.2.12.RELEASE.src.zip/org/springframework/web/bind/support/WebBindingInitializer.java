package org.springframework.web.bind.support;

import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.context.request.WebRequest;

public abstract interface WebBindingInitializer
{
  public abstract void initBinder(WebDataBinder paramWebDataBinder, WebRequest paramWebRequest);
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.WebBindingInitializer
 * JD-Core Version:    0.6.1
 */