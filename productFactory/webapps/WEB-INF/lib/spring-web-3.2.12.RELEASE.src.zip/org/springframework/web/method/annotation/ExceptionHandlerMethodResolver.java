/*     */ package org.springframework.web.method.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.ExceptionDepthComparator;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodFilter;
/*     */ import org.springframework.web.bind.annotation.ExceptionHandler;
/*     */ import org.springframework.web.method.HandlerMethodSelector;
/*     */ 
/*     */ public class ExceptionHandlerMethodResolver
/*     */ {
/*  48 */   public static final ReflectionUtils.MethodFilter EXCEPTION_HANDLER_METHODS = new ReflectionUtils.MethodFilter() {
/*     */     public boolean matches(Method method) {
/*  50 */       return AnnotationUtils.findAnnotation(method, ExceptionHandler.class) != null;
/*     */     }
/*  48 */   };
/*     */ 
/*  57 */   private static final Method NO_METHOD_FOUND = ClassUtils.getMethodIfAvailable(System.class, "currentTimeMillis", new Class[0]);
/*     */ 
/*  60 */   private final Map<Class<? extends Throwable>, Method> mappedMethods = new ConcurrentHashMap(16);
/*     */ 
/*  63 */   private final Map<Class<? extends Throwable>, Method> exceptionLookupCache = new ConcurrentHashMap(16);
/*     */ 
/*     */   public ExceptionHandlerMethodResolver(Class<?> handlerType)
/*     */   {
/*  72 */     for (Iterator i$ = HandlerMethodSelector.selectMethods(handlerType, EXCEPTION_HANDLER_METHODS).iterator(); i$.hasNext(); ) { method = (Method)i$.next();
/*  73 */       for (Class exceptionType : detectExceptionMappings(method))
/*  74 */         addExceptionMapping(exceptionType, method);
/*     */     }
/*     */     Method method;
/*     */   }
/*     */ 
/*     */   private List<Class<? extends Throwable>> detectExceptionMappings(Method method)
/*     */   {
/*  86 */     List result = new ArrayList();
/*  87 */     detectAnnotationExceptionMappings(method, result);
/*  88 */     if (result.isEmpty()) {
/*  89 */       for (Class paramType : method.getParameterTypes()) {
/*  90 */         if (Throwable.class.isAssignableFrom(paramType)) {
/*  91 */           result.add(paramType);
/*     */         }
/*     */       }
/*     */     }
/*  95 */     Assert.notEmpty(result, "No exception types mapped to {" + method + "}");
/*  96 */     return result;
/*     */   }
/*     */ 
/*     */   protected void detectAnnotationExceptionMappings(Method method, List<Class<? extends Throwable>> result) {
/* 100 */     ExceptionHandler annot = (ExceptionHandler)AnnotationUtils.findAnnotation(method, ExceptionHandler.class);
/* 101 */     result.addAll(Arrays.asList(annot.value()));
/*     */   }
/*     */ 
/*     */   private void addExceptionMapping(Class<? extends Throwable> exceptionType, Method method) {
/* 105 */     Method oldMethod = (Method)this.mappedMethods.put(exceptionType, method);
/* 106 */     if ((oldMethod != null) && (!oldMethod.equals(method)))
/* 107 */       throw new IllegalStateException("Ambiguous @ExceptionHandler method mapped for [" + exceptionType + "]: {" + oldMethod + ", " + method + "}.");
/*     */   }
/*     */ 
/*     */   public boolean hasExceptionMappings()
/*     */   {
/* 117 */     return !this.mappedMethods.isEmpty();
/*     */   }
/*     */ 
/*     */   public Method resolveMethod(Exception exception)
/*     */   {
/* 127 */     return resolveMethodByExceptionType(exception.getClass());
/*     */   }
/*     */ 
/*     */   public Method resolveMethodByExceptionType(Class<? extends Exception> exceptionType)
/*     */   {
/* 137 */     Method method = (Method)this.exceptionLookupCache.get(exceptionType);
/* 138 */     if (method == null) {
/* 139 */       method = getMappedMethod(exceptionType);
/* 140 */       this.exceptionLookupCache.put(exceptionType, method != null ? method : NO_METHOD_FOUND);
/*     */     }
/* 142 */     return method != NO_METHOD_FOUND ? method : null;
/*     */   }
/*     */ 
/*     */   private Method getMappedMethod(Class<? extends Exception> exceptionType)
/*     */   {
/* 149 */     List matches = new ArrayList();
/* 150 */     for (Class mappedException : this.mappedMethods.keySet()) {
/* 151 */       if (mappedException.isAssignableFrom(exceptionType)) {
/* 152 */         matches.add(mappedException);
/*     */       }
/*     */     }
/* 155 */     if (!matches.isEmpty()) {
/* 156 */       Collections.sort(matches, new ExceptionDepthComparator(exceptionType));
/* 157 */       return (Method)this.mappedMethods.get(matches.get(0));
/*     */     }
/*     */ 
/* 160 */     return null;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ExceptionHandlerMethodResolver
 * JD-Core Version:    0.6.1
 */