package org.springframework.web.context.request.async;

import org.springframework.web.context.request.NativeWebRequest;

public abstract interface DeferredResultProcessingInterceptor
{
  public abstract <T> void beforeConcurrentHandling(NativeWebRequest paramNativeWebRequest, DeferredResult<T> paramDeferredResult)
    throws Exception;

  public abstract <T> void preProcess(NativeWebRequest paramNativeWebRequest, DeferredResult<T> paramDeferredResult)
    throws Exception;

  public abstract <T> void postProcess(NativeWebRequest paramNativeWebRequest, DeferredResult<T> paramDeferredResult, Object paramObject)
    throws Exception;

  public abstract <T> boolean handleTimeout(NativeWebRequest paramNativeWebRequest, DeferredResult<T> paramDeferredResult)
    throws Exception;

  public abstract <T> void afterCompletion(NativeWebRequest paramNativeWebRequest, DeferredResult<T> paramDeferredResult)
    throws Exception;
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.DeferredResultProcessingInterceptor
 * JD-Core Version:    0.6.1
 */