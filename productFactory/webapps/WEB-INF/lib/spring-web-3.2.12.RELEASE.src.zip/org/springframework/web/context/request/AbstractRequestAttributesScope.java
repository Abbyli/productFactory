/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.beans.factory.config.Scope;
/*    */ 
/*    */ public abstract class AbstractRequestAttributesScope
/*    */   implements Scope
/*    */ {
/*    */   public Object get(String name, ObjectFactory objectFactory)
/*    */   {
/* 40 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 41 */     Object scopedObject = attributes.getAttribute(name, getScope());
/* 42 */     if (scopedObject == null) {
/* 43 */       scopedObject = objectFactory.getObject();
/* 44 */       attributes.setAttribute(name, scopedObject, getScope());
/*    */     }
/* 46 */     return scopedObject;
/*    */   }
/*    */ 
/*    */   public Object remove(String name) {
/* 50 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 51 */     Object scopedObject = attributes.getAttribute(name, getScope());
/* 52 */     if (scopedObject != null) {
/* 53 */       attributes.removeAttribute(name, getScope());
/* 54 */       return scopedObject;
/*    */     }
/*    */ 
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */   public void registerDestructionCallback(String name, Runnable callback)
/*    */   {
/* 62 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 63 */     attributes.registerDestructionCallback(name, callback, getScope());
/*    */   }
/*    */ 
/*    */   public Object resolveContextualObject(String key) {
/* 67 */     RequestAttributes attributes = RequestContextHolder.currentRequestAttributes();
/* 68 */     return attributes.resolveReference(key);
/*    */   }
/*    */ 
/*    */   protected abstract int getScope();
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.AbstractRequestAttributesScope
 * JD-Core Version:    0.6.1
 */