/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.DigestUtils;
/*     */ import org.springframework.util.StreamUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ShallowEtagHeaderFilter extends OncePerRequestFilter
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/*  70 */     HttpServletResponse responseToUse = response;
/*  71 */     if (!isAsyncDispatch(request)) {
/*  72 */       responseToUse = new ShallowEtagResponseWrapper(response);
/*     */     }
/*     */ 
/*  75 */     filterChain.doFilter(request, responseToUse);
/*     */ 
/*  77 */     if (!isAsyncStarted(request))
/*  78 */       updateResponse(request, responseToUse);
/*     */   }
/*     */ 
/*     */   private void updateResponse(HttpServletRequest request, HttpServletResponse response) throws IOException
/*     */   {
/*  83 */     ShallowEtagResponseWrapper responseWrapper = (ShallowEtagResponseWrapper)WebUtils.getNativeResponse(response, ShallowEtagResponseWrapper.class);
/*     */ 
/*  85 */     Assert.notNull(responseWrapper, "ShallowEtagResponseWrapper not found");
/*     */ 
/*  87 */     HttpServletResponse rawResponse = (HttpServletResponse)responseWrapper.getResponse();
/*  88 */     int statusCode = responseWrapper.getStatusCode();
/*  89 */     byte[] body = responseWrapper.toByteArray();
/*     */ 
/*  91 */     if (isEligibleForEtag(request, responseWrapper, statusCode, body)) {
/*  92 */       String responseETag = generateETagHeaderValue(body);
/*  93 */       rawResponse.setHeader("ETag", responseETag);
/*  94 */       String requestETag = request.getHeader("If-None-Match");
/*  95 */       if (responseETag.equals(requestETag)) {
/*  96 */         if (this.logger.isTraceEnabled()) {
/*  97 */           this.logger.trace("ETag [" + responseETag + "] equal to If-None-Match, sending 304");
/*     */         }
/*  99 */         rawResponse.setStatus(304);
/*     */       }
/*     */       else {
/* 102 */         if (this.logger.isTraceEnabled()) {
/* 103 */           this.logger.trace("ETag [" + responseETag + "] not equal to If-None-Match [" + requestETag + "], sending normal response");
/*     */         }
/*     */ 
/* 106 */         copyBodyToResponse(body, rawResponse);
/*     */       }
/*     */     }
/*     */     else {
/* 110 */       if (this.logger.isTraceEnabled()) {
/* 111 */         this.logger.trace("Response with status code [" + statusCode + "] not eligible for ETag");
/*     */       }
/* 113 */       copyBodyToResponse(body, rawResponse);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void copyBodyToResponse(byte[] body, HttpServletResponse response) throws IOException {
/* 118 */     if (body.length > 0) {
/* 119 */       response.setContentLength(body.length);
/* 120 */       StreamUtils.copy(body, response.getOutputStream());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleForEtag(HttpServletRequest request, HttpServletResponse response, int responseStatusCode, byte[] responseBody)
/*     */   {
/* 136 */     return (responseStatusCode >= 200) && (responseStatusCode < 300);
/*     */   }
/*     */ 
/*     */   protected String generateETagHeaderValue(byte[] bytes)
/*     */   {
/* 147 */     StringBuilder builder = new StringBuilder("\"0");
/* 148 */     DigestUtils.appendMd5DigestAsHex(bytes, builder);
/* 149 */     builder.append('"');
/* 150 */     return builder.toString();
/*     */   }
/*     */ 
/*     */   private static class ShallowEtagResponseWrapper extends HttpServletResponseWrapper
/*     */   {
/* 161 */     private final ByteArrayOutputStream content = new ByteArrayOutputStream(1024);
/*     */ 
/* 163 */     private final ServletOutputStream outputStream = new ResponseServletOutputStream(null);
/*     */     private PrintWriter writer;
/* 167 */     private int statusCode = 200;
/*     */ 
/*     */     public ShallowEtagResponseWrapper(HttpServletResponse response) {
/* 170 */       super();
/*     */     }
/*     */ 
/*     */     public void setStatus(int sc)
/*     */     {
/* 175 */       super.setStatus(sc);
/* 176 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void setStatus(int sc, String sm)
/*     */     {
/* 182 */       super.setStatus(sc, sm);
/* 183 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void sendError(int sc) throws IOException
/*     */     {
/* 188 */       super.sendError(sc);
/* 189 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void sendError(int sc, String msg) throws IOException
/*     */     {
/* 194 */       super.sendError(sc, msg);
/* 195 */       this.statusCode = sc;
/*     */     }
/*     */ 
/*     */     public void setContentLength(int len)
/*     */     {
/*     */     }
/*     */ 
/*     */     public ServletOutputStream getOutputStream()
/*     */     {
/* 204 */       return this.outputStream;
/*     */     }
/*     */ 
/*     */     public PrintWriter getWriter() throws IOException
/*     */     {
/* 209 */       if (this.writer == null) {
/* 210 */         String characterEncoding = getCharacterEncoding();
/* 211 */         this.writer = (characterEncoding != null ? new ResponsePrintWriter(characterEncoding) : new ResponsePrintWriter("ISO-8859-1"));
/*     */       }
/*     */ 
/* 214 */       return this.writer;
/*     */     }
/*     */ 
/*     */     public void reset()
/*     */     {
/* 219 */       super.reset();
/* 220 */       resetBuffer();
/*     */     }
/*     */ 
/*     */     public void resetBuffer()
/*     */     {
/* 225 */       this.content.reset();
/*     */     }
/*     */ 
/*     */     public int getStatusCode() {
/* 229 */       return this.statusCode;
/*     */     }
/*     */ 
/*     */     public byte[] toByteArray() {
/* 233 */       return this.content.toByteArray();
/*     */     }
/*     */ 
/*     */     private class ResponsePrintWriter extends PrintWriter
/*     */     {
/*     */       public ResponsePrintWriter(String characterEncoding)
/*     */         throws UnsupportedEncodingException
/*     */       {
/* 254 */         super();
/*     */       }
/*     */ 
/*     */       public void write(char[] buf, int off, int len)
/*     */       {
/* 259 */         super.write(buf, off, len);
/* 260 */         super.flush();
/*     */       }
/*     */ 
/*     */       public void write(String s, int off, int len)
/*     */       {
/* 265 */         super.write(s, off, len);
/* 266 */         super.flush();
/*     */       }
/*     */ 
/*     */       public void write(int c)
/*     */       {
/* 271 */         super.write(c);
/* 272 */         super.flush();
/*     */       }
/*     */     }
/*     */ 
/*     */     private class ResponseServletOutputStream extends ServletOutputStream
/*     */     {
/*     */       private ResponseServletOutputStream()
/*     */       {
/*     */       }
/*     */ 
/*     */       public void write(int b)
/*     */         throws IOException
/*     */       {
/* 241 */         ShallowEtagHeaderFilter.ShallowEtagResponseWrapper.this.content.write(b);
/*     */       }
/*     */ 
/*     */       public void write(byte[] b, int off, int len) throws IOException
/*     */       {
/* 246 */         ShallowEtagHeaderFilter.ShallowEtagResponseWrapper.this.content.write(b, off, len);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.ShallowEtagHeaderFilter
 * JD-Core Version:    0.6.1
 */