/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractRequestLoggingFilter extends OncePerRequestFilter
/*     */ {
/*     */   public static final String DEFAULT_BEFORE_MESSAGE_PREFIX = "Before request [";
/*     */   public static final String DEFAULT_BEFORE_MESSAGE_SUFFIX = "]";
/*     */   public static final String DEFAULT_AFTER_MESSAGE_PREFIX = "After request [";
/*     */   public static final String DEFAULT_AFTER_MESSAGE_SUFFIX = "]";
/*     */   private static final int DEFAULT_MAX_PAYLOAD_LENGTH = 50;
/*     */   private boolean includeQueryString;
/*     */   private boolean includeClientInfo;
/*     */   private boolean includePayload;
/*     */   private int maxPayloadLength;
/*     */   private String beforeMessagePrefix;
/*     */   private String beforeMessageSuffix;
/*     */   private String afterMessagePrefix;
/*     */   private String afterMessageSuffix;
/*     */ 
/*     */   public AbstractRequestLoggingFilter()
/*     */   {
/*  72 */     this.includeQueryString = false;
/*     */ 
/*  74 */     this.includeClientInfo = false;
/*     */ 
/*  76 */     this.includePayload = false;
/*     */ 
/*  78 */     this.maxPayloadLength = 50;
/*     */ 
/*  80 */     this.beforeMessagePrefix = "Before request [";
/*     */ 
/*  82 */     this.beforeMessageSuffix = "]";
/*     */ 
/*  84 */     this.afterMessagePrefix = "After request [";
/*     */ 
/*  86 */     this.afterMessageSuffix = "]";
/*     */   }
/*     */ 
/*     */   public void setIncludeQueryString(boolean includeQueryString)
/*     */   {
/*  95 */     this.includeQueryString = includeQueryString;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeQueryString()
/*     */   {
/* 102 */     return this.includeQueryString;
/*     */   }
/*     */ 
/*     */   public void setIncludeClientInfo(boolean includeClientInfo)
/*     */   {
/* 111 */     this.includeClientInfo = includeClientInfo;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeClientInfo()
/*     */   {
/* 118 */     return this.includeClientInfo;
/*     */   }
/*     */ 
/*     */   public void setIncludePayload(boolean includePayload)
/*     */   {
/* 128 */     this.includePayload = includePayload;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludePayload()
/*     */   {
/* 135 */     return this.includePayload;
/*     */   }
/*     */ 
/*     */   public void setMaxPayloadLength(int maxPayloadLength)
/*     */   {
/* 142 */     Assert.isTrue(maxPayloadLength >= 0, "'maxPayloadLength' should be larger than or equal to 0");
/* 143 */     this.maxPayloadLength = maxPayloadLength;
/*     */   }
/*     */ 
/*     */   protected int getMaxPayloadLength()
/*     */   {
/* 150 */     return this.maxPayloadLength;
/*     */   }
/*     */ 
/*     */   public void setBeforeMessagePrefix(String beforeMessagePrefix)
/*     */   {
/* 157 */     this.beforeMessagePrefix = beforeMessagePrefix;
/*     */   }
/*     */ 
/*     */   public void setBeforeMessageSuffix(String beforeMessageSuffix)
/*     */   {
/* 164 */     this.beforeMessageSuffix = beforeMessageSuffix;
/*     */   }
/*     */ 
/*     */   public void setAfterMessagePrefix(String afterMessagePrefix)
/*     */   {
/* 171 */     this.afterMessagePrefix = afterMessagePrefix;
/*     */   }
/*     */ 
/*     */   public void setAfterMessageSuffix(String afterMessageSuffix)
/*     */   {
/* 178 */     this.afterMessageSuffix = afterMessageSuffix;
/*     */   }
/*     */ 
/*     */   protected boolean shouldNotFilterAsyncDispatch()
/*     */   {
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 202 */     boolean isFirstRequest = !isAsyncDispatch(request);
/*     */ 
/* 204 */     if ((isIncludePayload()) && 
/* 205 */       (isFirstRequest)) {
/* 206 */       request = new RequestCachingRequestWrapper(request, null);
/*     */     }
/*     */ 
/* 210 */     if (isFirstRequest)
/* 211 */       beforeRequest(request, getBeforeMessage(request));
/*     */     try
/*     */     {
/* 214 */       filterChain.doFilter(request, response);
/*     */     }
/*     */     finally {
/* 217 */       if (!isAsyncStarted(request))
/* 218 */         afterRequest(request, getAfterMessage(request));
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getBeforeMessage(HttpServletRequest request)
/*     */   {
/* 228 */     return createMessage(request, this.beforeMessagePrefix, this.beforeMessageSuffix);
/*     */   }
/*     */ 
/*     */   private String getAfterMessage(HttpServletRequest request)
/*     */   {
/* 236 */     return createMessage(request, this.afterMessagePrefix, this.afterMessageSuffix);
/*     */   }
/*     */ 
/*     */   protected String createMessage(HttpServletRequest request, String prefix, String suffix)
/*     */   {
/* 248 */     StringBuilder msg = new StringBuilder();
/* 249 */     msg.append(prefix);
/* 250 */     msg.append("uri=").append(request.getRequestURI());
/* 251 */     if (isIncludeQueryString()) {
/* 252 */       msg.append('?').append(request.getQueryString());
/*     */     }
/* 254 */     if (isIncludeClientInfo()) {
/* 255 */       String client = request.getRemoteAddr();
/* 256 */       if (StringUtils.hasLength(client)) {
/* 257 */         msg.append(";client=").append(client);
/*     */       }
/* 259 */       HttpSession session = request.getSession(false);
/* 260 */       if (session != null) {
/* 261 */         msg.append(";session=").append(session.getId());
/*     */       }
/* 263 */       String user = request.getRemoteUser();
/* 264 */       if (user != null) {
/* 265 */         msg.append(";user=").append(user);
/*     */       }
/*     */     }
/* 268 */     if ((isIncludePayload()) && ((request instanceof RequestCachingRequestWrapper))) {
/* 269 */       RequestCachingRequestWrapper wrapper = (RequestCachingRequestWrapper)request;
/* 270 */       byte[] buf = wrapper.getContentAsByteArray();
/* 271 */       if (buf.length > 0) { int length = Math.min(buf.length, getMaxPayloadLength());
/*     */         String payload;
/*     */         try {
/* 275 */           payload = new String(buf, 0, length, wrapper.getCharacterEncoding());
/*     */         }
/*     */         catch (UnsupportedEncodingException e) {
/* 278 */           payload = "[unknown]";
/*     */         }
/* 280 */         msg.append(";payload=").append(payload);
/*     */       }
/*     */     }
/*     */ 
/* 284 */     msg.append(suffix);
/* 285 */     return msg.toString();
/*     */   }
/*     */ 
/*     */   protected abstract void beforeRequest(HttpServletRequest paramHttpServletRequest, String paramString);
/*     */ 
/*     */   protected abstract void afterRequest(HttpServletRequest paramHttpServletRequest, String paramString);
/*     */ 
/*     */   private static class RequestCachingRequestWrapper extends HttpServletRequestWrapper
/*     */   {
/* 307 */     private final ByteArrayOutputStream cachedContent = new ByteArrayOutputStream(1024);
/*     */     private final ServletInputStream inputStream;
/*     */     private BufferedReader reader;
/*     */ 
/*     */     private RequestCachingRequestWrapper(HttpServletRequest request)
/*     */       throws IOException
/*     */     {
/* 314 */       super();
/* 315 */       this.inputStream = new RequestCachingInputStream(request.getInputStream());
/*     */     }
/*     */ 
/*     */     public ServletInputStream getInputStream() throws IOException
/*     */     {
/* 320 */       return this.inputStream;
/*     */     }
/*     */ 
/*     */     public String getCharacterEncoding()
/*     */     {
/* 325 */       String enc = super.getCharacterEncoding();
/* 326 */       return enc != null ? enc : "ISO-8859-1";
/*     */     }
/*     */ 
/*     */     public BufferedReader getReader() throws IOException
/*     */     {
/* 331 */       if (this.reader == null) {
/* 332 */         this.reader = new BufferedReader(new InputStreamReader(this.inputStream, getCharacterEncoding()));
/*     */       }
/* 334 */       return this.reader;
/*     */     }
/*     */ 
/*     */     private byte[] getContentAsByteArray() {
/* 338 */       return this.cachedContent.toByteArray();
/*     */     }
/*     */ 
/*     */     private class RequestCachingInputStream extends ServletInputStream
/*     */     {
/*     */       private final ServletInputStream is;
/*     */ 
/*     */       public RequestCachingInputStream(ServletInputStream is)
/*     */       {
/* 347 */         this.is = is;
/*     */       }
/*     */ 
/*     */       public int read() throws IOException
/*     */       {
/* 352 */         int ch = this.is.read();
/* 353 */         if (ch != -1) {
/* 354 */           AbstractRequestLoggingFilter.RequestCachingRequestWrapper.this.cachedContent.write(ch);
/*     */         }
/* 356 */         return ch;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.AbstractRequestLoggingFilter
 * JD-Core Version:    0.6.1
 */