/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ 
/*     */ public class HandlerMethodReturnValueHandlerComposite
/*     */   implements HandlerMethodReturnValueHandler
/*     */ {
/*  38 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  40 */   private final List<HandlerMethodReturnValueHandler> returnValueHandlers = new ArrayList();
/*     */ 
/*     */   public List<HandlerMethodReturnValueHandler> getHandlers()
/*     */   {
/*  47 */     return Collections.unmodifiableList(this.returnValueHandlers);
/*     */   }
/*     */ 
/*     */   public boolean supportsReturnType(MethodParameter returnType)
/*     */   {
/*  55 */     return getReturnValueHandler(returnType) != null;
/*     */   }
/*     */ 
/*     */   public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/*  67 */     HandlerMethodReturnValueHandler handler = getReturnValueHandler(returnType);
/*  68 */     Assert.notNull(handler, "Unknown return value type [" + returnType.getParameterType().getName() + "]");
/*  69 */     handler.handleReturnValue(returnValue, returnType, mavContainer, webRequest);
/*     */   }
/*     */ 
/*     */   private HandlerMethodReturnValueHandler getReturnValueHandler(MethodParameter returnType)
/*     */   {
/*  76 */     for (HandlerMethodReturnValueHandler returnValueHandler : this.returnValueHandlers) {
/*  77 */       if (this.logger.isTraceEnabled()) {
/*  78 */         this.logger.trace("Testing if return value handler [" + returnValueHandler + "] supports [" + returnType.getGenericParameterType() + "]");
/*     */       }
/*     */ 
/*  81 */       if (returnValueHandler.supportsReturnType(returnType)) {
/*  82 */         return returnValueHandler;
/*     */       }
/*     */     }
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   public HandlerMethodReturnValueHandlerComposite addHandler(HandlerMethodReturnValueHandler returnValuehandler)
/*     */   {
/*  92 */     this.returnValueHandlers.add(returnValuehandler);
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */   public HandlerMethodReturnValueHandlerComposite addHandlers(List<? extends HandlerMethodReturnValueHandler> returnValueHandlers)
/*     */   {
/* 101 */     if (returnValueHandlers != null) {
/* 102 */       for (HandlerMethodReturnValueHandler handler : returnValueHandlers) {
/* 103 */         this.returnValueHandlers.add(handler);
/*     */       }
/*     */     }
/* 106 */     return this;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite
 * JD-Core Version:    0.6.1
 */