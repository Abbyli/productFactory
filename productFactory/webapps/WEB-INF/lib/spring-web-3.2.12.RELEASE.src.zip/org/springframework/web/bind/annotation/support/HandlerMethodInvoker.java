/*     */ package org.springframework.web.bind.annotation.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.annotation.Value;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.http.HttpEntity;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpInputMessage;
/*     */ import org.springframework.http.HttpOutputMessage;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.ui.ExtendedModelMap;
/*     */ import org.springframework.ui.Model;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.LinkedMultiValueMap;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.validation.BindException;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.HttpMediaTypeNotSupportedException;
/*     */ import org.springframework.web.bind.WebDataBinder;
/*     */ import org.springframework.web.bind.annotation.CookieValue;
/*     */ import org.springframework.web.bind.annotation.InitBinder;
/*     */ import org.springframework.web.bind.annotation.ModelAttribute;
/*     */ import org.springframework.web.bind.annotation.PathVariable;
/*     */ import org.springframework.web.bind.annotation.RequestBody;
/*     */ import org.springframework.web.bind.annotation.RequestHeader;
/*     */ import org.springframework.web.bind.annotation.RequestParam;
/*     */ import org.springframework.web.bind.support.DefaultSessionAttributeStore;
/*     */ import org.springframework.web.bind.support.SessionAttributeStore;
/*     */ import org.springframework.web.bind.support.SessionStatus;
/*     */ import org.springframework.web.bind.support.SimpleSessionStatus;
/*     */ import org.springframework.web.bind.support.WebArgumentResolver;
/*     */ import org.springframework.web.bind.support.WebBindingInitializer;
/*     */ import org.springframework.web.bind.support.WebRequestDataBinder;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.context.request.WebRequest;
/*     */ import org.springframework.web.multipart.MultipartRequest;
/*     */ 
/*     */ public class HandlerMethodInvoker
/*     */ {
/*  98 */   private static final String MODEL_KEY_PREFIX_STALE = SessionAttributeStore.class.getName() + ".STALE.";
/*     */ 
/* 101 */   private static final Log logger = LogFactory.getLog(HandlerMethodInvoker.class);
/*     */   private final HandlerMethodResolver methodResolver;
/*     */   private final WebBindingInitializer bindingInitializer;
/*     */   private final SessionAttributeStore sessionAttributeStore;
/*     */   private final ParameterNameDiscoverer parameterNameDiscoverer;
/*     */   private final WebArgumentResolver[] customArgumentResolvers;
/*     */   private final HttpMessageConverter[] messageConverters;
/* 115 */   private final SimpleSessionStatus sessionStatus = new SimpleSessionStatus();
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver)
/*     */   {
/* 119 */     this(methodResolver, null);
/*     */   }
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver, WebBindingInitializer bindingInitializer) {
/* 123 */     this(methodResolver, bindingInitializer, new DefaultSessionAttributeStore(), null, null, null);
/*     */   }
/*     */ 
/*     */   public HandlerMethodInvoker(HandlerMethodResolver methodResolver, WebBindingInitializer bindingInitializer, SessionAttributeStore sessionAttributeStore, ParameterNameDiscoverer parameterNameDiscoverer, WebArgumentResolver[] customArgumentResolvers, HttpMessageConverter[] messageConverters)
/*     */   {
/* 130 */     this.methodResolver = methodResolver;
/* 131 */     this.bindingInitializer = bindingInitializer;
/* 132 */     this.sessionAttributeStore = sessionAttributeStore;
/* 133 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/* 134 */     this.customArgumentResolvers = customArgumentResolvers;
/* 135 */     this.messageConverters = messageConverters;
/*     */   }
/*     */ 
/*     */   public final Object invokeHandlerMethod(Method handlerMethod, Object handler, NativeWebRequest webRequest, ExtendedModelMap implicitModel)
/*     */     throws Exception
/*     */   {
/* 142 */     Method handlerMethodToInvoke = BridgeMethodResolver.findBridgedMethod(handlerMethod);
/*     */     try {
/* 144 */       boolean debug = logger.isDebugEnabled();
/* 145 */       for (String attrName : this.methodResolver.getActualSessionAttributeNames()) {
/* 146 */         Object attrValue = this.sessionAttributeStore.retrieveAttribute(webRequest, attrName);
/* 147 */         if (attrValue != null) {
/* 148 */           implicitModel.addAttribute(attrName, attrValue);
/*     */         }
/*     */       }
/* 151 */       for (Method attributeMethod : this.methodResolver.getModelAttributeMethods()) {
/* 152 */         Method attributeMethodToInvoke = BridgeMethodResolver.findBridgedMethod(attributeMethod);
/* 153 */         Object[] args = resolveHandlerArguments(attributeMethodToInvoke, handler, webRequest, implicitModel);
/* 154 */         if (debug) {
/* 155 */           logger.debug("Invoking model attribute method: " + attributeMethodToInvoke);
/*     */         }
/* 157 */         String attrName = ((ModelAttribute)AnnotationUtils.findAnnotation(attributeMethod, ModelAttribute.class)).value();
/* 158 */         if (("".equals(attrName)) || (!implicitModel.containsAttribute(attrName)))
/*     */         {
/* 161 */           ReflectionUtils.makeAccessible(attributeMethodToInvoke);
/* 162 */           Object attrValue = attributeMethodToInvoke.invoke(handler, args);
/* 163 */           if ("".equals(attrName)) {
/* 164 */             Class resolvedType = GenericTypeResolver.resolveReturnType(attributeMethodToInvoke, handler.getClass());
/* 165 */             attrName = Conventions.getVariableNameForReturnType(attributeMethodToInvoke, resolvedType, attrValue);
/*     */           }
/* 167 */           if (!implicitModel.containsAttribute(attrName))
/* 168 */             implicitModel.addAttribute(attrName, attrValue);
/*     */         }
/*     */       }
/* 171 */       Object[] args = resolveHandlerArguments(handlerMethodToInvoke, handler, webRequest, implicitModel);
/* 172 */       if (debug) {
/* 173 */         logger.debug("Invoking request handler method: " + handlerMethodToInvoke);
/*     */       }
/* 175 */       ReflectionUtils.makeAccessible(handlerMethodToInvoke);
/* 176 */       return handlerMethodToInvoke.invoke(handler, args);
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 181 */       throw new HandlerMethodInvocationException(handlerMethodToInvoke, ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 185 */       ReflectionUtils.rethrowException(ex.getTargetException());
/* 186 */     }return null;
/*     */   }
/*     */ 
/*     */   public final void updateModelAttributes(Object handler, Map<String, Object> mavModel, ExtendedModelMap implicitModel, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 193 */     if ((this.methodResolver.hasSessionAttributes()) && (this.sessionStatus.isComplete())) {
/* 194 */       for (String attrName : this.methodResolver.getActualSessionAttributeNames()) {
/* 195 */         this.sessionAttributeStore.cleanupAttribute(webRequest, attrName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 201 */     Map model = mavModel != null ? mavModel : implicitModel;
/* 202 */     if (model != null)
/*     */       try {
/* 204 */         String[] originalAttrNames = (String[])model.keySet().toArray(new String[model.size()]);
/* 205 */         for (String attrName : originalAttrNames) {
/* 206 */           Object attrValue = model.get(attrName);
/* 207 */           boolean isSessionAttr = this.methodResolver.isSessionAttribute(attrName, attrValue != null ? attrValue.getClass() : null);
/*     */ 
/* 209 */           if (isSessionAttr) {
/* 210 */             if (this.sessionStatus.isComplete()) {
/* 211 */               implicitModel.put(MODEL_KEY_PREFIX_STALE + attrName, Boolean.TRUE);
/*     */             }
/* 213 */             else if (!implicitModel.containsKey(MODEL_KEY_PREFIX_STALE + attrName)) {
/* 214 */               this.sessionAttributeStore.storeAttribute(webRequest, attrName, attrValue);
/*     */             }
/*     */           }
/* 217 */           if ((!attrName.startsWith(BindingResult.MODEL_KEY_PREFIX)) && ((isSessionAttr) || (isBindingCandidate(attrValue))))
/*     */           {
/* 219 */             String bindingResultKey = BindingResult.MODEL_KEY_PREFIX + attrName;
/* 220 */             if ((mavModel != null) && (!model.containsKey(bindingResultKey))) {
/* 221 */               WebDataBinder binder = createBinder(webRequest, attrValue, attrName);
/* 222 */               initBinder(handler, attrName, binder, webRequest);
/* 223 */               mavModel.put(bindingResultKey, binder.getBindingResult());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/* 230 */         ReflectionUtils.rethrowException(ex.getTargetException());
/*     */       }
/*     */   }
/*     */ 
/*     */   private Object[] resolveHandlerArguments(Method handlerMethod, Object handler, NativeWebRequest webRequest, ExtendedModelMap implicitModel)
/*     */     throws Exception
/*     */   {
/* 239 */     Class[] paramTypes = handlerMethod.getParameterTypes();
/* 240 */     Object[] args = new Object[paramTypes.length];
/*     */ 
/* 242 */     for (int i = 0; i < args.length; i++) {
/* 243 */       MethodParameter methodParam = new MethodParameter(handlerMethod, i);
/* 244 */       methodParam.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 245 */       GenericTypeResolver.resolveParameterType(methodParam, handler.getClass());
/* 246 */       String paramName = null;
/* 247 */       String headerName = null;
/* 248 */       boolean requestBodyFound = false;
/* 249 */       String cookieName = null;
/* 250 */       String pathVarName = null;
/* 251 */       String attrName = null;
/* 252 */       boolean required = false;
/* 253 */       String defaultValue = null;
/* 254 */       boolean validate = false;
/* 255 */       Object[] validationHints = null;
/* 256 */       int annotationsFound = 0;
/* 257 */       Annotation[] paramAnns = methodParam.getParameterAnnotations();
/*     */ 
/* 259 */       for (Annotation paramAnn : paramAnns) {
/* 260 */         if (RequestParam.class.isInstance(paramAnn)) {
/* 261 */           RequestParam requestParam = (RequestParam)paramAnn;
/* 262 */           paramName = requestParam.value();
/* 263 */           required = requestParam.required();
/* 264 */           defaultValue = parseDefaultValueAttribute(requestParam.defaultValue());
/* 265 */           annotationsFound++;
/*     */         }
/* 267 */         else if (RequestHeader.class.isInstance(paramAnn)) {
/* 268 */           RequestHeader requestHeader = (RequestHeader)paramAnn;
/* 269 */           headerName = requestHeader.value();
/* 270 */           required = requestHeader.required();
/* 271 */           defaultValue = parseDefaultValueAttribute(requestHeader.defaultValue());
/* 272 */           annotationsFound++;
/*     */         }
/* 274 */         else if (RequestBody.class.isInstance(paramAnn)) {
/* 275 */           requestBodyFound = true;
/* 276 */           annotationsFound++;
/*     */         }
/* 278 */         else if (CookieValue.class.isInstance(paramAnn)) {
/* 279 */           CookieValue cookieValue = (CookieValue)paramAnn;
/* 280 */           cookieName = cookieValue.value();
/* 281 */           required = cookieValue.required();
/* 282 */           defaultValue = parseDefaultValueAttribute(cookieValue.defaultValue());
/* 283 */           annotationsFound++;
/*     */         }
/* 285 */         else if (PathVariable.class.isInstance(paramAnn)) {
/* 286 */           PathVariable pathVar = (PathVariable)paramAnn;
/* 287 */           pathVarName = pathVar.value();
/* 288 */           annotationsFound++;
/*     */         }
/* 290 */         else if (ModelAttribute.class.isInstance(paramAnn)) {
/* 291 */           ModelAttribute attr = (ModelAttribute)paramAnn;
/* 292 */           attrName = attr.value();
/* 293 */           annotationsFound++;
/*     */         }
/* 295 */         else if (Value.class.isInstance(paramAnn)) {
/* 296 */           defaultValue = ((Value)paramAnn).value();
/*     */         }
/* 298 */         else if (paramAnn.annotationType().getSimpleName().startsWith("Valid")) {
/* 299 */           validate = true;
/* 300 */           Object value = AnnotationUtils.getValue(paramAnn);
/* 301 */           validationHints = new Object[] { (value instanceof Object[]) ? (Object[])value : value };
/*     */         }
/*     */       }
/*     */ 
/* 305 */       if (annotationsFound > 1) {
/* 306 */         throw new IllegalStateException("Handler parameter annotations are exclusive choices - do not specify more than one such annotation on the same parameter: " + handlerMethod);
/*     */       }
/*     */ 
/* 310 */       if (annotationsFound == 0) {
/* 311 */         Object argValue = resolveCommonArgument(methodParam, webRequest);
/* 312 */         if (argValue != WebArgumentResolver.UNRESOLVED) {
/* 313 */           args[i] = argValue;
/*     */         }
/* 315 */         else if (defaultValue != null) {
/* 316 */           args[i] = resolveDefaultValue(defaultValue);
/*     */         }
/*     */         else {
/* 319 */           Class paramType = methodParam.getParameterType();
/* 320 */           if ((Model.class.isAssignableFrom(paramType)) || (Map.class.isAssignableFrom(paramType))) {
/* 321 */             if (!paramType.isAssignableFrom(implicitModel.getClass())) {
/* 322 */               throw new IllegalStateException("Argument [" + paramType.getSimpleName() + "] is of type " + "Model or Map but is not assignable from the actual model. You may need to switch " + "newer MVC infrastructure classes to use this argument.");
/*     */             }
/*     */ 
/* 326 */             args[i] = implicitModel;
/*     */           }
/* 328 */           else if (SessionStatus.class.isAssignableFrom(paramType)) {
/* 329 */             args[i] = this.sessionStatus;
/*     */           }
/* 331 */           else if (HttpEntity.class.isAssignableFrom(paramType)) {
/* 332 */             args[i] = resolveHttpEntityRequest(methodParam, webRequest);
/*     */           } else {
/* 334 */             if (Errors.class.isAssignableFrom(paramType)) {
/* 335 */               throw new IllegalStateException("Errors/BindingResult argument declared without preceding model attribute. Check your handler method signature!");
/*     */             }
/*     */ 
/* 338 */             if (BeanUtils.isSimpleProperty(paramType)) {
/* 339 */               paramName = "";
/*     */             }
/*     */             else {
/* 342 */               attrName = "";
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 347 */       if (paramName != null) {
/* 348 */         args[i] = resolveRequestParam(paramName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 350 */       else if (headerName != null) {
/* 351 */         args[i] = resolveRequestHeader(headerName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 353 */       else if (requestBodyFound) {
/* 354 */         args[i] = resolveRequestBody(methodParam, webRequest, handler);
/*     */       }
/* 356 */       else if (cookieName != null) {
/* 357 */         args[i] = resolveCookieValue(cookieName, required, defaultValue, methodParam, webRequest, handler);
/*     */       }
/* 359 */       else if (pathVarName != null) {
/* 360 */         args[i] = resolvePathVariable(pathVarName, methodParam, webRequest, handler);
/*     */       }
/* 362 */       else if (attrName != null) {
/* 363 */         WebDataBinder binder = resolveModelAttribute(attrName, methodParam, implicitModel, webRequest, handler);
/*     */ 
/* 365 */         boolean assignBindingResult = (args.length > i + 1) && (Errors.class.isAssignableFrom(paramTypes[(i + 1)]));
/* 366 */         if (binder.getTarget() != null) {
/* 367 */           doBind(binder, webRequest, validate, validationHints, !assignBindingResult);
/*     */         }
/* 369 */         args[i] = binder.getTarget();
/* 370 */         if (assignBindingResult) {
/* 371 */           args[(i + 1)] = binder.getBindingResult();
/* 372 */           i++;
/*     */         }
/* 374 */         implicitModel.putAll(binder.getBindingResult().getModel());
/*     */       }
/*     */     }
/*     */ 
/* 378 */     return args;
/*     */   }
/*     */ 
/*     */   protected void initBinder(Object handler, String attrName, WebDataBinder binder, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 384 */     if (this.bindingInitializer != null)
/* 385 */       this.bindingInitializer.initBinder(binder, webRequest);
/*     */     boolean debug;
/* 387 */     if (handler != null) {
/* 388 */       Set initBinderMethods = this.methodResolver.getInitBinderMethods();
/* 389 */       if (!initBinderMethods.isEmpty()) {
/* 390 */         debug = logger.isDebugEnabled();
/* 391 */         for (Method initBinderMethod : initBinderMethods) {
/* 392 */           Method methodToInvoke = BridgeMethodResolver.findBridgedMethod(initBinderMethod);
/* 393 */           String[] targetNames = ((InitBinder)AnnotationUtils.findAnnotation(initBinderMethod, InitBinder.class)).value();
/* 394 */           if ((targetNames.length == 0) || (Arrays.asList(targetNames).contains(attrName))) {
/* 395 */             Object[] initBinderArgs = resolveInitBinderArguments(handler, methodToInvoke, binder, webRequest);
/*     */ 
/* 397 */             if (debug) {
/* 398 */               logger.debug("Invoking init-binder method: " + methodToInvoke);
/*     */             }
/* 400 */             ReflectionUtils.makeAccessible(methodToInvoke);
/* 401 */             Object returnValue = methodToInvoke.invoke(handler, initBinderArgs);
/* 402 */             if (returnValue != null)
/* 403 */               throw new IllegalStateException("InitBinder methods must not have a return value: " + methodToInvoke);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object[] resolveInitBinderArguments(Object handler, Method initBinderMethod, WebDataBinder binder, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 415 */     Class[] initBinderParams = initBinderMethod.getParameterTypes();
/* 416 */     Object[] initBinderArgs = new Object[initBinderParams.length];
/*     */ 
/* 418 */     for (int i = 0; i < initBinderArgs.length; i++) {
/* 419 */       MethodParameter methodParam = new MethodParameter(initBinderMethod, i);
/* 420 */       methodParam.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 421 */       GenericTypeResolver.resolveParameterType(methodParam, handler.getClass());
/* 422 */       String paramName = null;
/* 423 */       boolean paramRequired = false;
/* 424 */       String paramDefaultValue = null;
/* 425 */       String pathVarName = null;
/* 426 */       Annotation[] paramAnns = methodParam.getParameterAnnotations();
/*     */ 
/* 428 */       for (Annotation paramAnn : paramAnns) {
/* 429 */         if (RequestParam.class.isInstance(paramAnn)) {
/* 430 */           RequestParam requestParam = (RequestParam)paramAnn;
/* 431 */           paramName = requestParam.value();
/* 432 */           paramRequired = requestParam.required();
/* 433 */           paramDefaultValue = parseDefaultValueAttribute(requestParam.defaultValue());
/* 434 */           break;
/*     */         }
/* 436 */         if (ModelAttribute.class.isInstance(paramAnn)) {
/* 437 */           throw new IllegalStateException("@ModelAttribute is not supported on @InitBinder methods: " + initBinderMethod);
/*     */         }
/*     */ 
/* 440 */         if (PathVariable.class.isInstance(paramAnn)) {
/* 441 */           PathVariable pathVar = (PathVariable)paramAnn;
/* 442 */           pathVarName = pathVar.value();
/*     */         }
/*     */       }
/*     */ 
/* 446 */       if ((paramName == null) && (pathVarName == null)) {
/* 447 */         Object argValue = resolveCommonArgument(methodParam, webRequest);
/* 448 */         if (argValue != WebArgumentResolver.UNRESOLVED) {
/* 449 */           initBinderArgs[i] = argValue;
/*     */         }
/*     */         else {
/* 452 */           Class paramType = initBinderParams[i];
/* 453 */           if (paramType.isInstance(binder)) {
/* 454 */             initBinderArgs[i] = binder;
/*     */           }
/* 456 */           else if (BeanUtils.isSimpleProperty(paramType)) {
/* 457 */             paramName = "";
/*     */           }
/*     */           else {
/* 460 */             throw new IllegalStateException("Unsupported argument [" + paramType.getName() + "] for @InitBinder method: " + initBinderMethod);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 466 */       if (paramName != null) {
/* 467 */         initBinderArgs[i] = resolveRequestParam(paramName, paramRequired, paramDefaultValue, methodParam, webRequest, null);
/*     */       }
/* 470 */       else if (pathVarName != null) {
/* 471 */         initBinderArgs[i] = resolvePathVariable(pathVarName, methodParam, webRequest, null);
/*     */       }
/*     */     }
/*     */ 
/* 475 */     return initBinderArgs;
/*     */   }
/*     */ 
/*     */   private Object resolveRequestParam(String paramName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 483 */     Class paramType = methodParam.getParameterType();
/* 484 */     if ((Map.class.isAssignableFrom(paramType)) && (paramName.length() == 0)) {
/* 485 */       return resolveRequestParamMap(paramType, webRequest);
/*     */     }
/* 487 */     if (paramName.length() == 0) {
/* 488 */       paramName = getRequiredParameterName(methodParam);
/*     */     }
/* 490 */     Object paramValue = null;
/* 491 */     MultipartRequest multipartRequest = (MultipartRequest)webRequest.getNativeRequest(MultipartRequest.class);
/* 492 */     if (multipartRequest != null) {
/* 493 */       List files = multipartRequest.getFiles(paramName);
/* 494 */       if (!files.isEmpty()) {
/* 495 */         paramValue = files.size() == 1 ? files.get(0) : files;
/*     */       }
/*     */     }
/* 498 */     if (paramValue == null) {
/* 499 */       String[] paramValues = webRequest.getParameterValues(paramName);
/* 500 */       if (paramValues != null) {
/* 501 */         paramValue = paramValues.length == 1 ? paramValues[0] : paramValues;
/*     */       }
/*     */     }
/* 504 */     if (paramValue == null) {
/* 505 */       if (defaultValue != null) {
/* 506 */         paramValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 508 */       else if (required) {
/* 509 */         raiseMissingParameterException(paramName, paramType);
/*     */       }
/* 511 */       paramValue = checkValue(paramName, paramValue, paramType);
/*     */     }
/* 513 */     WebDataBinder binder = createBinder(webRequest, null, paramName);
/* 514 */     initBinder(handlerForInitBinderCall, paramName, binder, webRequest);
/* 515 */     return binder.convertIfNecessary(paramValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   private Map resolveRequestParamMap(Class<? extends Map> mapType, NativeWebRequest webRequest) {
/* 519 */     Map parameterMap = webRequest.getParameterMap();
/* 520 */     if (MultiValueMap.class.isAssignableFrom(mapType)) {
/* 521 */       MultiValueMap result = new LinkedMultiValueMap(parameterMap.size());
/* 522 */       for (Map.Entry entry : parameterMap.entrySet()) {
/* 523 */         for (String value : (String[])entry.getValue()) {
/* 524 */           result.add(entry.getKey(), value);
/*     */         }
/*     */       }
/* 527 */       return result;
/*     */     }
/*     */ 
/* 530 */     Map result = new LinkedHashMap(parameterMap.size());
/* 531 */     for (Map.Entry entry : parameterMap.entrySet()) {
/* 532 */       if (((String[])entry.getValue()).length > 0) {
/* 533 */         result.put(entry.getKey(), ((String[])entry.getValue())[0]);
/*     */       }
/*     */     }
/* 536 */     return result;
/*     */   }
/*     */ 
/*     */   private Object resolveRequestHeader(String headerName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 545 */     Class paramType = methodParam.getParameterType();
/* 546 */     if (Map.class.isAssignableFrom(paramType)) {
/* 547 */       return resolveRequestHeaderMap(paramType, webRequest);
/*     */     }
/* 549 */     if (headerName.length() == 0) {
/* 550 */       headerName = getRequiredParameterName(methodParam);
/*     */     }
/* 552 */     Object headerValue = null;
/* 553 */     String[] headerValues = webRequest.getHeaderValues(headerName);
/* 554 */     if (headerValues != null) {
/* 555 */       headerValue = headerValues.length == 1 ? headerValues[0] : headerValues;
/*     */     }
/* 557 */     if (headerValue == null) {
/* 558 */       if (defaultValue != null) {
/* 559 */         headerValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 561 */       else if (required) {
/* 562 */         raiseMissingHeaderException(headerName, paramType);
/*     */       }
/* 564 */       headerValue = checkValue(headerName, headerValue, paramType);
/*     */     }
/* 566 */     WebDataBinder binder = createBinder(webRequest, null, headerName);
/* 567 */     initBinder(handlerForInitBinderCall, headerName, binder, webRequest);
/* 568 */     return binder.convertIfNecessary(headerValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   private Map resolveRequestHeaderMap(Class<? extends Map> mapType, NativeWebRequest webRequest) {
/* 572 */     if (MultiValueMap.class.isAssignableFrom(mapType))
/*     */     {
/*     */       MultiValueMap result;
/*     */       MultiValueMap result;
/* 574 */       if (HttpHeaders.class.isAssignableFrom(mapType)) {
/* 575 */         result = new HttpHeaders();
/*     */       }
/*     */       else {
/* 578 */         result = new LinkedMultiValueMap();
/*     */       }
/* 580 */       for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 581 */         String headerName = (String)iterator.next();
/* 582 */         for (String headerValue : webRequest.getHeaderValues(headerName)) {
/* 583 */           result.add(headerName, headerValue);
/*     */         }
/*     */       }
/* 586 */       return result;
/*     */     }
/*     */ 
/* 589 */     Map result = new LinkedHashMap();
/* 590 */     for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 591 */       String headerName = (String)iterator.next();
/* 592 */       String headerValue = webRequest.getHeader(headerName);
/* 593 */       result.put(headerName, headerValue);
/*     */     }
/* 595 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object resolveRequestBody(MethodParameter methodParam, NativeWebRequest webRequest, Object handler)
/*     */     throws Exception
/*     */   {
/* 605 */     return readWithMessageConverters(methodParam, createHttpInputMessage(webRequest), methodParam.getParameterType());
/*     */   }
/*     */ 
/*     */   private HttpEntity resolveHttpEntityRequest(MethodParameter methodParam, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 611 */     HttpInputMessage inputMessage = createHttpInputMessage(webRequest);
/* 612 */     Class paramType = getHttpEntityType(methodParam);
/* 613 */     Object body = readWithMessageConverters(methodParam, inputMessage, paramType);
/* 614 */     return new HttpEntity(body, inputMessage.getHeaders());
/*     */   }
/*     */ 
/*     */   private Object readWithMessageConverters(MethodParameter methodParam, HttpInputMessage inputMessage, Class paramType)
/*     */     throws Exception
/*     */   {
/* 620 */     MediaType contentType = inputMessage.getHeaders().getContentType();
/* 621 */     if (contentType == null) {
/* 622 */       StringBuilder builder = new StringBuilder(ClassUtils.getShortName(methodParam.getParameterType()));
/* 623 */       String paramName = methodParam.getParameterName();
/* 624 */       if (paramName != null) {
/* 625 */         builder.append(' ');
/* 626 */         builder.append(paramName);
/*     */       }
/* 628 */       throw new HttpMediaTypeNotSupportedException("Cannot extract parameter (" + builder.toString() + "): no Content-Type found");
/*     */     }
/*     */ 
/* 632 */     List allSupportedMediaTypes = new ArrayList();
/* 633 */     if (this.messageConverters != null) {
/* 634 */       for (HttpMessageConverter messageConverter : this.messageConverters) {
/* 635 */         allSupportedMediaTypes.addAll(messageConverter.getSupportedMediaTypes());
/* 636 */         if (messageConverter.canRead(paramType, contentType)) {
/* 637 */           if (logger.isDebugEnabled()) {
/* 638 */             logger.debug("Reading [" + paramType.getName() + "] as \"" + contentType + "\" using [" + messageConverter + "]");
/*     */           }
/*     */ 
/* 641 */           return messageConverter.read(paramType, inputMessage);
/*     */         }
/*     */       }
/*     */     }
/* 645 */     throw new HttpMediaTypeNotSupportedException(contentType, allSupportedMediaTypes);
/*     */   }
/*     */ 
/*     */   private Class<?> getHttpEntityType(MethodParameter methodParam) {
/* 649 */     Assert.isAssignable(HttpEntity.class, methodParam.getParameterType());
/* 650 */     ParameterizedType type = (ParameterizedType)methodParam.getGenericParameterType();
/* 651 */     if (type.getActualTypeArguments().length == 1) {
/* 652 */       Type typeArgument = type.getActualTypeArguments()[0];
/* 653 */       if ((typeArgument instanceof Class)) {
/* 654 */         return (Class)typeArgument;
/*     */       }
/* 656 */       if ((typeArgument instanceof GenericArrayType)) {
/* 657 */         Type componentType = ((GenericArrayType)typeArgument).getGenericComponentType();
/* 658 */         if ((componentType instanceof Class))
/*     */         {
/* 660 */           Object array = Array.newInstance((Class)componentType, 0);
/* 661 */           return array.getClass();
/*     */         }
/*     */       }
/*     */     }
/* 665 */     throw new IllegalArgumentException("HttpEntity parameter (" + methodParam.getParameterName() + ") is not parameterized");
/*     */   }
/*     */ 
/*     */   private Object resolveCookieValue(String cookieName, boolean required, String defaultValue, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 674 */     Class paramType = methodParam.getParameterType();
/* 675 */     if (cookieName.length() == 0) {
/* 676 */       cookieName = getRequiredParameterName(methodParam);
/*     */     }
/* 678 */     Object cookieValue = resolveCookieValue(cookieName, paramType, webRequest);
/* 679 */     if (cookieValue == null) {
/* 680 */       if (defaultValue != null) {
/* 681 */         cookieValue = resolveDefaultValue(defaultValue);
/*     */       }
/* 683 */       else if (required) {
/* 684 */         raiseMissingCookieException(cookieName, paramType);
/*     */       }
/* 686 */       cookieValue = checkValue(cookieName, cookieValue, paramType);
/*     */     }
/* 688 */     WebDataBinder binder = createBinder(webRequest, null, cookieName);
/* 689 */     initBinder(handlerForInitBinderCall, cookieName, binder, webRequest);
/* 690 */     return binder.convertIfNecessary(cookieValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   protected Object resolveCookieValue(String cookieName, Class paramType, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 700 */     throw new UnsupportedOperationException("@CookieValue not supported");
/*     */   }
/*     */ 
/*     */   private Object resolvePathVariable(String pathVarName, MethodParameter methodParam, NativeWebRequest webRequest, Object handlerForInitBinderCall)
/*     */     throws Exception
/*     */   {
/* 706 */     Class paramType = methodParam.getParameterType();
/* 707 */     if (pathVarName.length() == 0) {
/* 708 */       pathVarName = getRequiredParameterName(methodParam);
/*     */     }
/* 710 */     String pathVarValue = resolvePathVariable(pathVarName, paramType, webRequest);
/* 711 */     WebDataBinder binder = createBinder(webRequest, null, pathVarName);
/* 712 */     initBinder(handlerForInitBinderCall, pathVarName, binder, webRequest);
/* 713 */     return binder.convertIfNecessary(pathVarValue, paramType, methodParam);
/*     */   }
/*     */ 
/*     */   protected String resolvePathVariable(String pathVarName, Class paramType, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 723 */     throw new UnsupportedOperationException("@PathVariable not supported");
/*     */   }
/*     */ 
/*     */   private String getRequiredParameterName(MethodParameter methodParam) {
/* 727 */     String name = methodParam.getParameterName();
/* 728 */     if (name == null) {
/* 729 */       throw new IllegalStateException("No parameter name specified for argument of type [" + methodParam.getParameterType().getName() + "], and no parameter name information found in class file either.");
/*     */     }
/*     */ 
/* 733 */     return name;
/*     */   }
/*     */ 
/*     */   private Object checkValue(String name, Object value, Class paramType) {
/* 737 */     if (value == null) {
/* 738 */       if (Boolean.TYPE.equals(paramType)) {
/* 739 */         return Boolean.FALSE;
/*     */       }
/* 741 */       if (paramType.isPrimitive()) {
/* 742 */         throw new IllegalStateException("Optional " + paramType + " parameter '" + name + "' is not present but cannot be translated into a null value due to being declared as a " + "primitive type. Consider declaring it as object wrapper for the corresponding primitive type.");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 747 */     return value;
/*     */   }
/*     */ 
/*     */   private WebDataBinder resolveModelAttribute(String attrName, MethodParameter methodParam, ExtendedModelMap implicitModel, NativeWebRequest webRequest, Object handler)
/*     */     throws Exception
/*     */   {
/* 754 */     String name = attrName;
/* 755 */     if ("".equals(name)) {
/* 756 */       name = Conventions.getVariableNameForParameter(methodParam);
/*     */     }
/* 758 */     Class paramType = methodParam.getParameterType();
/*     */     Object bindObject;
/*     */     Object bindObject;
/* 760 */     if (implicitModel.containsKey(name)) {
/* 761 */       bindObject = implicitModel.get(name);
/*     */     }
/* 763 */     else if (this.methodResolver.isSessionAttribute(name, paramType)) {
/* 764 */       Object bindObject = this.sessionAttributeStore.retrieveAttribute(webRequest, name);
/* 765 */       if (bindObject == null)
/* 766 */         raiseSessionRequiredException("Session attribute '" + name + "' required - not found in session");
/*     */     }
/*     */     else
/*     */     {
/* 770 */       bindObject = BeanUtils.instantiateClass(paramType);
/*     */     }
/* 772 */     WebDataBinder binder = createBinder(webRequest, bindObject, name);
/* 773 */     initBinder(handler, name, binder, webRequest);
/* 774 */     return binder;
/*     */   }
/*     */ 
/*     */   protected boolean isBindingCandidate(Object value)
/*     */   {
/* 783 */     return (value != null) && (!value.getClass().isArray()) && (!(value instanceof Collection)) && (!(value instanceof Map)) && (!BeanUtils.isSimpleValueType(value.getClass()));
/*     */   }
/*     */ 
/*     */   protected void raiseMissingParameterException(String paramName, Class paramType) throws Exception
/*     */   {
/* 788 */     throw new IllegalStateException("Missing parameter '" + paramName + "' of type [" + paramType.getName() + "]");
/*     */   }
/*     */ 
/*     */   protected void raiseMissingHeaderException(String headerName, Class paramType) throws Exception {
/* 792 */     throw new IllegalStateException("Missing header '" + headerName + "' of type [" + paramType.getName() + "]");
/*     */   }
/*     */ 
/*     */   protected void raiseMissingCookieException(String cookieName, Class paramType) throws Exception {
/* 796 */     throw new IllegalStateException("Missing cookie value '" + cookieName + "' of type [" + paramType.getName() + "]");
/*     */   }
/*     */ 
/*     */   protected void raiseSessionRequiredException(String message) throws Exception
/*     */   {
/* 801 */     throw new IllegalStateException(message);
/*     */   }
/*     */ 
/*     */   protected WebDataBinder createBinder(NativeWebRequest webRequest, Object target, String objectName)
/*     */     throws Exception
/*     */   {
/* 807 */     return new WebRequestDataBinder(target, objectName);
/*     */   }
/*     */ 
/*     */   private void doBind(WebDataBinder binder, NativeWebRequest webRequest, boolean validate, Object[] validationHints, boolean failOnErrors)
/*     */     throws Exception
/*     */   {
/* 813 */     doBind(binder, webRequest);
/* 814 */     if (validate) {
/* 815 */       binder.validate(validationHints);
/*     */     }
/* 817 */     if ((failOnErrors) && (binder.getBindingResult().hasErrors()))
/* 818 */       throw new BindException(binder.getBindingResult());
/*     */   }
/*     */ 
/*     */   protected void doBind(WebDataBinder binder, NativeWebRequest webRequest) throws Exception
/*     */   {
/* 823 */     ((WebRequestDataBinder)binder).bind(webRequest);
/*     */   }
/*     */ 
/*     */   protected HttpInputMessage createHttpInputMessage(NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 831 */     throw new UnsupportedOperationException("@RequestBody not supported");
/*     */   }
/*     */ 
/*     */   protected HttpOutputMessage createHttpOutputMessage(NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 839 */     throw new UnsupportedOperationException("@Body not supported");
/*     */   }
/*     */ 
/*     */   protected String parseDefaultValueAttribute(String value) {
/* 843 */     return "\n\t\t\n\t\t\n\n\t\t\t\t\n".equals(value) ? null : value;
/*     */   }
/*     */ 
/*     */   protected Object resolveDefaultValue(String value) {
/* 847 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveCommonArgument(MethodParameter methodParameter, NativeWebRequest webRequest)
/*     */     throws Exception
/*     */   {
/* 854 */     if (this.customArgumentResolvers != null) {
/* 855 */       for (WebArgumentResolver argumentResolver : this.customArgumentResolvers) {
/* 856 */         Object value = argumentResolver.resolveArgument(methodParameter, webRequest);
/* 857 */         if (value != WebArgumentResolver.UNRESOLVED) {
/* 858 */           return value;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 864 */     Class paramType = methodParameter.getParameterType();
/* 865 */     Object value = resolveStandardArgument(paramType, webRequest);
/* 866 */     if ((value != WebArgumentResolver.UNRESOLVED) && (!ClassUtils.isAssignableValue(paramType, value))) {
/* 867 */       throw new IllegalStateException("Standard argument type [" + paramType.getName() + "] resolved to incompatible value of type [" + (value != null ? value.getClass() : null) + "]. Consider declaring the argument type in a less specific fashion.");
/*     */     }
/*     */ 
/* 871 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveStandardArgument(Class<?> parameterType, NativeWebRequest webRequest) throws Exception {
/* 875 */     if (WebRequest.class.isAssignableFrom(parameterType)) {
/* 876 */       return webRequest;
/*     */     }
/* 878 */     return WebArgumentResolver.UNRESOLVED;
/*     */   }
/*     */ 
/*     */   protected final void addReturnValueAsModelAttribute(Method handlerMethod, Class handlerType, Object returnValue, ExtendedModelMap implicitModel)
/*     */   {
/* 884 */     ModelAttribute attr = (ModelAttribute)AnnotationUtils.findAnnotation(handlerMethod, ModelAttribute.class);
/* 885 */     String attrName = attr != null ? attr.value() : "";
/* 886 */     if ("".equals(attrName)) {
/* 887 */       Class resolvedType = GenericTypeResolver.resolveReturnType(handlerMethod, handlerType);
/* 888 */       attrName = Conventions.getVariableNameForReturnType(handlerMethod, resolvedType, returnValue);
/*     */     }
/* 890 */     implicitModel.addAttribute(attrName, returnValue);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.support.HandlerMethodInvoker
 * JD-Core Version:    0.6.1
 */