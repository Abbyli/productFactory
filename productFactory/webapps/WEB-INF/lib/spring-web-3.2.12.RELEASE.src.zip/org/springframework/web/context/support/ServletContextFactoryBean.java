/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.web.context.ServletContextAware;
/*    */ 
/*    */ @Deprecated
/*    */ public class ServletContextFactoryBean
/*    */   implements FactoryBean<ServletContext>, ServletContextAware
/*    */ {
/*    */   private ServletContext servletContext;
/*    */ 
/*    */   public void setServletContext(ServletContext servletContext)
/*    */   {
/* 53 */     this.servletContext = servletContext;
/*    */   }
/*    */ 
/*    */   public ServletContext getObject()
/*    */   {
/* 58 */     return this.servletContext;
/*    */   }
/*    */ 
/*    */   public Class<? extends ServletContext> getObjectType() {
/* 62 */     return this.servletContext != null ? this.servletContext.getClass() : ServletContext.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 66 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextFactoryBean
 * JD-Core Version:    0.6.1
 */