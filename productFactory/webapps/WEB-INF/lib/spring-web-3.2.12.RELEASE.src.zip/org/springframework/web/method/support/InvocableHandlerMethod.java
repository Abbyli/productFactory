/*     */ package org.springframework.web.method.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*     */ import org.springframework.web.context.request.NativeWebRequest;
/*     */ import org.springframework.web.method.HandlerMethod;
/*     */ 
/*     */ public class InvocableHandlerMethod extends HandlerMethod
/*     */ {
/*     */   private WebDataBinderFactory dataBinderFactory;
/*  52 */   private HandlerMethodArgumentResolverComposite argumentResolvers = new HandlerMethodArgumentResolverComposite();
/*     */ 
/*  54 */   private ParameterNameDiscoverer parameterNameDiscoverer = new LocalVariableTableParameterNameDiscoverer();
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, Method method)
/*     */   {
/*  61 */     super(bean, method);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(HandlerMethod handlerMethod)
/*     */   {
/*  68 */     super(handlerMethod);
/*     */   }
/*     */ 
/*     */   public InvocableHandlerMethod(Object bean, String methodName, Class<?>[] parameterTypes)
/*     */     throws NoSuchMethodException
/*     */   {
/*  79 */     super(bean, methodName, parameterTypes);
/*     */   }
/*     */ 
/*     */   public void setDataBinderFactory(WebDataBinderFactory dataBinderFactory)
/*     */   {
/*  89 */     this.dataBinderFactory = dataBinderFactory;
/*     */   }
/*     */ 
/*     */   public void setHandlerMethodArgumentResolvers(HandlerMethodArgumentResolverComposite argumentResolvers)
/*     */   {
/*  96 */     this.argumentResolvers = argumentResolvers;
/*     */   }
/*     */ 
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer)
/*     */   {
/* 105 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */   public final Object invokeForRequest(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 124 */     Object[] args = getMethodArgumentValues(request, mavContainer, providedArgs);
/* 125 */     if (this.logger.isTraceEnabled()) {
/* 126 */       StringBuilder sb = new StringBuilder("Invoking [");
/* 127 */       sb.append(getBeanType().getSimpleName()).append(".");
/* 128 */       sb.append(getMethod().getName()).append("] method with arguments ");
/* 129 */       sb.append(Arrays.asList(args));
/* 130 */       this.logger.trace(sb.toString());
/*     */     }
/* 132 */     Object returnValue = invoke(args);
/* 133 */     if (this.logger.isTraceEnabled()) {
/* 134 */       this.logger.trace("Method [" + getMethod().getName() + "] returned [" + returnValue + "]");
/*     */     }
/* 136 */     return returnValue;
/*     */   }
/*     */ 
/*     */   private Object[] getMethodArgumentValues(NativeWebRequest request, ModelAndViewContainer mavContainer, Object[] providedArgs)
/*     */     throws Exception
/*     */   {
/* 145 */     MethodParameter[] parameters = getMethodParameters();
/* 146 */     Object[] args = new Object[parameters.length];
/* 147 */     for (int i = 0; i < parameters.length; i++) {
/* 148 */       MethodParameter parameter = parameters[i];
/* 149 */       parameter.initParameterNameDiscovery(this.parameterNameDiscoverer);
/* 150 */       GenericTypeResolver.resolveParameterType(parameter, getBean().getClass());
/* 151 */       args[i] = resolveProvidedArgument(parameter, providedArgs);
/* 152 */       if (args[i] == null)
/*     */       {
/* 155 */         if (this.argumentResolvers.supportsParameter(parameter)) {
/*     */           try {
/* 157 */             args[i] = this.argumentResolvers.resolveArgument(parameter, mavContainer, request, this.dataBinderFactory);
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 162 */             if (this.logger.isTraceEnabled()) {
/* 163 */               this.logger.trace(getArgumentResolutionErrorMessage("Error resolving argument", i), ex);
/*     */             }
/* 165 */             throw ex;
/*     */           }
/*     */         }
/* 168 */         else if (args[i] == null) {
/* 169 */           String msg = getArgumentResolutionErrorMessage("No suitable resolver for argument", i);
/* 170 */           throw new IllegalStateException(msg);
/*     */         }
/*     */       }
/*     */     }
/* 173 */     return args;
/*     */   }
/*     */ 
/*     */   private String getArgumentResolutionErrorMessage(String message, int index) {
/* 177 */     MethodParameter param = getMethodParameters()[index];
/* 178 */     message = message + " [" + index + "] [type=" + param.getParameterType().getName() + "]";
/* 179 */     return getDetailedErrorMessage(message);
/*     */   }
/*     */ 
/*     */   protected String getDetailedErrorMessage(String message)
/*     */   {
/* 187 */     StringBuilder sb = new StringBuilder(message).append("\n");
/* 188 */     sb.append("HandlerMethod details: \n");
/* 189 */     sb.append("Controller [").append(getBeanType().getName()).append("]\n");
/* 190 */     sb.append("Method [").append(getBridgedMethod().toGenericString()).append("]\n");
/* 191 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private Object resolveProvidedArgument(MethodParameter parameter, Object[] providedArgs)
/*     */   {
/* 198 */     if (providedArgs == null) {
/* 199 */       return null;
/*     */     }
/* 201 */     for (Object providedArg : providedArgs) {
/* 202 */       if (parameter.getParameterType().isInstance(providedArg)) {
/* 203 */         return providedArg;
/*     */       }
/*     */     }
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */   private Object invoke(Object[] args)
/*     */     throws Exception
/*     */   {
/* 213 */     ReflectionUtils.makeAccessible(getBridgedMethod());
/*     */     try {
/* 215 */       return getBridgedMethod().invoke(getBean(), args);
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/* 218 */       assertTargetBean(getBridgedMethod(), getBean(), args);
/* 219 */       throw new IllegalStateException(getInvocationErrorMessage(ex.getMessage(), args), ex);
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 223 */       Throwable targetException = ex.getTargetException();
/* 224 */       if ((targetException instanceof RuntimeException)) {
/* 225 */         throw ((RuntimeException)targetException);
/*     */       }
/* 227 */       if ((targetException instanceof Error)) {
/* 228 */         throw ((Error)targetException);
/*     */       }
/* 230 */       if ((targetException instanceof Exception)) {
/* 231 */         throw ((Exception)targetException);
/*     */       }
/*     */ 
/* 234 */       String msg = getInvocationErrorMessage("Failed to invoke controller method", args);
/* 235 */       throw new IllegalStateException(msg, targetException);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void assertTargetBean(Method method, Object targetBean, Object[] args)
/*     */   {
/* 248 */     Class methodDeclaringClass = method.getDeclaringClass();
/* 249 */     Class targetBeanClass = targetBean.getClass();
/* 250 */     if (!methodDeclaringClass.isAssignableFrom(targetBeanClass)) {
/* 251 */       String msg = "The mapped controller method class '" + methodDeclaringClass.getName() + "' is not an instance of the actual controller bean instance '" + targetBeanClass.getName() + "'. If the controller requires proxying " + "(e.g. due to @Transactional), please use class-based proxying.";
/*     */ 
/* 255 */       throw new IllegalStateException(getInvocationErrorMessage(msg, args));
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getInvocationErrorMessage(String message, Object[] resolvedArgs) {
/* 260 */     StringBuilder sb = new StringBuilder(getDetailedErrorMessage(message));
/* 261 */     sb.append("Resolved arguments: \n");
/* 262 */     for (int i = 0; i < resolvedArgs.length; i++) {
/* 263 */       sb.append("[").append(i).append("] ");
/* 264 */       if (resolvedArgs[i] == null) {
/* 265 */         sb.append("[null] \n");
/*     */       }
/*     */       else {
/* 268 */         sb.append("[type=").append(resolvedArgs[i].getClass().getName()).append("] ");
/* 269 */         sb.append("[value=").append(resolvedArgs[i]).append("]\n");
/*     */       }
/*     */     }
/* 272 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.support.InvocableHandlerMethod
 * JD-Core Version:    0.6.1
 */