/*     */ package org.springframework.web.jsf;
/*     */ 
/*     */ import javax.faces.context.FacesContext;
/*     */ import javax.faces.el.EvaluationException;
/*     */ import javax.faces.el.VariableResolver;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ 
/*     */ @Deprecated
/*     */ public class DelegatingVariableResolver extends VariableResolver
/*     */ {
/*  79 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   protected final VariableResolver originalVariableResolver;
/*     */ 
/*     */   public DelegatingVariableResolver(VariableResolver originalVariableResolver)
/*     */   {
/*  92 */     Assert.notNull(originalVariableResolver, "Original JSF VariableResolver must not be null");
/*  93 */     this.originalVariableResolver = originalVariableResolver;
/*     */   }
/*     */ 
/*     */   protected final VariableResolver getOriginalVariableResolver()
/*     */   {
/* 101 */     return this.originalVariableResolver;
/*     */   }
/*     */ 
/*     */   public Object resolveVariable(FacesContext facesContext, String name)
/*     */     throws EvaluationException
/*     */   {
/* 111 */     Object value = resolveOriginal(facesContext, name);
/* 112 */     if (value != null) {
/* 113 */       return value;
/*     */     }
/* 115 */     Object bean = resolveSpringBean(facesContext, name);
/* 116 */     if (bean != null) {
/* 117 */       return bean;
/*     */     }
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object resolveOriginal(FacesContext facesContext, String name)
/*     */   {
/* 126 */     Object value = getOriginalVariableResolver().resolveVariable(facesContext, name);
/* 127 */     if ((value != null) && (this.logger.isTraceEnabled())) {
/* 128 */       this.logger.trace("Successfully resolved variable '" + name + "' via original VariableResolver");
/*     */     }
/* 130 */     return value;
/*     */   }
/*     */ 
/*     */   protected Object resolveSpringBean(FacesContext facesContext, String name)
/*     */   {
/* 137 */     BeanFactory bf = getBeanFactory(facesContext);
/* 138 */     if (bf.containsBean(name)) {
/* 139 */       if (this.logger.isTraceEnabled()) {
/* 140 */         this.logger.trace("Successfully resolved variable '" + name + "' in Spring BeanFactory");
/*     */       }
/* 142 */       return bf.getBean(name);
/*     */     }
/*     */ 
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */   protected BeanFactory getBeanFactory(FacesContext facesContext)
/*     */   {
/* 159 */     return getWebApplicationContext(facesContext);
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext getWebApplicationContext(FacesContext facesContext)
/*     */   {
/* 170 */     return FacesContextUtils.getRequiredWebApplicationContext(facesContext);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.jsf.DelegatingVariableResolver
 * JD-Core Version:    0.6.1
 */