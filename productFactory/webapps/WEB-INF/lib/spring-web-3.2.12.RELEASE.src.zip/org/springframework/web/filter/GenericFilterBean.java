/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceEditor;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.support.ServletContextResourceLoader;
/*     */ import org.springframework.web.context.support.StandardServletEnvironment;
/*     */ import org.springframework.web.util.NestedServletException;
/*     */ 
/*     */ public abstract class GenericFilterBean
/*     */   implements Filter, BeanNameAware, EnvironmentAware, ServletContextAware, InitializingBean, DisposableBean
/*     */ {
/*     */   protected final Log logger;
/*     */   private final Set<String> requiredProperties;
/*     */   private FilterConfig filterConfig;
/*     */   private String beanName;
/*     */   private Environment environment;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public GenericFilterBean()
/*     */   {
/*  82 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  88 */     this.requiredProperties = new HashSet();
/*     */ 
/*  94 */     this.environment = new StandardServletEnvironment();
/*     */   }
/*     */ 
/*     */   public final void setBeanName(String beanName)
/*     */   {
/* 107 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 120 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public final void setServletContext(ServletContext servletContext)
/*     */   {
/* 131 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws ServletException
/*     */   {
/* 143 */     initFilterBean();
/*     */   }
/*     */ 
/*     */   protected final void addRequiredProperty(String property)
/*     */   {
/* 157 */     this.requiredProperties.add(property);
/*     */   }
/*     */ 
/*     */   public final void init(FilterConfig filterConfig)
/*     */     throws ServletException
/*     */   {
/* 170 */     Assert.notNull(filterConfig, "FilterConfig must not be null");
/* 171 */     if (this.logger.isDebugEnabled()) {
/* 172 */       this.logger.debug("Initializing filter '" + filterConfig.getFilterName() + "'");
/*     */     }
/*     */ 
/* 175 */     this.filterConfig = filterConfig;
/*     */     try
/*     */     {
/* 179 */       PropertyValues pvs = new FilterConfigPropertyValues(filterConfig, this.requiredProperties);
/* 180 */       BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(this);
/* 181 */       ResourceLoader resourceLoader = new ServletContextResourceLoader(filterConfig.getServletContext());
/* 182 */       bw.registerCustomEditor(Resource.class, new ResourceEditor(resourceLoader, this.environment));
/* 183 */       initBeanWrapper(bw);
/* 184 */       bw.setPropertyValues(pvs, true);
/*     */     }
/*     */     catch (BeansException ex) {
/* 187 */       String msg = "Failed to set bean properties on filter '" + filterConfig.getFilterName() + "': " + ex.getMessage();
/*     */ 
/* 189 */       this.logger.error(msg, ex);
/* 190 */       throw new NestedServletException(msg, ex);
/*     */     }
/*     */ 
/* 194 */     initFilterBean();
/*     */ 
/* 196 */     if (this.logger.isDebugEnabled())
/* 197 */       this.logger.debug("Filter '" + filterConfig.getFilterName() + "' configured successfully");
/*     */   }
/*     */ 
/*     */   protected void initBeanWrapper(BeanWrapper bw)
/*     */     throws BeansException
/*     */   {
/*     */   }
/*     */ 
/*     */   public final FilterConfig getFilterConfig()
/*     */   {
/* 222 */     return this.filterConfig;
/*     */   }
/*     */ 
/*     */   protected final String getFilterName()
/*     */   {
/* 237 */     return this.filterConfig != null ? this.filterConfig.getFilterName() : this.beanName;
/*     */   }
/*     */ 
/*     */   protected final ServletContext getServletContext()
/*     */   {
/* 252 */     return this.filterConfig != null ? this.filterConfig.getServletContext() : this.servletContext;
/*     */   }
/*     */ 
/*     */   protected void initFilterBean()
/*     */     throws ServletException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   private static class FilterConfigPropertyValues extends MutablePropertyValues
/*     */   {
/*     */     public FilterConfigPropertyValues(FilterConfig config, Set<String> requiredProperties)
/*     */       throws ServletException
/*     */     {
/* 297 */       Set missingProps = (requiredProperties != null) && (!requiredProperties.isEmpty()) ? new HashSet(requiredProperties) : null;
/*     */ 
/* 300 */       Enumeration en = config.getInitParameterNames();
/* 301 */       while (en.hasMoreElements()) {
/* 302 */         String property = (String)en.nextElement();
/* 303 */         Object value = config.getInitParameter(property);
/* 304 */         addPropertyValue(new PropertyValue(property, value));
/* 305 */         if (missingProps != null) {
/* 306 */           missingProps.remove(property);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 311 */       if ((missingProps != null) && (missingProps.size() > 0))
/* 312 */         throw new ServletException("Initialization from FilterConfig for filter '" + config.getFilterName() + "' failed; the following required properties were missing: " + StringUtils.collectionToDelimitedString(missingProps, ", "));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.GenericFilterBean
 * JD-Core Version:    0.6.1
 */