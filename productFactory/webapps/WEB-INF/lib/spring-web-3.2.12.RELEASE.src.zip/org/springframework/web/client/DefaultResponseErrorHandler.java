/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.HttpStatus.Series;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ public class DefaultResponseErrorHandler
/*     */   implements ResponseErrorHandler
/*     */ {
/*     */   public boolean hasError(ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/*  49 */     return hasError(getHttpStatusCode(response));
/*     */   }
/*     */ 
/*     */   private HttpStatus getHttpStatusCode(ClientHttpResponse response) throws IOException {
/*     */     HttpStatus statusCode;
/*     */     try {
/*  55 */       statusCode = response.getStatusCode();
/*     */     }
/*     */     catch (IllegalArgumentException ex) {
/*  58 */       throw new UnknownHttpStatusCodeException(response.getRawStatusCode(), response.getStatusText(), response.getHeaders(), getResponseBody(response), getCharset(response));
/*     */     }
/*     */ 
/*  61 */     return statusCode;
/*     */   }
/*     */ 
/*     */   protected boolean hasError(HttpStatus statusCode)
/*     */   {
/*  74 */     return (statusCode.series() == HttpStatus.Series.CLIENT_ERROR) || (statusCode.series() == HttpStatus.Series.SERVER_ERROR);
/*     */   }
/*     */ 
/*     */   public void handleError(ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/*  85 */     HttpStatus statusCode = getHttpStatusCode(response);
/*  86 */     switch (1.$SwitchMap$org$springframework$http$HttpStatus$Series[statusCode.series().ordinal()]) {
/*     */     case 1:
/*  88 */       throw new HttpClientErrorException(statusCode, response.getStatusText(), response.getHeaders(), getResponseBody(response), getCharset(response));
/*     */     case 2:
/*  91 */       throw new HttpServerErrorException(statusCode, response.getStatusText(), response.getHeaders(), getResponseBody(response), getCharset(response));
/*     */     }
/*     */ 
/*  94 */     throw new RestClientException("Unknown status code [" + statusCode + "]");
/*     */   }
/*     */ 
/*     */   private byte[] getResponseBody(ClientHttpResponse response)
/*     */   {
/*     */     try {
/* 100 */       InputStream responseBody = response.getBody();
/* 101 */       if (responseBody != null) {
/* 102 */         return FileCopyUtils.copyToByteArray(responseBody);
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/* 108 */     return new byte[0];
/*     */   }
/*     */ 
/*     */   private Charset getCharset(ClientHttpResponse response) {
/* 112 */     HttpHeaders headers = response.getHeaders();
/* 113 */     MediaType contentType = headers.getContentType();
/* 114 */     return contentType != null ? contentType.getCharSet() : null;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.DefaultResponseErrorHandler
 * JD-Core Version:    0.6.1
 */