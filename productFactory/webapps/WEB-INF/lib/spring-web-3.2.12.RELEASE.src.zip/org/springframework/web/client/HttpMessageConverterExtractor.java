/*     */ package org.springframework.web.client;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.HttpStatus;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.client.ClientHttpResponse;
/*     */ import org.springframework.http.converter.GenericHttpMessageConverter;
/*     */ import org.springframework.http.converter.HttpMessageConverter;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HttpMessageConverterExtractor<T>
/*     */   implements ResponseExtractor<T>
/*     */ {
/*     */   private final Type responseType;
/*     */   private final Class<T> responseClass;
/*     */   private final List<HttpMessageConverter<?>> messageConverters;
/*     */   private final Log logger;
/*     */ 
/*     */   public HttpMessageConverterExtractor(Class<T> responseType, List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  57 */     this(responseType, messageConverters);
/*     */   }
/*     */ 
/*     */   public HttpMessageConverterExtractor(Type responseType, List<HttpMessageConverter<?>> messageConverters)
/*     */   {
/*  66 */     this(responseType, messageConverters, LogFactory.getLog(HttpMessageConverterExtractor.class));
/*     */   }
/*     */ 
/*     */   HttpMessageConverterExtractor(Type responseType, List<HttpMessageConverter<?>> messageConverters, Log logger)
/*     */   {
/*  71 */     Assert.notNull(responseType, "'responseType' must not be null");
/*  72 */     Assert.notEmpty(messageConverters, "'messageConverters' must not be empty");
/*  73 */     this.responseType = responseType;
/*  74 */     this.responseClass = ((responseType instanceof Class) ? (Class)responseType : null);
/*  75 */     this.messageConverters = messageConverters;
/*  76 */     this.logger = logger;
/*     */   }
/*     */ 
/*     */   public T extractData(ClientHttpResponse response) throws IOException
/*     */   {
/*  81 */     if (!hasMessageBody(response)) {
/*  82 */       return null;
/*     */     }
/*  84 */     MediaType contentType = getContentType(response);
/*     */ 
/*  86 */     for (HttpMessageConverter messageConverter : this.messageConverters) {
/*  87 */       if ((messageConverter instanceof GenericHttpMessageConverter)) {
/*  88 */         GenericHttpMessageConverter genericMessageConverter = (GenericHttpMessageConverter)messageConverter;
/*  89 */         if (genericMessageConverter.canRead(this.responseType, null, contentType)) {
/*  90 */           if (this.logger.isDebugEnabled()) {
/*  91 */             this.logger.debug("Reading [" + this.responseType + "] as \"" + contentType + "\" using [" + messageConverter + "]");
/*     */           }
/*     */ 
/*  94 */           return genericMessageConverter.read(this.responseType, null, response);
/*     */         }
/*     */       }
/*  97 */       if ((this.responseClass != null) && 
/*  98 */         (messageConverter.canRead(this.responseClass, contentType))) {
/*  99 */         if (this.logger.isDebugEnabled()) {
/* 100 */           this.logger.debug("Reading [" + this.responseClass.getName() + "] as \"" + contentType + "\" using [" + messageConverter + "]");
/*     */         }
/*     */ 
/* 103 */         return messageConverter.read(this.responseClass, response);
/*     */       }
/*     */     }
/*     */ 
/* 107 */     throw new RestClientException("Could not extract response: no suitable HttpMessageConverter found for response type [" + this.responseType + "] and content type [" + contentType + "]");
/*     */   }
/*     */ 
/*     */   private MediaType getContentType(ClientHttpResponse response)
/*     */   {
/* 113 */     MediaType contentType = response.getHeaders().getContentType();
/* 114 */     if (contentType == null) {
/* 115 */       if (this.logger.isTraceEnabled()) {
/* 116 */         this.logger.trace("No Content-Type header found, defaulting to application/octet-stream");
/*     */       }
/* 118 */       contentType = MediaType.APPLICATION_OCTET_STREAM;
/*     */     }
/* 120 */     return contentType;
/*     */   }
/*     */ 
/*     */   protected boolean hasMessageBody(ClientHttpResponse response)
/*     */     throws IOException
/*     */   {
/* 133 */     HttpStatus responseStatus = response.getStatusCode();
/* 134 */     if ((responseStatus == HttpStatus.NO_CONTENT) || (responseStatus == HttpStatus.NOT_MODIFIED))
/*     */     {
/* 136 */       return false;
/*     */     }
/* 138 */     long contentLength = response.getHeaders().getContentLength();
/* 139 */     return contentLength != 0L;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.HttpMessageConverterExtractor
 * JD-Core Version:    0.6.1
 */