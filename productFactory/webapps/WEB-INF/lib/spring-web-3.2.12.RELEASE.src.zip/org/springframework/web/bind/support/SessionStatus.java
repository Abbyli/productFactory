package org.springframework.web.bind.support;

public abstract interface SessionStatus
{
  public abstract void setComplete();

  public abstract boolean isComplete();
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.SessionStatus
 * JD-Core Version:    0.6.1
 */