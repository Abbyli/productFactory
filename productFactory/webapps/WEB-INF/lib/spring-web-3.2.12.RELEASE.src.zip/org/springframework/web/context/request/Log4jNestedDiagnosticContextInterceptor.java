/*    */ package org.springframework.web.context.request;
/*    */ 
/*    */ import org.apache.log4j.Logger;
/*    */ import org.apache.log4j.NDC;
/*    */ import org.springframework.ui.ModelMap;
/*    */ 
/*    */ public class Log4jNestedDiagnosticContextInterceptor
/*    */   implements AsyncWebRequestInterceptor
/*    */ {
/* 36 */   protected final Logger log4jLogger = Logger.getLogger(getClass());
/*    */ 
/* 38 */   private boolean includeClientInfo = false;
/*    */ 
/*    */   public void setIncludeClientInfo(boolean includeClientInfo)
/*    */   {
/* 46 */     this.includeClientInfo = includeClientInfo;
/*    */   }
/*    */ 
/*    */   protected boolean isIncludeClientInfo()
/*    */   {
/* 54 */     return this.includeClientInfo;
/*    */   }
/*    */ 
/*    */   public void preHandle(WebRequest request)
/*    */     throws Exception
/*    */   {
/* 62 */     NDC.push(getNestedDiagnosticContextMessage(request));
/*    */   }
/*    */ 
/*    */   protected String getNestedDiagnosticContextMessage(WebRequest request)
/*    */   {
/* 74 */     return request.getDescription(isIncludeClientInfo());
/*    */   }
/*    */ 
/*    */   public void postHandle(WebRequest request, ModelMap model)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public void afterCompletion(WebRequest request, Exception ex) throws Exception
/*    */   {
/* 84 */     NDC.pop();
/* 85 */     if (NDC.getDepth() == 0)
/* 86 */       NDC.remove();
/*    */   }
/*    */ 
/*    */   public void afterConcurrentHandlingStarted(WebRequest request)
/*    */   {
/* 95 */     NDC.pop();
/* 96 */     if (NDC.getDepth() == 0)
/* 97 */       NDC.remove();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.Log4jNestedDiagnosticContextInterceptor
 * JD-Core Version:    0.6.1
 */