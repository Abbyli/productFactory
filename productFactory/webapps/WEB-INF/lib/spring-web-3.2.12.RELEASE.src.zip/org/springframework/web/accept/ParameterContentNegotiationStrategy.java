/*    */ package org.springframework.web.accept;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class ParameterContentNegotiationStrategy extends AbstractMappingContentNegotiationStrategy
/*    */ {
/* 37 */   private static final Log logger = LogFactory.getLog(ParameterContentNegotiationStrategy.class);
/*    */ 
/* 39 */   private String parameterName = "format";
/*    */ 
/*    */   public ParameterContentNegotiationStrategy(Map<String, MediaType> mediaTypes)
/*    */   {
/* 46 */     super(mediaTypes);
/*    */   }
/*    */ 
/*    */   public void setParameterName(String parameterName)
/*    */   {
/* 54 */     Assert.notNull(parameterName, "parameterName is required");
/* 55 */     this.parameterName = parameterName;
/*    */   }
/*    */ 
/*    */   protected String getMediaTypeKey(NativeWebRequest webRequest)
/*    */   {
/* 60 */     return webRequest.getParameter(this.parameterName);
/*    */   }
/*    */ 
/*    */   protected void handleMatch(String mediaTypeKey, MediaType mediaType)
/*    */   {
/* 65 */     if (logger.isDebugEnabled())
/* 66 */       logger.debug("Requested media type is '" + mediaType + "' (based on parameter '" + this.parameterName + "'='" + mediaTypeKey + "')");
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ParameterContentNegotiationStrategy
 * JD-Core Version:    0.6.1
 */