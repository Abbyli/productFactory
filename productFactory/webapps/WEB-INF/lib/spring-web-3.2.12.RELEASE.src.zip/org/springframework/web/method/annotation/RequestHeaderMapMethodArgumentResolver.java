/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.http.HttpHeaders;
/*    */ import org.springframework.util.LinkedMultiValueMap;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.springframework.web.bind.annotation.RequestHeader;
/*    */ import org.springframework.web.bind.support.WebDataBinderFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ import org.springframework.web.method.support.HandlerMethodArgumentResolver;
/*    */ import org.springframework.web.method.support.ModelAndViewContainer;
/*    */ 
/*    */ public class RequestHeaderMapMethodArgumentResolver
/*    */   implements HandlerMethodArgumentResolver
/*    */ {
/*    */   public boolean supportsParameter(MethodParameter parameter)
/*    */   {
/* 49 */     return (parameter.hasParameterAnnotation(RequestHeader.class)) && (Map.class.isAssignableFrom(parameter.getParameterType()));
/*    */   }
/*    */ 
/*    */   public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory)
/*    */     throws Exception
/*    */   {
/* 58 */     Class paramType = parameter.getParameterType();
/*    */ 
/* 60 */     if (MultiValueMap.class.isAssignableFrom(paramType))
/*    */     {
/*    */       MultiValueMap result;
/*    */       MultiValueMap result;
/* 62 */       if (HttpHeaders.class.isAssignableFrom(paramType)) {
/* 63 */         result = new HttpHeaders();
/*    */       }
/*    */       else {
/* 66 */         result = new LinkedMultiValueMap();
/*    */       }
/* 68 */       for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 69 */         String headerName = (String)iterator.next();
/* 70 */         for (String headerValue : webRequest.getHeaderValues(headerName)) {
/* 71 */           result.add(headerName, headerValue);
/*    */         }
/*    */       }
/* 74 */       return result;
/*    */     }
/*    */ 
/* 77 */     Map result = new LinkedHashMap();
/* 78 */     for (Iterator iterator = webRequest.getHeaderNames(); iterator.hasNext(); ) {
/* 79 */       String headerName = (String)iterator.next();
/* 80 */       String headerValue = webRequest.getHeader(headerName);
/* 81 */       result.put(headerName, headerValue);
/*    */     }
/* 83 */     return result;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.RequestHeaderMapMethodArgumentResolver
 * JD-Core Version:    0.6.1
 */