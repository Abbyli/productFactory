/*     */ package org.springframework.web.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ public class DelegatingFilterProxy extends GenericFilterBean
/*     */ {
/*     */   private String contextAttribute;
/*     */   private WebApplicationContext webApplicationContext;
/*     */   private String targetBeanName;
/*  89 */   private boolean targetFilterLifecycle = false;
/*     */   private volatile Filter delegate;
/*  93 */   private final Object delegateMonitor = new Object();
/*     */ 
/*     */   public DelegatingFilterProxy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DelegatingFilterProxy(Filter delegate)
/*     */   {
/* 118 */     Assert.notNull(delegate, "delegate Filter object must not be null");
/* 119 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName)
/*     */   {
/* 136 */     this(targetBeanName, null);
/*     */   }
/*     */ 
/*     */   public DelegatingFilterProxy(String targetBeanName, WebApplicationContext wac)
/*     */   {
/* 160 */     Assert.hasText(targetBeanName, "target Filter bean name must not be null or empty");
/* 161 */     setTargetBeanName(targetBeanName);
/* 162 */     this.webApplicationContext = wac;
/* 163 */     if (wac != null)
/* 164 */       setEnvironment(wac.getEnvironment());
/*     */   }
/*     */ 
/*     */   public void setContextAttribute(String contextAttribute)
/*     */   {
/* 173 */     this.contextAttribute = contextAttribute;
/*     */   }
/*     */ 
/*     */   public String getContextAttribute()
/*     */   {
/* 181 */     return this.contextAttribute;
/*     */   }
/*     */ 
/*     */   public void setTargetBeanName(String targetBeanName)
/*     */   {
/* 191 */     this.targetBeanName = targetBeanName;
/*     */   }
/*     */ 
/*     */   protected String getTargetBeanName()
/*     */   {
/* 198 */     return this.targetBeanName;
/*     */   }
/*     */ 
/*     */   public void setTargetFilterLifecycle(boolean targetFilterLifecycle)
/*     */   {
/* 210 */     this.targetFilterLifecycle = targetFilterLifecycle;
/*     */   }
/*     */ 
/*     */   protected boolean isTargetFilterLifecycle()
/*     */   {
/* 218 */     return this.targetFilterLifecycle;
/*     */   }
/*     */ 
/*     */   protected void initFilterBean()
/*     */     throws ServletException
/*     */   {
/* 224 */     synchronized (this.delegateMonitor) {
/* 225 */       if (this.delegate == null)
/*     */       {
/* 227 */         if (this.targetBeanName == null) {
/* 228 */           this.targetBeanName = getFilterName();
/*     */         }
/*     */ 
/* 233 */         WebApplicationContext wac = findWebApplicationContext();
/* 234 */         if (wac != null)
/* 235 */           this.delegate = initDelegate(wac);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 245 */     Filter delegateToUse = this.delegate;
/* 246 */     if (delegateToUse == null) {
/* 247 */       synchronized (this.delegateMonitor) {
/* 248 */         if (this.delegate == null) {
/* 249 */           WebApplicationContext wac = findWebApplicationContext();
/* 250 */           if (wac == null) {
/* 251 */             throw new IllegalStateException("No WebApplicationContext found: no ContextLoaderListener registered?");
/*     */           }
/* 253 */           this.delegate = initDelegate(wac);
/*     */         }
/* 255 */         delegateToUse = this.delegate;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 260 */     invokeDelegate(delegateToUse, request, response, filterChain);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 265 */     Filter delegateToUse = this.delegate;
/* 266 */     if (delegateToUse != null)
/* 267 */       destroyDelegate(delegateToUse);
/*     */   }
/*     */ 
/*     */   protected WebApplicationContext findWebApplicationContext()
/*     */   {
/* 289 */     if (this.webApplicationContext != null)
/*     */     {
/* 291 */       if (((this.webApplicationContext instanceof ConfigurableApplicationContext)) && 
/* 292 */         (!((ConfigurableApplicationContext)this.webApplicationContext).isActive()))
/*     */       {
/* 294 */         ((ConfigurableApplicationContext)this.webApplicationContext).refresh();
/*     */       }
/*     */ 
/* 297 */       return this.webApplicationContext;
/*     */     }
/* 299 */     String attrName = getContextAttribute();
/* 300 */     if (attrName != null) {
/* 301 */       return WebApplicationContextUtils.getWebApplicationContext(getServletContext(), attrName);
/*     */     }
/*     */ 
/* 304 */     return WebApplicationContextUtils.getWebApplicationContext(getServletContext());
/*     */   }
/*     */ 
/*     */   protected Filter initDelegate(WebApplicationContext wac)
/*     */     throws ServletException
/*     */   {
/* 323 */     Filter delegate = (Filter)wac.getBean(getTargetBeanName(), Filter.class);
/* 324 */     if (isTargetFilterLifecycle()) {
/* 325 */       delegate.init(getFilterConfig());
/*     */     }
/* 327 */     return delegate;
/*     */   }
/*     */ 
/*     */   protected void invokeDelegate(Filter delegate, ServletRequest request, ServletResponse response, FilterChain filterChain)
/*     */     throws ServletException, IOException
/*     */   {
/* 343 */     delegate.doFilter(request, response, filterChain);
/*     */   }
/*     */ 
/*     */   protected void destroyDelegate(Filter delegate)
/*     */   {
/* 354 */     if (isTargetFilterLifecycle())
/* 355 */       delegate.destroy();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.filter.DelegatingFilterProxy
 * JD-Core Version:    0.6.1
 */