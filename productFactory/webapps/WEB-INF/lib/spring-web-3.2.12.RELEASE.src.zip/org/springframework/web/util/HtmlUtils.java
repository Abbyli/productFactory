/*     */ package org.springframework.web.util;
/*     */ 
/*     */ public abstract class HtmlUtils
/*     */ {
/*  43 */   private static final HtmlCharacterEntityReferences characterEntityReferences = new HtmlCharacterEntityReferences();
/*     */ 
/*     */   public static String htmlEscape(String input)
/*     */   {
/*  60 */     if (input == null) {
/*  61 */       return null;
/*     */     }
/*  63 */     StringBuilder escaped = new StringBuilder(input.length() * 2);
/*  64 */     for (int i = 0; i < input.length(); i++) {
/*  65 */       char character = input.charAt(i);
/*  66 */       String reference = characterEntityReferences.convertToReference(character);
/*  67 */       if (reference != null) {
/*  68 */         escaped.append(reference);
/*     */       }
/*     */       else {
/*  71 */         escaped.append(character);
/*     */       }
/*     */     }
/*  74 */     return escaped.toString();
/*     */   }
/*     */ 
/*     */   public static String htmlEscapeDecimal(String input)
/*     */   {
/*  90 */     if (input == null) {
/*  91 */       return null;
/*     */     }
/*  93 */     StringBuilder escaped = new StringBuilder(input.length() * 2);
/*  94 */     for (int i = 0; i < input.length(); i++) {
/*  95 */       char character = input.charAt(i);
/*  96 */       if (characterEntityReferences.isMappedToReference(character)) {
/*  97 */         escaped.append("&#");
/*  98 */         escaped.append(character);
/*  99 */         escaped.append(';');
/*     */       }
/*     */       else {
/* 102 */         escaped.append(character);
/*     */       }
/*     */     }
/* 105 */     return escaped.toString();
/*     */   }
/*     */ 
/*     */   public static String htmlEscapeHex(String input)
/*     */   {
/* 121 */     if (input == null) {
/* 122 */       return null;
/*     */     }
/* 124 */     StringBuilder escaped = new StringBuilder(input.length() * 2);
/* 125 */     for (int i = 0; i < input.length(); i++) {
/* 126 */       char character = input.charAt(i);
/* 127 */       if (characterEntityReferences.isMappedToReference(character)) {
/* 128 */         escaped.append("&#x");
/* 129 */         escaped.append(Integer.toString(character, 16));
/* 130 */         escaped.append(';');
/*     */       }
/*     */       else {
/* 133 */         escaped.append(character);
/*     */       }
/*     */     }
/* 136 */     return escaped.toString();
/*     */   }
/*     */ 
/*     */   public static String htmlUnescape(String input)
/*     */   {
/* 159 */     if (input == null) {
/* 160 */       return null;
/*     */     }
/* 162 */     return new HtmlCharacterEntityDecoder(characterEntityReferences, input).decode();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.HtmlUtils
 * JD-Core Version:    0.6.1
 */