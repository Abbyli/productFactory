/*    */ package org.springframework.web.context.request.async;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ class DeferredResultInterceptorChain
/*    */ {
/* 32 */   private static final Log logger = LogFactory.getLog(DeferredResultInterceptorChain.class);
/*    */   private final List<DeferredResultProcessingInterceptor> interceptors;
/* 36 */   private int preProcessingIndex = -1;
/*    */ 
/*    */   public DeferredResultInterceptorChain(List<DeferredResultProcessingInterceptor> interceptors)
/*    */   {
/* 40 */     this.interceptors = interceptors;
/*    */   }
/*    */ 
/*    */   public void applyBeforeConcurrentHandling(NativeWebRequest request, DeferredResult<?> deferredResult) throws Exception {
/* 44 */     for (DeferredResultProcessingInterceptor interceptor : this.interceptors)
/* 45 */       interceptor.beforeConcurrentHandling(request, deferredResult);
/*    */   }
/*    */ 
/*    */   public void applyPreProcess(NativeWebRequest request, DeferredResult<?> deferredResult) throws Exception
/*    */   {
/* 50 */     for (DeferredResultProcessingInterceptor interceptor : this.interceptors) {
/* 51 */       interceptor.preProcess(request, deferredResult);
/* 52 */       this.preProcessingIndex += 1;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object applyPostProcess(NativeWebRequest request, DeferredResult<?> deferredResult, Object concurrentResult) {
/*    */     try {
/* 58 */       for (int i = this.preProcessingIndex; i >= 0; i--)
/* 59 */         ((DeferredResultProcessingInterceptor)this.interceptors.get(i)).postProcess(request, deferredResult, concurrentResult);
/*    */     }
/*    */     catch (Throwable t)
/*    */     {
/* 63 */       return t;
/*    */     }
/* 65 */     return concurrentResult;
/*    */   }
/*    */ 
/*    */   public void triggerAfterTimeout(NativeWebRequest request, DeferredResult<?> deferredResult) throws Exception {
/* 69 */     for (DeferredResultProcessingInterceptor interceptor : this.interceptors) {
/* 70 */       if (deferredResult.isSetOrExpired()) {
/* 71 */         return;
/*    */       }
/* 73 */       if (!interceptor.handleTimeout(request, deferredResult))
/*    */         break;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void triggerAfterCompletion(NativeWebRequest request, DeferredResult<?> deferredResult)
/*    */   {
/* 80 */     for (int i = this.preProcessingIndex; i >= 0; i--)
/*    */       try {
/* 82 */         ((DeferredResultProcessingInterceptor)this.interceptors.get(i)).afterCompletion(request, deferredResult);
/*    */       }
/*    */       catch (Throwable t) {
/* 85 */         logger.error("afterCompletion error", t);
/*    */       }
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.DeferredResultInterceptorChain
 * JD-Core Version:    0.6.1
 */