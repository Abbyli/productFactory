/*    */ package org.springframework.web.client;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class RestClientException extends NestedRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -4084444984163796577L;
/*    */ 
/*    */   public RestClientException(String msg)
/*    */   {
/* 38 */     super(msg);
/*    */   }
/*    */ 
/*    */   public RestClientException(String msg, Throwable ex)
/*    */   {
/* 48 */     super(msg, ex);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.client.RestClientException
 * JD-Core Version:    0.6.1
 */