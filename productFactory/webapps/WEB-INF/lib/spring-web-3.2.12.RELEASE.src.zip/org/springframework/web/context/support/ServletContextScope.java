/*     */ package org.springframework.web.context.support;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.ObjectFactory;
/*     */ import org.springframework.beans.factory.config.Scope;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ServletContextScope
/*     */   implements Scope, DisposableBean
/*     */ {
/*     */   private final ServletContext servletContext;
/*  52 */   private final Map<String, Runnable> destructionCallbacks = new LinkedHashMap();
/*     */ 
/*     */   public ServletContextScope(ServletContext servletContext)
/*     */   {
/*  60 */     Assert.notNull(servletContext, "ServletContext must not be null");
/*  61 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public Object get(String name, ObjectFactory<?> objectFactory)
/*     */   {
/*  66 */     Object scopedObject = this.servletContext.getAttribute(name);
/*  67 */     if (scopedObject == null) {
/*  68 */       scopedObject = objectFactory.getObject();
/*  69 */       this.servletContext.setAttribute(name, scopedObject);
/*     */     }
/*  71 */     return scopedObject;
/*     */   }
/*     */ 
/*     */   public Object remove(String name) {
/*  75 */     Object scopedObject = this.servletContext.getAttribute(name);
/*  76 */     if (scopedObject != null) {
/*  77 */       this.servletContext.removeAttribute(name);
/*  78 */       this.destructionCallbacks.remove(name);
/*  79 */       return scopedObject;
/*     */     }
/*     */ 
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   public void registerDestructionCallback(String name, Runnable callback)
/*     */   {
/*  87 */     this.destructionCallbacks.put(name, callback);
/*     */   }
/*     */ 
/*     */   public Object resolveContextualObject(String key) {
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */   public String getConversationId() {
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 105 */     for (Runnable runnable : this.destructionCallbacks.values()) {
/* 106 */       runnable.run();
/*     */     }
/* 108 */     this.destructionCallbacks.clear();
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ServletContextScope
 * JD-Core Version:    0.6.1
 */