/*    */ package org.springframework.web.context.support;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletRequestWrapper;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ public class ContextExposingHttpServletRequest extends HttpServletRequestWrapper
/*    */ {
/*    */   private final WebApplicationContext webApplicationContext;
/*    */   private final Set<String> exposedContextBeanNames;
/*    */   private Set<String> explicitAttributes;
/*    */ 
/*    */   public ContextExposingHttpServletRequest(HttpServletRequest originalRequest, WebApplicationContext context)
/*    */   {
/* 51 */     this(originalRequest, context, null);
/*    */   }
/*    */ 
/*    */   public ContextExposingHttpServletRequest(HttpServletRequest originalRequest, WebApplicationContext context, Set<String> exposedContextBeanNames)
/*    */   {
/* 65 */     super(originalRequest);
/* 66 */     Assert.notNull(context, "WebApplicationContext must not be null");
/* 67 */     this.webApplicationContext = context;
/* 68 */     this.exposedContextBeanNames = exposedContextBeanNames;
/*    */   }
/*    */ 
/*    */   public final WebApplicationContext getWebApplicationContext()
/*    */   {
/* 76 */     return this.webApplicationContext;
/*    */   }
/*    */ 
/*    */   public Object getAttribute(String name)
/*    */   {
/* 82 */     if (((this.explicitAttributes == null) || (!this.explicitAttributes.contains(name))) && ((this.exposedContextBeanNames == null) || (this.exposedContextBeanNames.contains(name))) && (this.webApplicationContext.containsBean(name)))
/*    */     {
/* 85 */       return this.webApplicationContext.getBean(name);
/*    */     }
/*    */ 
/* 88 */     return super.getAttribute(name);
/*    */   }
/*    */ 
/*    */   public void setAttribute(String name, Object value)
/*    */   {
/* 94 */     super.setAttribute(name, value);
/* 95 */     if (this.explicitAttributes == null) {
/* 96 */       this.explicitAttributes = new HashSet(8);
/*    */     }
/* 98 */     this.explicitAttributes.add(name);
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.support.ContextExposingHttpServletRequest
 * JD-Core Version:    0.6.1
 */