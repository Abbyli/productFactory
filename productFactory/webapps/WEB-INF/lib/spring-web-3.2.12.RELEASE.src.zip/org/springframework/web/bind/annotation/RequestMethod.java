/*    */ package org.springframework.web.bind.annotation;
/*    */ 
/*    */ public enum RequestMethod
/*    */ {
/* 39 */   GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE;
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.annotation.RequestMethod
 * JD-Core Version:    0.6.1
 */