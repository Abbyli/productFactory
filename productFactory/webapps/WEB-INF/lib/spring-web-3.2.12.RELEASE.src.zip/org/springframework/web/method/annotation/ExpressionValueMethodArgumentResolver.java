/*    */ package org.springframework.web.method.annotation;
/*    */ 
/*    */ import javax.servlet.ServletException;
/*    */ import org.springframework.beans.factory.annotation.Value;
/*    */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*    */ import org.springframework.core.MethodParameter;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class ExpressionValueMethodArgumentResolver extends AbstractNamedValueMethodArgumentResolver
/*    */ {
/*    */   public ExpressionValueMethodArgumentResolver(ConfigurableBeanFactory beanFactory)
/*    */   {
/* 48 */     super(beanFactory);
/*    */   }
/*    */ 
/*    */   public boolean supportsParameter(MethodParameter parameter) {
/* 52 */     return parameter.hasParameterAnnotation(Value.class);
/*    */   }
/*    */ 
/*    */   protected AbstractNamedValueMethodArgumentResolver.NamedValueInfo createNamedValueInfo(MethodParameter parameter)
/*    */   {
/* 57 */     Value annotation = (Value)parameter.getParameterAnnotation(Value.class);
/* 58 */     return new ExpressionValueNamedValueInfo(annotation, null);
/*    */   }
/*    */ 
/*    */   protected Object resolveName(String name, MethodParameter parameter, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   protected void handleMissingValue(String name, MethodParameter parameter) throws ServletException
/*    */   {
/* 70 */     throw new UnsupportedOperationException("@Value is never required: " + parameter.getMethod());
/*    */   }
/*    */ 
/*    */   private static class ExpressionValueNamedValueInfo extends AbstractNamedValueMethodArgumentResolver.NamedValueInfo
/*    */   {
/*    */     private ExpressionValueNamedValueInfo(Value annotation) {
/* 76 */       super(false, annotation.value());
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.annotation.ExpressionValueMethodArgumentResolver
 * JD-Core Version:    0.6.1
 */