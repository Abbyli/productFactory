/*     */ package org.springframework.web.context.request.async;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.task.AsyncTaskExecutor;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.util.UrlPathHelper;
/*     */ 
/*     */ public final class WebAsyncManager
/*     */ {
/*  59 */   private static final Object RESULT_NONE = new Object();
/*     */ 
/*  61 */   private static final Log logger = LogFactory.getLog(WebAsyncManager.class);
/*     */ 
/*  63 */   private static final UrlPathHelper urlPathHelper = new UrlPathHelper();
/*     */ 
/*  65 */   private static final CallableProcessingInterceptor timeoutCallableInterceptor = new TimeoutCallableProcessingInterceptor();
/*     */ 
/*  68 */   private static final DeferredResultProcessingInterceptor timeoutDeferredResultInterceptor = new TimeoutDeferredResultProcessingInterceptor();
/*     */   private AsyncWebRequest asyncWebRequest;
/*  74 */   private AsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor(getClass().getSimpleName());
/*     */ 
/*  76 */   private Object concurrentResult = RESULT_NONE;
/*     */   private Object[] concurrentResultContext;
/*  80 */   private final Map<Object, CallableProcessingInterceptor> callableInterceptors = new LinkedHashMap();
/*     */ 
/*  83 */   private final Map<Object, DeferredResultProcessingInterceptor> deferredResultInterceptors = new LinkedHashMap();
/*     */ 
/*     */   public void setAsyncWebRequest(final AsyncWebRequest asyncWebRequest)
/*     */   {
/* 106 */     Assert.notNull(asyncWebRequest, "AsyncWebRequest must not be null");
/* 107 */     Assert.state(!isConcurrentHandlingStarted(), "Can't set AsyncWebRequest with concurrent handling in progress");
/* 108 */     this.asyncWebRequest = asyncWebRequest;
/* 109 */     this.asyncWebRequest.addCompletionHandler(new Runnable() {
/*     */       public void run() {
/* 111 */         asyncWebRequest.removeAttribute(WebAsyncUtils.WEB_ASYNC_MANAGER_ATTRIBUTE, 0);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(AsyncTaskExecutor taskExecutor)
/*     */   {
/* 122 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public boolean isConcurrentHandlingStarted()
/*     */   {
/* 134 */     return (this.asyncWebRequest != null) && (this.asyncWebRequest.isAsyncStarted());
/*     */   }
/*     */ 
/*     */   public boolean hasConcurrentResult()
/*     */   {
/* 141 */     return this.concurrentResult != RESULT_NONE;
/*     */   }
/*     */ 
/*     */   public Object getConcurrentResult()
/*     */   {
/* 151 */     return this.concurrentResult;
/*     */   }
/*     */ 
/*     */   public Object[] getConcurrentResultContext()
/*     */   {
/* 160 */     return this.concurrentResultContext;
/*     */   }
/*     */ 
/*     */   public CallableProcessingInterceptor getCallableInterceptor(Object key)
/*     */   {
/* 169 */     return (CallableProcessingInterceptor)this.callableInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public DeferredResultProcessingInterceptor getDeferredResultInterceptor(Object key)
/*     */   {
/* 178 */     return (DeferredResultProcessingInterceptor)this.deferredResultInterceptors.get(key);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptor(Object key, CallableProcessingInterceptor interceptor)
/*     */   {
/* 187 */     Assert.notNull(key, "Key is required");
/* 188 */     Assert.notNull(interceptor, "CallableProcessingInterceptor  is required");
/* 189 */     this.callableInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerCallableInterceptors(CallableProcessingInterceptor[] interceptors)
/*     */   {
/* 198 */     Assert.notNull(interceptors, "A CallableProcessingInterceptor is required");
/* 199 */     for (CallableProcessingInterceptor interceptor : interceptors) {
/* 200 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 201 */       this.callableInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptor(Object key, DeferredResultProcessingInterceptor interceptor)
/*     */   {
/* 211 */     Assert.notNull(key, "Key is required");
/* 212 */     Assert.notNull(interceptor, "DeferredResultProcessingInterceptor is required");
/* 213 */     this.deferredResultInterceptors.put(key, interceptor);
/*     */   }
/*     */ 
/*     */   public void registerDeferredResultInterceptors(DeferredResultProcessingInterceptor[] interceptors)
/*     */   {
/* 222 */     Assert.notNull(interceptors, "A DeferredResultProcessingInterceptor is required");
/* 223 */     for (DeferredResultProcessingInterceptor interceptor : interceptors) {
/* 224 */       String key = interceptor.getClass().getName() + ":" + interceptor.hashCode();
/* 225 */       this.deferredResultInterceptors.put(key, interceptor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearConcurrentResult()
/*     */   {
/* 234 */     this.concurrentResult = RESULT_NONE;
/* 235 */     this.concurrentResultContext = null;
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(Callable<?> callable, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 253 */     Assert.notNull(callable, "Callable must not be null");
/* 254 */     startCallableProcessing(new WebAsyncTask(callable), processingContext);
/*     */   }
/*     */ 
/*     */   public void startCallableProcessing(WebAsyncTask<?> webAsyncTask, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 267 */     Assert.notNull(webAsyncTask, "WebAsyncTask must not be null");
/* 268 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 270 */     Long timeout = webAsyncTask.getTimeout();
/* 271 */     if (timeout != null) {
/* 272 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 275 */     AsyncTaskExecutor executor = webAsyncTask.getExecutor();
/* 276 */     if (executor != null) {
/* 277 */       this.taskExecutor = executor;
/*     */     }
/*     */ 
/* 280 */     List interceptors = new ArrayList();
/* 281 */     interceptors.add(webAsyncTask.getInterceptor());
/* 282 */     interceptors.addAll(this.callableInterceptors.values());
/* 283 */     interceptors.add(timeoutCallableInterceptor);
/*     */ 
/* 285 */     final Callable callable = webAsyncTask.getCallable();
/* 286 */     final CallableInterceptorChain interceptorChain = new CallableInterceptorChain(interceptors);
/*     */ 
/* 288 */     this.asyncWebRequest.addTimeoutHandler(new Runnable() {
/*     */       public void run() {
/* 290 */         WebAsyncManager.logger.debug("Processing timeout");
/* 291 */         Object result = interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, callable);
/* 292 */         if (result != CallableProcessingInterceptor.RESULT_NONE)
/* 293 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       }
/*     */     });
/* 298 */     this.asyncWebRequest.addCompletionHandler(new Runnable() {
/*     */       public void run() {
/* 300 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, callable);
/*     */       }
/*     */     });
/* 304 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, callable);
/* 305 */     startAsyncProcessing(processingContext);
/*     */ 
/* 307 */     this.taskExecutor.submit(new Runnable() {
/*     */       public void run() {
/* 309 */         Object result = null;
/*     */         try {
/* 311 */           interceptorChain.applyPreProcess(WebAsyncManager.this.asyncWebRequest, callable);
/* 312 */           result = callable.call();
/*     */         }
/*     */         catch (Throwable ex) {
/* 315 */           result = ex;
/*     */         }
/*     */         finally {
/* 318 */           result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, callable, result);
/*     */         }
/* 320 */         WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private void setConcurrentResultAndDispatch(Object result) {
/* 326 */     synchronized (this) {
/* 327 */       if (hasConcurrentResult()) {
/* 328 */         return;
/*     */       }
/* 330 */       this.concurrentResult = result;
/*     */     }
/*     */ 
/* 333 */     if (this.asyncWebRequest.isAsyncComplete()) {
/* 334 */       logger.error("Could not complete async processing due to timeout or network error");
/* 335 */       return;
/*     */     }
/*     */ 
/* 338 */     if (logger.isDebugEnabled()) {
/* 339 */       logger.debug("Concurrent result value [" + this.concurrentResult + "] - dispatching request to resume processing");
/*     */     }
/*     */ 
/* 343 */     this.asyncWebRequest.dispatch();
/*     */   }
/*     */ 
/*     */   public void startDeferredResultProcessing(final DeferredResult<?> deferredResult, Object[] processingContext)
/*     */     throws Exception
/*     */   {
/* 363 */     Assert.notNull(deferredResult, "DeferredResult must not be null");
/* 364 */     Assert.state(this.asyncWebRequest != null, "AsyncWebRequest must not be null");
/*     */ 
/* 366 */     Long timeout = deferredResult.getTimeoutValue();
/* 367 */     if (timeout != null) {
/* 368 */       this.asyncWebRequest.setTimeout(timeout);
/*     */     }
/*     */ 
/* 371 */     List interceptors = new ArrayList();
/* 372 */     interceptors.add(deferredResult.getInterceptor());
/* 373 */     interceptors.addAll(this.deferredResultInterceptors.values());
/* 374 */     interceptors.add(timeoutDeferredResultInterceptor);
/*     */ 
/* 376 */     final DeferredResultInterceptorChain interceptorChain = new DeferredResultInterceptorChain(interceptors);
/*     */ 
/* 378 */     this.asyncWebRequest.addTimeoutHandler(new Runnable() {
/*     */       public void run() {
/*     */         try {
/* 381 */           interceptorChain.triggerAfterTimeout(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */         }
/*     */         catch (Throwable ex) {
/* 384 */           WebAsyncManager.this.setConcurrentResultAndDispatch(ex);
/*     */         }
/*     */       }
/*     */     });
/* 389 */     this.asyncWebRequest.addCompletionHandler(new Runnable() {
/*     */       public void run() {
/* 391 */         interceptorChain.triggerAfterCompletion(WebAsyncManager.this.asyncWebRequest, deferredResult);
/*     */       }
/*     */     });
/* 395 */     interceptorChain.applyBeforeConcurrentHandling(this.asyncWebRequest, deferredResult);
/* 396 */     startAsyncProcessing(processingContext);
/*     */     try
/*     */     {
/* 399 */       interceptorChain.applyPreProcess(this.asyncWebRequest, deferredResult);
/* 400 */       deferredResult.setResultHandler(new DeferredResult.DeferredResultHandler() {
/*     */         public void handleResult(Object result) {
/* 402 */           result = interceptorChain.applyPostProcess(WebAsyncManager.this.asyncWebRequest, deferredResult, result);
/* 403 */           WebAsyncManager.this.setConcurrentResultAndDispatch(result);
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (Throwable ex) {
/* 408 */       setConcurrentResultAndDispatch(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void startAsyncProcessing(Object[] processingContext) {
/* 413 */     clearConcurrentResult();
/* 414 */     this.concurrentResultContext = processingContext;
/* 415 */     this.asyncWebRequest.startAsync();
/*     */ 
/* 417 */     if (logger.isDebugEnabled()) {
/* 418 */       HttpServletRequest request = (HttpServletRequest)this.asyncWebRequest.getNativeRequest(HttpServletRequest.class);
/* 419 */       String requestUri = urlPathHelper.getRequestUri(request);
/* 420 */       logger.debug("Concurrent handling starting for " + request.getMethod() + " [" + requestUri + "]");
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.async.WebAsyncManager
 * JD-Core Version:    0.6.1
 */