/*     */ package org.springframework.web.multipart.commons;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.fileupload.FileItemFactory;
/*     */ import org.apache.commons.fileupload.FileUpload;
/*     */ import org.apache.commons.fileupload.FileUploadBase.SizeLimitExceededException;
/*     */ import org.apache.commons.fileupload.FileUploadException;
/*     */ import org.apache.commons.fileupload.disk.DiskFileItemFactory;
/*     */ import org.apache.commons.fileupload.servlet.ServletFileUpload;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.multipart.MaxUploadSizeExceededException;
/*     */ import org.springframework.web.multipart.MultipartException;
/*     */ import org.springframework.web.multipart.MultipartHttpServletRequest;
/*     */ import org.springframework.web.multipart.MultipartResolver;
/*     */ import org.springframework.web.multipart.support.DefaultMultipartHttpServletRequest;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class CommonsMultipartResolver extends CommonsFileUploadSupport
/*     */   implements MultipartResolver, ServletContextAware
/*     */ {
/*  65 */   private boolean resolveLazily = false;
/*     */ 
/*     */   public CommonsMultipartResolver()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CommonsMultipartResolver(ServletContext servletContext)
/*     */   {
/*  86 */     this();
/*  87 */     setServletContext(servletContext);
/*     */   }
/*     */ 
/*     */   public void setResolveLazily(boolean resolveLazily)
/*     */   {
/* 100 */     this.resolveLazily = resolveLazily;
/*     */   }
/*     */ 
/*     */   protected FileUpload newFileUpload(FileItemFactory fileItemFactory)
/*     */   {
/* 111 */     return new ServletFileUpload(fileItemFactory);
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext) {
/* 115 */     if (!isUploadTempDirSpecified())
/* 116 */       getFileItemFactory().setRepository(WebUtils.getTempDir(servletContext));
/*     */   }
/*     */ 
/*     */   public boolean isMultipart(HttpServletRequest request)
/*     */   {
/* 122 */     return (request != null) && (ServletFileUpload.isMultipartContent(request));
/*     */   }
/*     */ 
/*     */   public MultipartHttpServletRequest resolveMultipart(final HttpServletRequest request) throws MultipartException {
/* 126 */     Assert.notNull(request, "Request must not be null");
/* 127 */     if (this.resolveLazily) {
/* 128 */       return new DefaultMultipartHttpServletRequest(request)
/*     */       {
/*     */         protected void initializeMultipart() {
/* 131 */           CommonsFileUploadSupport.MultipartParsingResult parsingResult = CommonsMultipartResolver.this.parseRequest(request);
/* 132 */           setMultipartFiles(parsingResult.getMultipartFiles());
/* 133 */           setMultipartParameters(parsingResult.getMultipartParameters());
/* 134 */           setMultipartParameterContentTypes(parsingResult.getMultipartParameterContentTypes());
/*     */         }
/*     */       };
/*     */     }
/*     */ 
/* 139 */     CommonsFileUploadSupport.MultipartParsingResult parsingResult = parseRequest(request);
/* 140 */     return new DefaultMultipartHttpServletRequest(request, parsingResult.getMultipartFiles(), parsingResult.getMultipartParameters(), parsingResult.getMultipartParameterContentTypes());
/*     */   }
/*     */ 
/*     */   protected CommonsFileUploadSupport.MultipartParsingResult parseRequest(HttpServletRequest request)
/*     */     throws MultipartException
/*     */   {
/* 153 */     String encoding = determineEncoding(request);
/* 154 */     FileUpload fileUpload = prepareFileUpload(encoding);
/*     */     try {
/* 156 */       List fileItems = ((ServletFileUpload)fileUpload).parseRequest(request);
/* 157 */       return parseFileItems(fileItems, encoding);
/*     */     }
/*     */     catch (FileUploadBase.SizeLimitExceededException ex) {
/* 160 */       throw new MaxUploadSizeExceededException(fileUpload.getSizeMax(), ex);
/*     */     }
/*     */     catch (FileUploadException ex) {
/* 163 */       throw new MultipartException("Could not parse multipart servlet request", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String determineEncoding(HttpServletRequest request)
/*     */   {
/* 178 */     String encoding = request.getCharacterEncoding();
/* 179 */     if (encoding == null) {
/* 180 */       encoding = getDefaultEncoding();
/*     */     }
/* 182 */     return encoding;
/*     */   }
/*     */ 
/*     */   public void cleanupMultipart(MultipartHttpServletRequest request) {
/* 186 */     if (request != null)
/*     */       try {
/* 188 */         cleanupFileItems(request.getMultiFileMap());
/*     */       }
/*     */       catch (Throwable ex) {
/* 191 */         this.logger.warn("Failed to perform multipart cleanup for servlet request", ex);
/*     */       }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.multipart.commons.CommonsMultipartResolver
 * JD-Core Version:    0.6.1
 */