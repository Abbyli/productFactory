package org.springframework.web.accept;

import java.util.List;
import org.springframework.http.MediaType;

public abstract interface MediaTypeFileExtensionResolver
{
  public abstract List<String> resolveFileExtensions(MediaType paramMediaType);

  public abstract List<String> getAllFileExtensions();
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.MediaTypeFileExtensionResolver
 * JD-Core Version:    0.6.1
 */