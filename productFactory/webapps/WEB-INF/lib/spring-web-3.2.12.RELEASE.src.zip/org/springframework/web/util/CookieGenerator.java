/*     */ package org.springframework.web.util;
/*     */ 
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class CookieGenerator
/*     */ {
/*     */   public static final String DEFAULT_COOKIE_PATH = "/";
/*     */ 
/*     */   @Deprecated
/*     */   public static final int DEFAULT_COOKIE_MAX_AGE = 2147483647;
/*  57 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private String cookieName;
/*     */   private String cookieDomain;
/*  63 */   private String cookiePath = "/";
/*     */ 
/*  65 */   private Integer cookieMaxAge = null;
/*     */ 
/*  67 */   private boolean cookieSecure = false;
/*     */ 
/*  69 */   private boolean cookieHttpOnly = false;
/*     */ 
/*     */   public void setCookieName(String cookieName)
/*     */   {
/*  77 */     this.cookieName = cookieName;
/*     */   }
/*     */ 
/*     */   public String getCookieName()
/*     */   {
/*  84 */     return this.cookieName;
/*     */   }
/*     */ 
/*     */   public void setCookieDomain(String cookieDomain)
/*     */   {
/*  93 */     this.cookieDomain = cookieDomain;
/*     */   }
/*     */ 
/*     */   public String getCookieDomain()
/*     */   {
/* 100 */     return this.cookieDomain;
/*     */   }
/*     */ 
/*     */   public void setCookiePath(String cookiePath)
/*     */   {
/* 109 */     this.cookiePath = cookiePath;
/*     */   }
/*     */ 
/*     */   public String getCookiePath()
/*     */   {
/* 116 */     return this.cookiePath;
/*     */   }
/*     */ 
/*     */   public void setCookieMaxAge(Integer cookieMaxAge)
/*     */   {
/* 125 */     this.cookieMaxAge = cookieMaxAge;
/*     */   }
/*     */ 
/*     */   public Integer getCookieMaxAge()
/*     */   {
/* 132 */     return this.cookieMaxAge;
/*     */   }
/*     */ 
/*     */   public void setCookieSecure(boolean cookieSecure)
/*     */   {
/* 142 */     this.cookieSecure = cookieSecure;
/*     */   }
/*     */ 
/*     */   public boolean isCookieSecure()
/*     */   {
/* 150 */     return this.cookieSecure;
/*     */   }
/*     */ 
/*     */   public void setCookieHttpOnly(boolean cookieHttpOnly)
/*     */   {
/* 159 */     this.cookieHttpOnly = cookieHttpOnly;
/*     */   }
/*     */ 
/*     */   public boolean isCookieHttpOnly()
/*     */   {
/* 166 */     return this.cookieHttpOnly;
/*     */   }
/*     */ 
/*     */   public void addCookie(HttpServletResponse response, String cookieValue)
/*     */   {
/* 182 */     Assert.notNull(response, "HttpServletResponse must not be null");
/* 183 */     Cookie cookie = createCookie(cookieValue);
/* 184 */     Integer maxAge = getCookieMaxAge();
/* 185 */     if (maxAge != null) {
/* 186 */       cookie.setMaxAge(maxAge.intValue());
/*     */     }
/* 188 */     if (isCookieSecure()) {
/* 189 */       cookie.setSecure(true);
/*     */     }
/* 191 */     if (isCookieHttpOnly()) {
/* 192 */       cookie.setHttpOnly(true);
/*     */     }
/* 194 */     response.addCookie(cookie);
/* 195 */     if (this.logger.isDebugEnabled())
/* 196 */       this.logger.debug("Added cookie with name [" + getCookieName() + "] and value [" + cookieValue + "]");
/*     */   }
/*     */ 
/*     */   public void removeCookie(HttpServletResponse response)
/*     */   {
/* 210 */     Assert.notNull(response, "HttpServletResponse must not be null");
/* 211 */     Cookie cookie = createCookie("");
/* 212 */     cookie.setMaxAge(0);
/* 213 */     response.addCookie(cookie);
/* 214 */     if (this.logger.isDebugEnabled())
/* 215 */       this.logger.debug("Removed cookie with name [" + getCookieName() + "]");
/*     */   }
/*     */ 
/*     */   protected Cookie createCookie(String cookieValue)
/*     */   {
/* 229 */     Cookie cookie = new Cookie(getCookieName(), cookieValue);
/* 230 */     if (getCookieDomain() != null) {
/* 231 */       cookie.setDomain(getCookieDomain());
/*     */     }
/* 233 */     cookie.setPath(getCookiePath());
/* 234 */     return cookie;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.util.CookieGenerator
 * JD-Core Version:    0.6.1
 */