/*    */ package org.springframework.web.bind.support;
/*    */ 
/*    */ import org.springframework.web.bind.WebDataBinder;
/*    */ import org.springframework.web.context.request.NativeWebRequest;
/*    */ 
/*    */ public class DefaultDataBinderFactory
/*    */   implements WebDataBinderFactory
/*    */ {
/*    */   private final WebBindingInitializer initializer;
/*    */ 
/*    */   public DefaultDataBinderFactory(WebBindingInitializer initializer)
/*    */   {
/* 38 */     this.initializer = initializer;
/*    */   }
/*    */ 
/*    */   public final WebDataBinder createBinder(NativeWebRequest webRequest, Object target, String objectName)
/*    */     throws Exception
/*    */   {
/* 48 */     WebDataBinder dataBinder = createBinderInstance(target, objectName, webRequest);
/* 49 */     if (this.initializer != null) {
/* 50 */       this.initializer.initBinder(dataBinder, webRequest);
/*    */     }
/* 52 */     initBinder(dataBinder, webRequest);
/* 53 */     return dataBinder;
/*    */   }
/*    */ 
/*    */   protected WebDataBinder createBinderInstance(Object target, String objectName, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/* 66 */     return new WebRequestDataBinder(target, objectName);
/*    */   }
/*    */ 
/*    */   protected void initBinder(WebDataBinder dataBinder, NativeWebRequest webRequest)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.bind.support.DefaultDataBinderFactory
 * JD-Core Version:    0.6.1
 */