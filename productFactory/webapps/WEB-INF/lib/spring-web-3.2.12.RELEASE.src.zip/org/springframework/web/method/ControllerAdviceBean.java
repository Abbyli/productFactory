/*     */ package org.springframework.web.method;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.annotation.Order;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.web.bind.annotation.ControllerAdvice;
/*     */ 
/*     */ public class ControllerAdviceBean
/*     */   implements Ordered
/*     */ {
/*     */   private final Object bean;
/*     */   private final int order;
/*     */   private final BeanFactory beanFactory;
/*     */ 
/*     */   public ControllerAdviceBean(String beanName, BeanFactory beanFactory)
/*     */   {
/*  56 */     Assert.hasText(beanName, "Bean name must not be null");
/*  57 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*     */ 
/*  59 */     if (!beanFactory.containsBean(beanName)) {
/*  60 */       throw new IllegalArgumentException("BeanFactory [" + beanFactory + "] does not contain bean with name '" + beanName + "'");
/*     */     }
/*     */ 
/*  64 */     this.bean = beanName;
/*  65 */     this.beanFactory = beanFactory;
/*  66 */     this.order = initOrderFromBeanType(this.beanFactory.getType(beanName));
/*     */   }
/*     */ 
/*     */   public ControllerAdviceBean(Object bean)
/*     */   {
/*  74 */     Assert.notNull(bean, "Bean must not be null");
/*  75 */     this.bean = bean;
/*  76 */     this.order = initOrderFromBean(bean);
/*  77 */     this.beanFactory = null;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/*  86 */     return this.order;
/*     */   }
/*     */ 
/*     */   public Class<?> getBeanType()
/*     */   {
/*  94 */     Class clazz = (this.bean instanceof String) ? this.beanFactory.getType((String)this.bean) : this.bean.getClass();
/*     */ 
/*  96 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   public Object resolveBean()
/*     */   {
/* 103 */     return (this.bean instanceof String) ? this.beanFactory.getBean((String)this.bean) : this.bean;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 109 */     return (this == other) || (((other instanceof ControllerAdviceBean)) && (this.bean.equals(((ControllerAdviceBean)other).bean)));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 115 */     return this.bean.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 120 */     return this.bean.toString();
/*     */   }
/*     */ 
/*     */   public static List<ControllerAdviceBean> findAnnotatedBeans(ApplicationContext applicationContext)
/*     */   {
/* 130 */     List beans = new ArrayList();
/* 131 */     for (String name : applicationContext.getBeanDefinitionNames()) {
/* 132 */       if (applicationContext.findAnnotationOnBean(name, ControllerAdvice.class) != null) {
/* 133 */         beans.add(new ControllerAdviceBean(name, applicationContext));
/*     */       }
/*     */     }
/* 136 */     return beans;
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBean(Object bean) {
/* 140 */     return (bean instanceof Ordered) ? ((Ordered)bean).getOrder() : initOrderFromBeanType(bean.getClass());
/*     */   }
/*     */ 
/*     */   private static int initOrderFromBeanType(Class<?> beanType) {
/* 144 */     Order ann = (Order)AnnotationUtils.findAnnotation(beanType, Order.class);
/* 145 */     return ann != null ? ann.value() : 2147483647;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.method.ControllerAdviceBean
 * JD-Core Version:    0.6.1
 */