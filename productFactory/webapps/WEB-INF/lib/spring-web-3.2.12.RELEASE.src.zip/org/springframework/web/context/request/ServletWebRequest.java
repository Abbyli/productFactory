/*     */ package org.springframework.web.context.request;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.util.WebUtils;
/*     */ 
/*     */ public class ServletWebRequest extends ServletRequestAttributes
/*     */   implements NativeWebRequest
/*     */ {
/*     */   private static final String HEADER_ETAG = "ETag";
/*     */   private static final String HEADER_IF_MODIFIED_SINCE = "If-Modified-Since";
/*     */   private static final String HEADER_IF_NONE_MATCH = "If-None-Match";
/*     */   private static final String HEADER_LAST_MODIFIED = "Last-Modified";
/*     */   private static final String METHOD_GET = "GET";
/*     */   private static final String METHOD_HEAD = "HEAD";
/*     */   private HttpServletResponse response;
/*  56 */   private boolean notModified = false;
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request)
/*     */   {
/*  64 */     super(request);
/*     */   }
/*     */ 
/*     */   public ServletWebRequest(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/*  73 */     this(request);
/*  74 */     this.response = response;
/*     */   }
/*     */ 
/*     */   public final HttpServletResponse getResponse()
/*     */   {
/*  82 */     return this.response;
/*     */   }
/*     */ 
/*     */   public Object getNativeRequest() {
/*  86 */     return getRequest();
/*     */   }
/*     */ 
/*     */   public Object getNativeResponse() {
/*  90 */     return getResponse();
/*     */   }
/*     */ 
/*     */   public <T> T getNativeRequest(Class<T> requiredType) {
/*  94 */     return WebUtils.getNativeRequest(getRequest(), requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T getNativeResponse(Class<T> requiredType) {
/*  98 */     return WebUtils.getNativeResponse(getResponse(), requiredType);
/*     */   }
/*     */ 
/*     */   public String getHeader(String headerName)
/*     */   {
/* 103 */     return getRequest().getHeader(headerName);
/*     */   }
/*     */ 
/*     */   public String[] getHeaderValues(String headerName) {
/* 107 */     String[] headerValues = StringUtils.toStringArray(getRequest().getHeaders(headerName));
/* 108 */     return !ObjectUtils.isEmpty(headerValues) ? headerValues : null;
/*     */   }
/*     */ 
/*     */   public Iterator<String> getHeaderNames() {
/* 112 */     return CollectionUtils.toIterator(getRequest().getHeaderNames());
/*     */   }
/*     */ 
/*     */   public String getParameter(String paramName) {
/* 116 */     return getRequest().getParameter(paramName);
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String paramName) {
/* 120 */     return getRequest().getParameterValues(paramName);
/*     */   }
/*     */ 
/*     */   public Iterator<String> getParameterNames() {
/* 124 */     return CollectionUtils.toIterator(getRequest().getParameterNames());
/*     */   }
/*     */ 
/*     */   public Map<String, String[]> getParameterMap() {
/* 128 */     return getRequest().getParameterMap();
/*     */   }
/*     */ 
/*     */   public Locale getLocale() {
/* 132 */     return getRequest().getLocale();
/*     */   }
/*     */ 
/*     */   public String getContextPath() {
/* 136 */     return getRequest().getContextPath();
/*     */   }
/*     */ 
/*     */   public String getRemoteUser() {
/* 140 */     return getRequest().getRemoteUser();
/*     */   }
/*     */ 
/*     */   public Principal getUserPrincipal() {
/* 144 */     return getRequest().getUserPrincipal();
/*     */   }
/*     */ 
/*     */   public boolean isUserInRole(String role) {
/* 148 */     return getRequest().isUserInRole(role);
/*     */   }
/*     */ 
/*     */   public boolean isSecure() {
/* 152 */     return getRequest().isSecure();
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(long lastModifiedTimestamp)
/*     */   {
/* 157 */     if ((lastModifiedTimestamp >= 0L) && (!this.notModified) && ((this.response == null) || (!this.response.containsHeader("Last-Modified"))))
/*     */     {
/* 159 */       long ifModifiedSince = -1L;
/*     */       try {
/* 161 */         ifModifiedSince = getRequest().getDateHeader("If-Modified-Since");
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 164 */         String headerValue = getRequest().getHeader("If-Modified-Since");
/*     */ 
/* 166 */         int separatorIndex = headerValue.indexOf(';');
/* 167 */         if (separatorIndex != -1) {
/* 168 */           String datePart = headerValue.substring(0, separatorIndex);
/*     */           try {
/* 170 */             ifModifiedSince = Date.parse(datePart);
/*     */           }
/*     */           catch (IllegalArgumentException ex2)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/* 177 */       this.notModified = (ifModifiedSince >= lastModifiedTimestamp / 1000L * 1000L);
/* 178 */       if (this.response != null) {
/* 179 */         if ((this.notModified) && (supportsNotModifiedStatus())) {
/* 180 */           this.response.setStatus(304);
/*     */         }
/*     */         else {
/* 183 */           this.response.setDateHeader("Last-Modified", lastModifiedTimestamp);
/*     */         }
/*     */       }
/*     */     }
/* 187 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public boolean checkNotModified(String etag)
/*     */   {
/* 192 */     if ((StringUtils.hasLength(etag)) && (!this.notModified) && ((this.response == null) || (!this.response.containsHeader("ETag"))))
/*     */     {
/* 194 */       String ifNoneMatch = getRequest().getHeader("If-None-Match");
/* 195 */       this.notModified = etag.equals(ifNoneMatch);
/* 196 */       if (this.response != null) {
/* 197 */         if ((this.notModified) && (supportsNotModifiedStatus())) {
/* 198 */           this.response.setStatus(304);
/*     */         }
/*     */         else {
/* 201 */           this.response.setHeader("ETag", etag);
/*     */         }
/*     */       }
/*     */     }
/* 205 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   private boolean supportsNotModifiedStatus() {
/* 209 */     String method = getRequest().getMethod();
/* 210 */     return ("GET".equals(method)) || ("HEAD".equals(method));
/*     */   }
/*     */ 
/*     */   public boolean isNotModified() {
/* 214 */     return this.notModified;
/*     */   }
/*     */ 
/*     */   public String getDescription(boolean includeClientInfo) {
/* 218 */     HttpServletRequest request = getRequest();
/* 219 */     StringBuilder sb = new StringBuilder();
/* 220 */     sb.append("uri=").append(request.getRequestURI());
/* 221 */     if (includeClientInfo) {
/* 222 */       String client = request.getRemoteAddr();
/* 223 */       if (StringUtils.hasLength(client)) {
/* 224 */         sb.append(";client=").append(client);
/*     */       }
/* 226 */       HttpSession session = request.getSession(false);
/* 227 */       if (session != null) {
/* 228 */         sb.append(";session=").append(session.getId());
/*     */       }
/* 230 */       String user = request.getRemoteUser();
/* 231 */       if (StringUtils.hasLength(user)) {
/* 232 */         sb.append(";user=").append(user);
/*     */       }
/*     */     }
/* 235 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 241 */     return "ServletWebRequest: " + getDescription(true);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.context.request.ServletWebRequest
 * JD-Core Version:    0.6.1
 */