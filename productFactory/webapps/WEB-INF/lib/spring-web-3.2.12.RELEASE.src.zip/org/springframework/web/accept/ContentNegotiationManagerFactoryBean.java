/*     */ package org.springframework.web.accept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ 
/*     */ public class ContentNegotiationManagerFactoryBean
/*     */   implements FactoryBean<ContentNegotiationManager>, ServletContextAware, InitializingBean
/*     */ {
/*  50 */   private boolean favorPathExtension = true;
/*     */ 
/*  52 */   private boolean favorParameter = false;
/*     */ 
/*  54 */   private boolean ignoreAcceptHeader = false;
/*     */ 
/*  56 */   private Map<String, MediaType> mediaTypes = new HashMap();
/*     */   private Boolean useJaf;
/*  60 */   private String parameterName = "format";
/*     */   private MediaType defaultContentType;
/*     */   private ContentNegotiationManager contentNegotiationManager;
/*     */   private ServletContext servletContext;
/*     */ 
/*     */   public void setFavorPathExtension(boolean favorPathExtension)
/*     */   {
/*  77 */     this.favorPathExtension = favorPathExtension;
/*     */   }
/*     */ 
/*     */   public void setMediaTypes(Properties mediaTypes)
/*     */   {
/*  89 */     if (!CollectionUtils.isEmpty(mediaTypes))
/*  90 */       for (Map.Entry entry : mediaTypes.entrySet()) {
/*  91 */         String extension = ((String)entry.getKey()).toLowerCase(Locale.ENGLISH);
/*  92 */         this.mediaTypes.put(extension, MediaType.valueOf((String)entry.getValue()));
/*     */       }
/*     */   }
/*     */ 
/*     */   public void addMediaType(String fileExtension, MediaType mediaType)
/*     */   {
/* 104 */     this.mediaTypes.put(fileExtension, mediaType);
/*     */   }
/*     */ 
/*     */   public void addMediaTypes(Map<String, MediaType> mediaTypes)
/*     */   {
/* 114 */     if (mediaTypes != null)
/* 115 */       this.mediaTypes.putAll(mediaTypes);
/*     */   }
/*     */ 
/*     */   public void setUseJaf(boolean useJaf)
/*     */   {
/* 128 */     this.useJaf = Boolean.valueOf(useJaf);
/*     */   }
/*     */ 
/*     */   public void setFavorParameter(boolean favorParameter)
/*     */   {
/* 143 */     this.favorParameter = favorParameter;
/*     */   }
/*     */ 
/*     */   public void setParameterName(String parameterName)
/*     */   {
/* 152 */     Assert.notNull(parameterName, "parameterName is required");
/* 153 */     this.parameterName = parameterName;
/*     */   }
/*     */ 
/*     */   public void setIgnoreAcceptHeader(boolean ignoreAcceptHeader)
/*     */   {
/* 164 */     this.ignoreAcceptHeader = ignoreAcceptHeader;
/*     */   }
/*     */ 
/*     */   public void setDefaultContentType(MediaType defaultContentType)
/*     */   {
/* 174 */     this.defaultContentType = defaultContentType;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext servletContext) {
/* 178 */     this.servletContext = servletContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 183 */     List strategies = new ArrayList();
/*     */ 
/* 185 */     if (this.favorPathExtension)
/*     */     {
/*     */       PathExtensionContentNegotiationStrategy strategy;
/*     */       PathExtensionContentNegotiationStrategy strategy;
/* 187 */       if (this.servletContext != null) {
/* 188 */         strategy = new ServletPathExtensionContentNegotiationStrategy(this.servletContext, this.mediaTypes);
/*     */       }
/*     */       else {
/* 191 */         strategy = new PathExtensionContentNegotiationStrategy(this.mediaTypes);
/*     */       }
/* 193 */       if (this.useJaf != null) {
/* 194 */         strategy.setUseJaf(this.useJaf.booleanValue());
/*     */       }
/* 196 */       strategies.add(strategy);
/*     */     }
/*     */ 
/* 199 */     if (this.favorParameter) {
/* 200 */       ParameterContentNegotiationStrategy strategy = new ParameterContentNegotiationStrategy(this.mediaTypes);
/* 201 */       strategy.setParameterName(this.parameterName);
/* 202 */       strategies.add(strategy);
/*     */     }
/*     */ 
/* 205 */     if (!this.ignoreAcceptHeader) {
/* 206 */       strategies.add(new HeaderContentNegotiationStrategy());
/*     */     }
/*     */ 
/* 209 */     if (this.defaultContentType != null) {
/* 210 */       strategies.add(new FixedContentNegotiationStrategy(this.defaultContentType));
/*     */     }
/*     */ 
/* 213 */     this.contentNegotiationManager = new ContentNegotiationManager(strategies);
/*     */   }
/*     */ 
/*     */   public ContentNegotiationManager getObject()
/*     */   {
/* 218 */     return this.contentNegotiationManager;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 222 */     return ContentNegotiationManager.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 226 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.web.accept.ContentNegotiationManagerFactoryBean
 * JD-Core Version:    0.6.1
 */