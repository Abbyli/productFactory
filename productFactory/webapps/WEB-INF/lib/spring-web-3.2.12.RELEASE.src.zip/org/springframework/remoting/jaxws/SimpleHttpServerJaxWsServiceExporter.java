/*     */ package org.springframework.remoting.jaxws;
/*     */ 
/*     */ import com.sun.net.httpserver.Authenticator;
/*     */ import com.sun.net.httpserver.Filter;
/*     */ import com.sun.net.httpserver.HttpContext;
/*     */ import com.sun.net.httpserver.HttpServer;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.List;
/*     */ import javax.jws.WebService;
/*     */ import javax.xml.ws.Endpoint;
/*     */ import javax.xml.ws.WebServiceProvider;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SimpleHttpServerJaxWsServiceExporter extends AbstractJaxWsServiceExporter
/*     */ {
/*  51 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private HttpServer server;
/*  55 */   private int port = 8080;
/*     */   private String hostname;
/*  59 */   private int backlog = -1;
/*     */ 
/*  61 */   private int shutdownDelay = 0;
/*     */ 
/*  63 */   private String basePath = "/";
/*     */   private List<Filter> filters;
/*     */   private Authenticator authenticator;
/*  69 */   private boolean localServer = false;
/*     */ 
/*     */   public void setServer(HttpServer server)
/*     */   {
/*  81 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/*  90 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public void setHostname(String hostname)
/*     */   {
/* 100 */     this.hostname = hostname;
/*     */   }
/*     */ 
/*     */   public void setBacklog(int backlog)
/*     */   {
/* 110 */     this.backlog = backlog;
/*     */   }
/*     */ 
/*     */   public void setShutdownDelay(int shutdownDelay)
/*     */   {
/* 120 */     this.shutdownDelay = shutdownDelay;
/*     */   }
/*     */ 
/*     */   public void setBasePath(String basePath)
/*     */   {
/* 132 */     this.basePath = basePath;
/*     */   }
/*     */ 
/*     */   public void setFilters(List<Filter> filters)
/*     */   {
/* 140 */     this.filters = filters;
/*     */   }
/*     */ 
/*     */   public void setAuthenticator(Authenticator authenticator)
/*     */   {
/* 148 */     this.authenticator = authenticator;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 154 */     if (this.server == null) {
/* 155 */       InetSocketAddress address = this.hostname != null ? new InetSocketAddress(this.hostname, this.port) : new InetSocketAddress(this.port);
/*     */ 
/* 157 */       this.server = HttpServer.create(address, this.backlog);
/* 158 */       if (this.logger.isInfoEnabled()) {
/* 159 */         this.logger.info("Starting HttpServer at address " + address);
/*     */       }
/* 161 */       this.server.start();
/* 162 */       this.localServer = true;
/*     */     }
/* 164 */     super.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   protected void publishEndpoint(Endpoint endpoint, WebService annotation)
/*     */   {
/* 169 */     endpoint.publish(buildHttpContext(endpoint, annotation.serviceName()));
/*     */   }
/*     */ 
/*     */   protected void publishEndpoint(Endpoint endpoint, WebServiceProvider annotation)
/*     */   {
/* 174 */     endpoint.publish(buildHttpContext(endpoint, annotation.serviceName()));
/*     */   }
/*     */ 
/*     */   protected HttpContext buildHttpContext(Endpoint endpoint, String serviceName)
/*     */   {
/* 184 */     String fullPath = calculateEndpointPath(endpoint, serviceName);
/* 185 */     HttpContext httpContext = this.server.createContext(fullPath);
/* 186 */     if (this.filters != null) {
/* 187 */       httpContext.getFilters().addAll(this.filters);
/*     */     }
/* 189 */     if (this.authenticator != null) {
/* 190 */       httpContext.setAuthenticator(this.authenticator);
/*     */     }
/* 192 */     return httpContext;
/*     */   }
/*     */ 
/*     */   protected String calculateEndpointPath(Endpoint endpoint, String serviceName)
/*     */   {
/* 202 */     return this.basePath + serviceName;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 208 */     super.destroy();
/* 209 */     if (this.localServer) {
/* 210 */       this.logger.info("Stopping HttpServer");
/* 211 */       this.server.stop(this.shutdownDelay);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.SimpleHttpServerJaxWsServiceExporter
 * JD-Core Version:    0.6.1
 */