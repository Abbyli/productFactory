package org.springframework.remoting.jaxrpc;

import javax.xml.rpc.Service;

@Deprecated
public abstract interface JaxRpcServicePostProcessor
{
  public abstract void postProcessJaxRpcService(Service paramService);
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxrpc.JaxRpcServicePostProcessor
 * JD-Core Version:    0.6.1
 */