/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import com.sun.net.httpserver.Headers;
/*     */ import com.sun.net.httpserver.HttpExchange;
/*     */ import com.sun.net.httpserver.HttpHandler;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.remoting.rmi.RemoteInvocationSerializingExporter;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ 
/*     */ public class SimpleHttpInvokerServiceExporter extends RemoteInvocationSerializingExporter
/*     */   implements HttpHandler
/*     */ {
/*     */   public void handle(HttpExchange exchange)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  66 */       RemoteInvocation invocation = readRemoteInvocation(exchange);
/*  67 */       RemoteInvocationResult result = invokeAndCreateResult(invocation, getProxy());
/*  68 */       writeRemoteInvocationResult(exchange, result);
/*  69 */       exchange.close();
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  72 */       exchange.sendResponseHeaders(500, -1L);
/*  73 */       this.logger.error("Class not found during deserialization", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpExchange exchange)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  91 */     return readRemoteInvocation(exchange, exchange.getRequestBody());
/*     */   }
/*     */ 
/*     */   protected RemoteInvocation readRemoteInvocation(HttpExchange exchange, InputStream is)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 110 */     ObjectInputStream ois = createObjectInputStream(decorateInputStream(exchange, is));
/* 111 */     return doReadRemoteInvocation(ois);
/*     */   }
/*     */ 
/*     */   protected InputStream decorateInputStream(HttpExchange exchange, InputStream is)
/*     */     throws IOException
/*     */   {
/* 125 */     return is;
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpExchange exchange, RemoteInvocationResult result)
/*     */     throws IOException
/*     */   {
/* 137 */     exchange.getResponseHeaders().set("Content-Type", getContentType());
/* 138 */     exchange.sendResponseHeaders(200, 0L);
/* 139 */     writeRemoteInvocationResult(exchange, result, exchange.getResponseBody());
/*     */   }
/*     */ 
/*     */   protected void writeRemoteInvocationResult(HttpExchange exchange, RemoteInvocationResult result, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 159 */     ObjectOutputStream oos = createObjectOutputStream(decorateOutputStream(exchange, os));
/* 160 */     doWriteRemoteInvocationResult(result, oos);
/* 161 */     oos.flush();
/*     */   }
/*     */ 
/*     */   protected OutputStream decorateOutputStream(HttpExchange exchange, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 175 */     return os;
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.SimpleHttpInvokerServiceExporter
 * JD-Core Version:    0.6.1
 */