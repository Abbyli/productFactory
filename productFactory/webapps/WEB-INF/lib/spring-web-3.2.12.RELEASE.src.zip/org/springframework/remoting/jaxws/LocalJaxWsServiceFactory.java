/*     */ package org.springframework.remoting.jaxws;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.handler.HandlerResolver;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class LocalJaxWsServiceFactory
/*     */ {
/*     */   private URL wsdlDocumentUrl;
/*     */   private String namespaceUri;
/*     */   private String serviceName;
/*     */   private Executor executor;
/*     */   private HandlerResolver handlerResolver;
/*     */ 
/*     */   public void setWsdlDocumentUrl(URL wsdlDocumentUrl)
/*     */   {
/*  61 */     this.wsdlDocumentUrl = wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public void setWsdlDocumentResource(Resource wsdlDocumentResource)
/*     */     throws IOException
/*     */   {
/*  70 */     Assert.notNull(wsdlDocumentResource, "WSDL Resource must not be null.");
/*  71 */     this.wsdlDocumentUrl = wsdlDocumentResource.getURL();
/*     */   }
/*     */ 
/*     */   public URL getWsdlDocumentUrl()
/*     */   {
/*  78 */     return this.wsdlDocumentUrl;
/*     */   }
/*     */ 
/*     */   public void setNamespaceUri(String namespaceUri)
/*     */   {
/*  86 */     this.namespaceUri = (namespaceUri != null ? namespaceUri.trim() : null);
/*     */   }
/*     */ 
/*     */   public String getNamespaceUri()
/*     */   {
/*  93 */     return this.namespaceUri;
/*     */   }
/*     */ 
/*     */   public void setServiceName(String serviceName)
/*     */   {
/* 101 */     this.serviceName = serviceName;
/*     */   }
/*     */ 
/*     */   public String getServiceName()
/*     */   {
/* 108 */     return this.serviceName;
/*     */   }
/*     */ 
/*     */   public void setExecutor(Executor executor)
/*     */   {
/* 117 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */   public void setHandlerResolver(HandlerResolver handlerResolver)
/*     */   {
/* 126 */     this.handlerResolver = handlerResolver;
/*     */   }
/*     */ 
/*     */   public Service createJaxWsService()
/*     */   {
/* 136 */     Assert.notNull(this.serviceName, "No service name specified");
/* 137 */     Service service = this.wsdlDocumentUrl != null ? Service.create(this.wsdlDocumentUrl, getQName(this.serviceName)) : Service.create(getQName(this.serviceName));
/*     */ 
/* 141 */     if (this.executor != null) {
/* 142 */       service.setExecutor(this.executor);
/*     */     }
/* 144 */     if (this.handlerResolver != null) {
/* 145 */       service.setHandlerResolver(this.handlerResolver);
/*     */     }
/* 147 */     return service;
/*     */   }
/*     */ 
/*     */   protected QName getQName(String name)
/*     */   {
/* 156 */     return getNamespaceUri() != null ? new QName(getNamespaceUri(), name) : new QName(name);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.LocalJaxWsServiceFactory
 * JD-Core Version:    0.6.1
 */