/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class SimpleHttpInvokerRequestExecutor extends AbstractHttpInvokerRequestExecutor
/*     */ {
/*  48 */   private int connectTimeout = -1;
/*     */ 
/*  50 */   private int readTimeout = -1;
/*     */ 
/*     */   public void setConnectTimeout(int connectTimeout)
/*     */   {
/*  60 */     this.connectTimeout = connectTimeout;
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int readTimeout)
/*     */   {
/*  70 */     this.readTimeout = readTimeout;
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult doExecuteRequest(HttpInvokerClientConfiguration config, ByteArrayOutputStream baos)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/*  89 */     HttpURLConnection con = openConnection(config);
/*  90 */     prepareConnection(con, baos.size());
/*  91 */     writeRequestBody(config, con, baos);
/*  92 */     validateResponse(config, con);
/*  93 */     InputStream responseBody = readResponseBody(config, con);
/*     */ 
/*  95 */     return readRemoteInvocationResult(responseBody, config.getCodebaseUrl());
/*     */   }
/*     */ 
/*     */   protected HttpURLConnection openConnection(HttpInvokerClientConfiguration config)
/*     */     throws IOException
/*     */   {
/* 107 */     URLConnection con = new URL(config.getServiceUrl()).openConnection();
/* 108 */     if (!(con instanceof HttpURLConnection)) {
/* 109 */       throw new IOException("Service URL [" + config.getServiceUrl() + "] is not an HTTP URL");
/*     */     }
/* 111 */     return (HttpURLConnection)con;
/*     */   }
/*     */ 
/*     */   protected void prepareConnection(HttpURLConnection connection, int contentLength)
/*     */     throws IOException
/*     */   {
/* 126 */     if (this.connectTimeout >= 0) {
/* 127 */       connection.setConnectTimeout(this.connectTimeout);
/*     */     }
/* 129 */     if (this.readTimeout >= 0) {
/* 130 */       connection.setReadTimeout(this.readTimeout);
/*     */     }
/* 132 */     connection.setDoOutput(true);
/* 133 */     connection.setRequestMethod("POST");
/* 134 */     connection.setRequestProperty("Content-Type", getContentType());
/* 135 */     connection.setRequestProperty("Content-Length", Integer.toString(contentLength));
/* 136 */     LocaleContext locale = LocaleContextHolder.getLocaleContext();
/* 137 */     if (locale != null) {
/* 138 */       connection.setRequestProperty("Accept-Language", StringUtils.toLanguageTag(locale.getLocale()));
/*     */     }
/* 140 */     if (isAcceptGzipEncoding())
/* 141 */       connection.setRequestProperty("Accept-Encoding", "gzip");
/*     */   }
/*     */ 
/*     */   protected void writeRequestBody(HttpInvokerClientConfiguration config, HttpURLConnection con, ByteArrayOutputStream baos)
/*     */     throws IOException
/*     */   {
/* 162 */     baos.writeTo(con.getOutputStream());
/*     */   }
/*     */ 
/*     */   protected void validateResponse(HttpInvokerClientConfiguration config, HttpURLConnection con)
/*     */     throws IOException
/*     */   {
/* 178 */     if (con.getResponseCode() >= 300)
/* 179 */       throw new IOException("Did not receive successful HTTP response: status code = " + con.getResponseCode() + ", status message = [" + con.getResponseMessage() + "]");
/*     */   }
/*     */ 
/*     */   protected InputStream readResponseBody(HttpInvokerClientConfiguration config, HttpURLConnection con)
/*     */     throws IOException
/*     */   {
/* 204 */     if (isGzipResponse(con))
/*     */     {
/* 206 */       return new GZIPInputStream(con.getInputStream());
/*     */     }
/*     */ 
/* 210 */     return con.getInputStream();
/*     */   }
/*     */ 
/*     */   protected boolean isGzipResponse(HttpURLConnection con)
/*     */   {
/* 221 */     String encodingHeader = con.getHeaderField("Content-Encoding");
/* 222 */     return (encodingHeader != null) && (encodingHeader.toLowerCase().contains("gzip"));
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.SimpleHttpInvokerRequestExecutor
 * JD-Core Version:    0.6.1
 */