/*     */ package org.springframework.remoting.caucho;
/*     */ 
/*     */ import com.caucho.hessian.HessianException;
/*     */ import com.caucho.hessian.client.HessianConnectionException;
/*     */ import com.caucho.hessian.client.HessianProxyFactory;
/*     */ import com.caucho.hessian.client.HessianRuntimeException;
/*     */ import com.caucho.hessian.io.SerializerFactory;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.net.ConnectException;
/*     */ import java.net.MalformedURLException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.RemoteProxyFailureException;
/*     */ import org.springframework.remoting.support.UrlBasedRemoteAccessor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class HessianClientInterceptor extends UrlBasedRemoteAccessor
/*     */   implements MethodInterceptor
/*     */ {
/*  66 */   private HessianProxyFactory proxyFactory = new HessianProxyFactory();
/*     */   private Object hessianProxy;
/*     */ 
/*     */   public void setProxyFactory(HessianProxyFactory proxyFactory)
/*     */   {
/*  78 */     this.proxyFactory = (proxyFactory != null ? proxyFactory : new HessianProxyFactory());
/*     */   }
/*     */ 
/*     */   public void setSerializerFactory(SerializerFactory serializerFactory)
/*     */   {
/*  88 */     this.proxyFactory.setSerializerFactory(serializerFactory);
/*     */   }
/*     */ 
/*     */   public void setSendCollectionType(boolean sendCollectionType)
/*     */   {
/*  96 */     this.proxyFactory.getSerializerFactory().setSendCollectionType(sendCollectionType);
/*     */   }
/*     */ 
/*     */   public void setOverloadEnabled(boolean overloadEnabled)
/*     */   {
/* 105 */     this.proxyFactory.setOverloadEnabled(overloadEnabled);
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 115 */     this.proxyFactory.setUser(username);
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 125 */     this.proxyFactory.setPassword(password);
/*     */   }
/*     */ 
/*     */   public void setDebug(boolean debug)
/*     */   {
/* 134 */     this.proxyFactory.setDebug(debug);
/*     */   }
/*     */ 
/*     */   public void setChunkedPost(boolean chunkedPost)
/*     */   {
/* 142 */     this.proxyFactory.setChunkedPost(chunkedPost);
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(long timeout)
/*     */   {
/* 150 */     this.proxyFactory.setReadTimeout(timeout);
/*     */   }
/*     */ 
/*     */   public void setHessian2(boolean hessian2)
/*     */   {
/* 159 */     this.proxyFactory.setHessian2Request(hessian2);
/* 160 */     this.proxyFactory.setHessian2Reply(hessian2);
/*     */   }
/*     */ 
/*     */   public void setHessian2Request(boolean hessian2)
/*     */   {
/* 169 */     this.proxyFactory.setHessian2Request(hessian2);
/*     */   }
/*     */ 
/*     */   public void setHessian2Reply(boolean hessian2)
/*     */   {
/* 178 */     this.proxyFactory.setHessian2Reply(hessian2);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 184 */     super.afterPropertiesSet();
/* 185 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/*     */     try
/*     */     {
/* 194 */       this.hessianProxy = createHessianProxy(this.proxyFactory);
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 197 */       throw new RemoteLookupFailureException("Service URL [" + getServiceUrl() + "] is invalid", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object createHessianProxy(HessianProxyFactory proxyFactory)
/*     */     throws MalformedURLException
/*     */   {
/* 209 */     Assert.notNull(getServiceInterface(), "'serviceInterface' is required");
/* 210 */     return proxyFactory.create(getServiceInterface(), getServiceUrl());
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable
/*     */   {
/* 215 */     if (this.hessianProxy == null) {
/* 216 */       throw new IllegalStateException("HessianClientInterceptor is not properly initialized - invoke 'prepare' before attempting any operations");
/*     */     }
/*     */ 
/* 220 */     ClassLoader originalClassLoader = overrideThreadContextClassLoader();
/*     */     try {
/* 222 */       return invocation.getMethod().invoke(this.hessianProxy, invocation.getArguments());
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 225 */       Throwable targetEx = ex.getTargetException();
/*     */ 
/* 227 */       if ((targetEx instanceof InvocationTargetException)) {
/* 228 */         targetEx = ((InvocationTargetException)targetEx).getTargetException();
/*     */       }
/* 230 */       if ((targetEx instanceof HessianConnectionException)) {
/* 231 */         throw convertHessianAccessException(targetEx);
/*     */       }
/* 233 */       if (((targetEx instanceof HessianException)) || ((targetEx instanceof HessianRuntimeException))) {
/* 234 */         Throwable cause = targetEx.getCause();
/* 235 */         throw convertHessianAccessException(cause != null ? cause : targetEx);
/*     */       }
/* 237 */       if ((targetEx instanceof UndeclaredThrowableException)) {
/* 238 */         UndeclaredThrowableException utex = (UndeclaredThrowableException)targetEx;
/* 239 */         throw convertHessianAccessException(utex.getUndeclaredThrowable());
/*     */       }
/*     */ 
/* 242 */       throw targetEx;
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 246 */       throw new RemoteProxyFailureException("Failed to invoke Hessian proxy for remote service [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */     finally
/*     */     {
/* 250 */       resetThreadContextClassLoader(originalClassLoader);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RemoteAccessException convertHessianAccessException(Throwable ex)
/*     */   {
/* 261 */     if (((ex instanceof HessianConnectionException)) || ((ex instanceof ConnectException))) {
/* 262 */       return new RemoteConnectFailureException("Cannot connect to Hessian remote service at [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */ 
/* 266 */     return new RemoteAccessException("Cannot access Hessian remote service at [" + getServiceUrl() + "]", ex);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.HessianClientInterceptor
 * JD-Core Version:    0.6.1
 */