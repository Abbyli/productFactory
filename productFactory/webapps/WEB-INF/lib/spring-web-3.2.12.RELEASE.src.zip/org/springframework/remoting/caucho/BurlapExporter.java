/*    */ package org.springframework.remoting.caucho;
/*    */ 
/*    */ import com.caucho.burlap.io.BurlapInput;
/*    */ import com.caucho.burlap.io.BurlapOutput;
/*    */ import com.caucho.burlap.server.BurlapSkeleton;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.remoting.support.RemoteExporter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class BurlapExporter extends RemoteExporter
/*    */   implements InitializingBean
/*    */ {
/*    */   private BurlapSkeleton skeleton;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 51 */     prepare();
/*    */   }
/*    */ 
/*    */   public void prepare()
/*    */   {
/* 58 */     checkService();
/* 59 */     checkServiceInterface();
/* 60 */     this.skeleton = new BurlapSkeleton(getProxyForService(), getServiceInterface());
/*    */   }
/*    */ 
/*    */   public void invoke(InputStream inputStream, OutputStream outputStream)
/*    */     throws Throwable
/*    */   {
/* 71 */     Assert.notNull(this.skeleton, "Burlap exporter has not been initialized");
/* 72 */     ClassLoader originalClassLoader = overrideThreadContextClassLoader();
/*    */     try {
/* 74 */       this.skeleton.invoke(new BurlapInput(inputStream), new BurlapOutput(outputStream));
/*    */     }
/*    */     finally {
/*    */       try {
/* 78 */         inputStream.close();
/*    */       }
/*    */       catch (IOException ex)
/*    */       {
/*    */       }
/*    */       try {
/* 84 */         outputStream.close();
/*    */       }
/*    */       catch (IOException ex)
/*    */       {
/*    */       }
/* 89 */       resetThreadContextClassLoader(originalClassLoader);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.BurlapExporter
 * JD-Core Version:    0.6.1
 */