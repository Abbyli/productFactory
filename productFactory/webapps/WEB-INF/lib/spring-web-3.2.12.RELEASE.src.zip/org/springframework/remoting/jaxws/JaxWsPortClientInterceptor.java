/*     */ package org.springframework.remoting.jaxws;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.jws.WebService;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.BindingProvider;
/*     */ import javax.xml.ws.ProtocolException;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebServiceException;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ import javax.xml.ws.soap.SOAPFaultException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.RemoteProxyFailureException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class JaxWsPortClientInterceptor extends LocalJaxWsServiceFactory
/*     */   implements MethodInterceptor, BeanClassLoaderAware, InitializingBean
/*     */ {
/*     */   private Service jaxWsService;
/*     */   private String portName;
/*     */   private String username;
/*     */   private String password;
/*     */   private String endpointAddress;
/*     */   private boolean maintainSession;
/*     */   private boolean useSoapAction;
/*     */   private String soapActionUri;
/*     */   private Map<String, Object> customProperties;
/*     */   private Object[] webServiceFeatures;
/*     */   private Class<?> serviceInterface;
/*     */   private boolean lookupServiceOnStartup;
/*     */   private ClassLoader beanClassLoader;
/*     */   private QName portQName;
/*     */   private Object portStub;
/*     */   private final Object preparationMonitor;
/*     */ 
/*     */   public JaxWsPortClientInterceptor()
/*     */   {
/*  90 */     this.lookupServiceOnStartup = true;
/*     */ 
/*  92 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*  98 */     this.preparationMonitor = new Object();
/*     */   }
/*     */ 
/*     */   public void setJaxWsService(Service jaxWsService)
/*     */   {
/* 111 */     this.jaxWsService = jaxWsService;
/*     */   }
/*     */ 
/*     */   public Service getJaxWsService()
/*     */   {
/* 118 */     return this.jaxWsService;
/*     */   }
/*     */ 
/*     */   public void setPortName(String portName)
/*     */   {
/* 126 */     this.portName = portName;
/*     */   }
/*     */ 
/*     */   public String getPortName()
/*     */   {
/* 133 */     return this.portName;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 141 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 148 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 156 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 163 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setEndpointAddress(String endpointAddress)
/*     */   {
/* 171 */     this.endpointAddress = endpointAddress;
/*     */   }
/*     */ 
/*     */   public String getEndpointAddress()
/*     */   {
/* 178 */     return this.endpointAddress;
/*     */   }
/*     */ 
/*     */   public void setMaintainSession(boolean maintainSession)
/*     */   {
/* 186 */     this.maintainSession = maintainSession;
/*     */   }
/*     */ 
/*     */   public boolean isMaintainSession()
/*     */   {
/* 193 */     return this.maintainSession;
/*     */   }
/*     */ 
/*     */   public void setUseSoapAction(boolean useSoapAction)
/*     */   {
/* 201 */     this.useSoapAction = useSoapAction;
/*     */   }
/*     */ 
/*     */   public boolean isUseSoapAction()
/*     */   {
/* 208 */     return this.useSoapAction;
/*     */   }
/*     */ 
/*     */   public void setSoapActionUri(String soapActionUri)
/*     */   {
/* 216 */     this.soapActionUri = soapActionUri;
/*     */   }
/*     */ 
/*     */   public String getSoapActionUri()
/*     */   {
/* 223 */     return this.soapActionUri;
/*     */   }
/*     */ 
/*     */   public void setCustomProperties(Map<String, Object> customProperties)
/*     */   {
/* 233 */     this.customProperties = customProperties;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getCustomProperties()
/*     */   {
/* 244 */     if (this.customProperties == null) {
/* 245 */       this.customProperties = new HashMap();
/*     */     }
/* 247 */     return this.customProperties;
/*     */   }
/*     */ 
/*     */   public void addCustomProperty(String name, Object value)
/*     */   {
/* 257 */     getCustomProperties().put(name, value);
/*     */   }
/*     */ 
/*     */   public void setWebServiceFeatures(Object[] webServiceFeatures)
/*     */   {
/* 266 */     this.webServiceFeatures = webServiceFeatures;
/*     */   }
/*     */ 
/*     */   public void setServiceInterface(Class<?> serviceInterface)
/*     */   {
/* 273 */     if ((serviceInterface != null) && (!serviceInterface.isInterface())) {
/* 274 */       throw new IllegalArgumentException("'serviceInterface' must be an interface");
/*     */     }
/* 276 */     this.serviceInterface = serviceInterface;
/*     */   }
/*     */ 
/*     */   public Class<?> getServiceInterface()
/*     */   {
/* 283 */     return this.serviceInterface;
/*     */   }
/*     */ 
/*     */   public void setLookupServiceOnStartup(boolean lookupServiceOnStartup)
/*     */   {
/* 293 */     this.lookupServiceOnStartup = lookupServiceOnStartup;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 303 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   protected ClassLoader getBeanClassLoader()
/*     */   {
/* 310 */     return this.beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 315 */     if (this.lookupServiceOnStartup)
/* 316 */       prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 324 */     Class ifc = getServiceInterface();
/* 325 */     if (ifc == null) {
/* 326 */       throw new IllegalArgumentException("Property 'serviceInterface' is required");
/*     */     }
/* 328 */     WebService ann = (WebService)ifc.getAnnotation(WebService.class);
/* 329 */     if (ann != null) {
/* 330 */       applyDefaultsFromAnnotation(ann);
/*     */     }
/* 332 */     Service serviceToUse = getJaxWsService();
/* 333 */     if (serviceToUse == null) {
/* 334 */       serviceToUse = createJaxWsService();
/*     */     }
/* 336 */     this.portQName = getQName(getPortName() != null ? getPortName() : getServiceInterface().getName());
/* 337 */     Object stub = getPortStub(serviceToUse, getPortName() != null ? this.portQName : null);
/* 338 */     preparePortStub(stub);
/* 339 */     this.portStub = stub;
/*     */   }
/*     */ 
/*     */   protected void applyDefaultsFromAnnotation(WebService ann)
/*     */   {
/* 350 */     if (getWsdlDocumentUrl() == null) {
/* 351 */       String wsdl = ann.wsdlLocation();
/* 352 */       if (StringUtils.hasText(wsdl)) {
/*     */         try {
/* 354 */           setWsdlDocumentUrl(new URL(wsdl));
/*     */         }
/*     */         catch (MalformedURLException ex) {
/* 357 */           throw new IllegalStateException("Encountered invalid @Service wsdlLocation value [" + wsdl + "]", ex);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 362 */     if (getNamespaceUri() == null) {
/* 363 */       String ns = ann.targetNamespace();
/* 364 */       if (StringUtils.hasText(ns)) {
/* 365 */         setNamespaceUri(ns);
/*     */       }
/*     */     }
/* 368 */     if (getServiceName() == null) {
/* 369 */       String sn = ann.serviceName();
/* 370 */       if (StringUtils.hasText(sn)) {
/* 371 */         setServiceName(sn);
/*     */       }
/*     */     }
/* 374 */     if (getPortName() == null) {
/* 375 */       String pn = ann.portName();
/* 376 */       if (StringUtils.hasText(pn))
/* 377 */         setPortName(pn);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isPrepared()
/*     */   {
/* 387 */     synchronized (this.preparationMonitor) {
/* 388 */       return this.portStub != null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final QName getPortQName()
/*     */   {
/* 398 */     return this.portQName;
/*     */   }
/*     */ 
/*     */   protected Object getPortStub(Service service, QName portQName)
/*     */   {
/* 409 */     if (this.webServiceFeatures != null) {
/*     */       try {
/* 411 */         return new FeaturePortProvider(null).getPortStub(service, portQName, this.webServiceFeatures);
/*     */       }
/*     */       catch (LinkageError ex) {
/* 414 */         throw new IllegalStateException("Specifying the 'webServiceFeatures' property requires JAX-WS 2.1 or higher at runtime", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 419 */     return portQName != null ? service.getPort(portQName, getServiceInterface()) : service.getPort(getServiceInterface());
/*     */   }
/*     */ 
/*     */   protected void preparePortStub(Object stub)
/*     */   {
/* 435 */     Map stubProperties = new HashMap();
/* 436 */     String username = getUsername();
/* 437 */     if (username != null) {
/* 438 */       stubProperties.put("javax.xml.ws.security.auth.username", username);
/*     */     }
/* 440 */     String password = getPassword();
/* 441 */     if (password != null) {
/* 442 */       stubProperties.put("javax.xml.ws.security.auth.password", password);
/*     */     }
/* 444 */     String endpointAddress = getEndpointAddress();
/* 445 */     if (endpointAddress != null) {
/* 446 */       stubProperties.put("javax.xml.ws.service.endpoint.address", endpointAddress);
/*     */     }
/* 448 */     if (isMaintainSession()) {
/* 449 */       stubProperties.put("javax.xml.ws.session.maintain", Boolean.TRUE);
/*     */     }
/* 451 */     if (isUseSoapAction()) {
/* 452 */       stubProperties.put("javax.xml.ws.soap.http.soapaction.use", Boolean.TRUE);
/*     */     }
/* 454 */     String soapActionUri = getSoapActionUri();
/* 455 */     if (soapActionUri != null) {
/* 456 */       stubProperties.put("javax.xml.ws.soap.http.soapaction.uri", soapActionUri);
/*     */     }
/* 458 */     stubProperties.putAll(getCustomProperties());
/* 459 */     if (!stubProperties.isEmpty()) {
/* 460 */       if (!(stub instanceof BindingProvider)) {
/* 461 */         throw new RemoteLookupFailureException("Port stub of class [" + stub.getClass().getName() + "] is not a customizable JAX-WS stub: it does not implement interface [javax.xml.ws.BindingProvider]");
/*     */       }
/*     */ 
/* 464 */       ((BindingProvider)stub).getRequestContext().putAll(stubProperties);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object getPortStub()
/*     */   {
/* 473 */     return this.portStub;
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable
/*     */   {
/* 478 */     if (AopUtils.isToStringMethod(invocation.getMethod())) {
/* 479 */       return "JAX-WS proxy for port [" + getPortName() + "] of service [" + getServiceName() + "]";
/*     */     }
/*     */ 
/* 482 */     synchronized (this.preparationMonitor) {
/* 483 */       if (!isPrepared()) {
/* 484 */         prepare();
/*     */       }
/*     */     }
/* 487 */     return doInvoke(invocation);
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 500 */       return doInvoke(invocation, getPortStub());
/*     */     }
/*     */     catch (SOAPFaultException ex) {
/* 503 */       throw new JaxWsSoapFaultException(ex);
/*     */     }
/*     */     catch (ProtocolException ex) {
/* 506 */       throw new RemoteConnectFailureException("Could not connect to remote service [" + getEndpointAddress() + "]", ex);
/*     */     }
/*     */     catch (WebServiceException ex)
/*     */     {
/* 510 */       throw new RemoteAccessException("Could not access remote service at [" + getEndpointAddress() + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation, Object portStub)
/*     */     throws Throwable
/*     */   {
/* 524 */     Method method = invocation.getMethod();
/*     */     try {
/* 526 */       return method.invoke(portStub, invocation.getArguments());
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 529 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (Throwable ex) {
/* 532 */       throw new RemoteProxyFailureException("Invocation of stub method failed: " + method, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class FeaturePortProvider
/*     */   {
/*     */     private FeaturePortProvider()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Object getPortStub(Service service, QName portQName, Object[] features)
/*     */     {
/* 544 */       WebServiceFeature[] wsFeatures = new WebServiceFeature[features.length];
/* 545 */       for (int i = 0; i < features.length; i++) {
/* 546 */         wsFeatures[i] = convertWebServiceFeature(features[i]);
/*     */       }
/* 548 */       return portQName != null ? service.getPort(portQName, JaxWsPortClientInterceptor.this.getServiceInterface(), wsFeatures) : service.getPort(JaxWsPortClientInterceptor.this.getServiceInterface(), wsFeatures);
/*     */     }
/*     */ 
/*     */     private WebServiceFeature convertWebServiceFeature(Object feature)
/*     */     {
/* 553 */       Assert.notNull(feature, "WebServiceFeature specification object must not be null");
/* 554 */       if ((feature instanceof WebServiceFeature)) {
/* 555 */         return (WebServiceFeature)feature;
/*     */       }
/* 557 */       if ((feature instanceof Class)) {
/* 558 */         return (WebServiceFeature)BeanUtils.instantiate((Class)feature);
/*     */       }
/* 560 */       if ((feature instanceof String)) {
/*     */         try {
/* 562 */           Class featureClass = JaxWsPortClientInterceptor.this.getBeanClassLoader().loadClass((String)feature);
/* 563 */           return (WebServiceFeature)BeanUtils.instantiate(featureClass);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 566 */           throw new IllegalArgumentException("Could not load WebServiceFeature class [" + feature + "]");
/*     */         }
/*     */       }
/*     */ 
/* 570 */       throw new IllegalArgumentException("Unknown WebServiceFeature specification type: " + feature.getClass());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.JaxWsPortClientInterceptor
 * JD-Core Version:    0.6.1
 */