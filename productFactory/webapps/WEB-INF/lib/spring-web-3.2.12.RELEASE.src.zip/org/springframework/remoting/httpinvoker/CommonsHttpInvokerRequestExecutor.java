/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import org.apache.commons.httpclient.Header;
/*     */ import org.apache.commons.httpclient.HttpClient;
/*     */ import org.apache.commons.httpclient.HttpConnectionManager;
/*     */ import org.apache.commons.httpclient.HttpException;
/*     */ import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
/*     */ import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
/*     */ import org.apache.commons.httpclient.methods.PostMethod;
/*     */ import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
/*     */ import org.springframework.context.i18n.LocaleContext;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CommonsHttpInvokerRequestExecutor extends AbstractHttpInvokerRequestExecutor
/*     */ {
/*     */   private static final int DEFAULT_READ_TIMEOUT_MILLISECONDS = 60000;
/*     */   private HttpClient httpClient;
/*     */ 
/*     */   public CommonsHttpInvokerRequestExecutor()
/*     */   {
/*  69 */     this.httpClient = new HttpClient(new MultiThreadedHttpConnectionManager());
/*  70 */     setReadTimeout(60000);
/*     */   }
/*     */ 
/*     */   public CommonsHttpInvokerRequestExecutor(HttpClient httpClient)
/*     */   {
/*  80 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public void setHttpClient(HttpClient httpClient)
/*     */   {
/*  88 */     this.httpClient = httpClient;
/*     */   }
/*     */ 
/*     */   public HttpClient getHttpClient()
/*     */   {
/*  95 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */   public void setConnectTimeout(int timeout)
/*     */   {
/* 105 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 106 */     this.httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(timeout);
/*     */   }
/*     */ 
/*     */   public void setReadTimeout(int timeout)
/*     */   {
/* 117 */     Assert.isTrue(timeout >= 0, "Timeout must be a non-negative value");
/* 118 */     this.httpClient.getHttpConnectionManager().getParams().setSoTimeout(timeout);
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult doExecuteRequest(HttpInvokerClientConfiguration config, ByteArrayOutputStream baos)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 137 */     PostMethod postMethod = createPostMethod(config);
/*     */     try {
/* 139 */       setRequestBody(config, postMethod, baos);
/* 140 */       executePostMethod(config, getHttpClient(), postMethod);
/* 141 */       validateResponse(config, postMethod);
/* 142 */       InputStream responseBody = getResponseBody(config, postMethod);
/* 143 */       return readRemoteInvocationResult(responseBody, config.getCodebaseUrl());
/*     */     }
/*     */     finally
/*     */     {
/* 147 */       postMethod.releaseConnection();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected PostMethod createPostMethod(HttpInvokerClientConfiguration config)
/*     */     throws IOException
/*     */   {
/* 161 */     PostMethod postMethod = new PostMethod(config.getServiceUrl());
/* 162 */     LocaleContext locale = LocaleContextHolder.getLocaleContext();
/* 163 */     if (locale != null) {
/* 164 */       postMethod.addRequestHeader("Accept-Language", StringUtils.toLanguageTag(locale.getLocale()));
/*     */     }
/* 166 */     if (isAcceptGzipEncoding()) {
/* 167 */       postMethod.addRequestHeader("Accept-Encoding", "gzip");
/*     */     }
/* 169 */     return postMethod;
/*     */   }
/*     */ 
/*     */   protected void setRequestBody(HttpInvokerClientConfiguration config, PostMethod postMethod, ByteArrayOutputStream baos)
/*     */     throws IOException
/*     */   {
/* 190 */     postMethod.setRequestEntity(new ByteArrayRequestEntity(baos.toByteArray(), getContentType()));
/*     */   }
/*     */ 
/*     */   protected void executePostMethod(HttpInvokerClientConfiguration config, HttpClient httpClient, PostMethod postMethod)
/*     */     throws IOException
/*     */   {
/* 205 */     httpClient.executeMethod(postMethod);
/*     */   }
/*     */ 
/*     */   protected void validateResponse(HttpInvokerClientConfiguration config, PostMethod postMethod)
/*     */     throws IOException
/*     */   {
/* 222 */     if (postMethod.getStatusCode() >= 300)
/* 223 */       throw new HttpException("Did not receive successful HTTP response: status code = " + postMethod.getStatusCode() + ", status message = [" + postMethod.getStatusText() + "]");
/*     */   }
/*     */ 
/*     */   protected InputStream getResponseBody(HttpInvokerClientConfiguration config, PostMethod postMethod)
/*     */     throws IOException
/*     */   {
/* 246 */     if (isGzipResponse(postMethod)) {
/* 247 */       return new GZIPInputStream(postMethod.getResponseBodyAsStream());
/*     */     }
/*     */ 
/* 250 */     return postMethod.getResponseBodyAsStream();
/*     */   }
/*     */ 
/*     */   protected boolean isGzipResponse(PostMethod postMethod)
/*     */   {
/* 262 */     Header encodingHeader = postMethod.getResponseHeader("Content-Encoding");
/* 263 */     return (encodingHeader != null) && (encodingHeader.getValue() != null) && (encodingHeader.getValue().toLowerCase().contains("gzip"));
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.CommonsHttpInvokerRequestExecutor
 * JD-Core Version:    0.6.1
 */