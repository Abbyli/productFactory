package org.springframework.remoting.httpinvoker;

public abstract interface HttpInvokerClientConfiguration
{
  public abstract String getServiceUrl();

  public abstract String getCodebaseUrl();
}

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerClientConfiguration
 * JD-Core Version:    0.6.1
 */