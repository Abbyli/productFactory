/*    */ package org.springframework.remoting.jaxrpc;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.soap.SOAPFaultException;
/*    */ import org.springframework.remoting.soap.SoapFaultException;
/*    */ 
/*    */ @Deprecated
/*    */ public class JaxRpcSoapFaultException extends SoapFaultException
/*    */ {
/*    */   public JaxRpcSoapFaultException(SOAPFaultException original)
/*    */   {
/* 41 */     super(original.getMessage(), original);
/*    */   }
/*    */ 
/*    */   public final SOAPFaultException getOriginalException()
/*    */   {
/* 48 */     return (SOAPFaultException)getCause();
/*    */   }
/*    */ 
/*    */   public String getFaultCode()
/*    */   {
/* 54 */     return getOriginalException().getFaultCode().toString();
/*    */   }
/*    */ 
/*    */   public QName getFaultCodeAsQName()
/*    */   {
/* 59 */     return getOriginalException().getFaultCode();
/*    */   }
/*    */ 
/*    */   public String getFaultString()
/*    */   {
/* 64 */     return getOriginalException().getFaultString();
/*    */   }
/*    */ 
/*    */   public String getFaultActor()
/*    */   {
/* 69 */     return getOriginalException().getFaultActor();
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxrpc.JaxRpcSoapFaultException
 * JD-Core Version:    0.6.1
 */