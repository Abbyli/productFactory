/*     */ package org.springframework.remoting.jaxrpc;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.Call;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.Service;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import javax.xml.rpc.Stub;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.RemoteProxyFailureException;
/*     */ import org.springframework.remoting.rmi.RmiClientInterceptorUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class JaxRpcPortClientInterceptor extends LocalJaxRpcServiceFactory
/*     */   implements MethodInterceptor, InitializingBean
/*     */ {
/*     */   private Service jaxRpcService;
/*     */   private Service serviceToUse;
/*     */   private String portName;
/*     */   private String username;
/*     */   private String password;
/*     */   private String endpointAddress;
/*     */   private boolean maintainSession;
/*  97 */   private final Map<String, Object> customPropertyMap = new HashMap();
/*     */   private Class serviceInterface;
/*     */   private Class portInterface;
/* 103 */   private boolean lookupServiceOnStartup = true;
/*     */ 
/* 105 */   private boolean refreshServiceAfterConnectFailure = false;
/*     */   private QName portQName;
/*     */   private Remote portStub;
/* 111 */   private final Object preparationMonitor = new Object();
/*     */ 
/*     */   public void setJaxRpcService(Service jaxRpcService)
/*     */   {
/* 125 */     this.jaxRpcService = jaxRpcService;
/*     */   }
/*     */ 
/*     */   public Service getJaxRpcService()
/*     */   {
/* 132 */     return this.jaxRpcService;
/*     */   }
/*     */ 
/*     */   public void setPortName(String portName)
/*     */   {
/* 140 */     this.portName = portName;
/*     */   }
/*     */ 
/*     */   public String getPortName()
/*     */   {
/* 147 */     return this.portName;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 156 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 163 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 172 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 179 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setEndpointAddress(String endpointAddress)
/*     */   {
/* 188 */     this.endpointAddress = endpointAddress;
/*     */   }
/*     */ 
/*     */   public String getEndpointAddress()
/*     */   {
/* 195 */     return this.endpointAddress;
/*     */   }
/*     */ 
/*     */   public void setMaintainSession(boolean maintainSession)
/*     */   {
/* 204 */     this.maintainSession = maintainSession;
/*     */   }
/*     */ 
/*     */   public boolean isMaintainSession()
/*     */   {
/* 211 */     return this.maintainSession;
/*     */   }
/*     */ 
/*     */   public void setCustomProperties(Properties customProperties)
/*     */   {
/* 222 */     CollectionUtils.mergePropertiesIntoMap(customProperties, this.customPropertyMap);
/*     */   }
/*     */ 
/*     */   public void setCustomPropertyMap(Map<String, Object> customProperties)
/*     */   {
/* 232 */     if (customProperties != null)
/* 233 */       for (Map.Entry entry : customProperties.entrySet())
/* 234 */         addCustomProperty((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getCustomPropertyMap()
/*     */   {
/* 247 */     return this.customPropertyMap;
/*     */   }
/*     */ 
/*     */   public void addCustomProperty(String name, Object value)
/*     */   {
/* 258 */     this.customPropertyMap.put(name, value);
/*     */   }
/*     */ 
/*     */   public void setServiceInterface(Class serviceInterface)
/*     */   {
/* 277 */     if ((serviceInterface != null) && (!serviceInterface.isInterface())) {
/* 278 */       throw new IllegalArgumentException("'serviceInterface' must be an interface");
/*     */     }
/* 280 */     this.serviceInterface = serviceInterface;
/*     */   }
/*     */ 
/*     */   public Class getServiceInterface()
/*     */   {
/* 287 */     return this.serviceInterface;
/*     */   }
/*     */ 
/*     */   public void setPortInterface(Class portInterface)
/*     */   {
/* 305 */     if ((portInterface != null) && ((!portInterface.isInterface()) || (!Remote.class.isAssignableFrom(portInterface))))
/*     */     {
/* 307 */       throw new IllegalArgumentException("'portInterface' must be an interface derived from [java.rmi.Remote]");
/*     */     }
/*     */ 
/* 310 */     this.portInterface = portInterface;
/*     */   }
/*     */ 
/*     */   public Class getPortInterface()
/*     */   {
/* 317 */     return this.portInterface;
/*     */   }
/*     */ 
/*     */   public void setLookupServiceOnStartup(boolean lookupServiceOnStartup)
/*     */   {
/* 327 */     this.lookupServiceOnStartup = lookupServiceOnStartup;
/*     */   }
/*     */ 
/*     */   public void setRefreshServiceAfterConnectFailure(boolean refreshServiceAfterConnectFailure)
/*     */   {
/* 339 */     this.refreshServiceAfterConnectFailure = refreshServiceAfterConnectFailure;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 348 */     if (this.lookupServiceOnStartup)
/* 349 */       prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/* 364 */     if (getPortName() == null) {
/* 365 */       throw new IllegalArgumentException("Property 'portName' is required");
/*     */     }
/*     */ 
/* 368 */     synchronized (this.preparationMonitor) {
/* 369 */       this.serviceToUse = null;
/*     */ 
/* 372 */       this.portQName = getQName(getPortName());
/*     */       try
/*     */       {
/* 375 */         Service service = getJaxRpcService();
/* 376 */         if (service == null) {
/* 377 */           service = createJaxRpcService();
/*     */         }
/*     */         else {
/* 380 */           postProcessJaxRpcService(service);
/*     */         }
/*     */ 
/* 383 */         Class portInterface = getPortInterface();
/* 384 */         if ((portInterface != null) && (!alwaysUseJaxRpcCall()))
/*     */         {
/* 387 */           if (this.logger.isDebugEnabled()) {
/* 388 */             this.logger.debug("Creating JAX-RPC proxy for JAX-RPC port [" + this.portQName + "], using port interface [" + portInterface.getName() + "]");
/*     */           }
/*     */ 
/* 391 */           Remote remoteObj = service.getPort(this.portQName, portInterface);
/*     */ 
/* 393 */           if (this.logger.isDebugEnabled()) {
/* 394 */             Class serviceInterface = getServiceInterface();
/* 395 */             if (serviceInterface != null) {
/* 396 */               boolean isImpl = serviceInterface.isInstance(remoteObj);
/* 397 */               this.logger.debug("Using service interface [" + serviceInterface.getName() + "] for JAX-RPC port [" + this.portQName + "] - " + (!isImpl ? "not" : "") + " directly implemented");
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 402 */           if (!(remoteObj instanceof Stub)) {
/* 403 */             throw new RemoteLookupFailureException("Port stub of class [" + remoteObj.getClass().getName() + "] is not a valid JAX-RPC stub: it does not implement interface [javax.xml.rpc.Stub]");
/*     */           }
/*     */ 
/* 406 */           Stub stub = (Stub)remoteObj;
/*     */ 
/* 409 */           preparePortStub(stub);
/*     */ 
/* 412 */           postProcessPortStub(stub);
/*     */ 
/* 414 */           this.portStub = remoteObj;
/*     */         }
/* 419 */         else if (this.logger.isDebugEnabled()) {
/* 420 */           this.logger.debug("Using JAX-RPC dynamic calls for JAX-RPC port [" + this.portQName + "]");
/*     */         }
/*     */ 
/* 424 */         this.serviceToUse = service;
/*     */       }
/*     */       catch (ServiceException ex) {
/* 427 */         throw new RemoteLookupFailureException("Failed to initialize service for JAX-RPC port [" + this.portQName + "]", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean alwaysUseJaxRpcCall()
/*     */   {
/* 446 */     return false;
/*     */   }
/*     */ 
/*     */   protected void reset()
/*     */   {
/* 454 */     synchronized (this.preparationMonitor) {
/* 455 */       this.serviceToUse = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isPrepared()
/*     */   {
/* 464 */     synchronized (this.preparationMonitor) {
/* 465 */       return this.serviceToUse != null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final QName getPortQName()
/*     */   {
/* 475 */     return this.portQName;
/*     */   }
/*     */ 
/*     */   protected void preparePortStub(Stub stub)
/*     */   {
/* 494 */     String username = getUsername();
/* 495 */     if (username != null) {
/* 496 */       stub._setProperty("javax.xml.rpc.security.auth.username", username);
/*     */     }
/* 498 */     String password = getPassword();
/* 499 */     if (password != null) {
/* 500 */       stub._setProperty("javax.xml.rpc.security.auth.password", password);
/*     */     }
/* 502 */     String endpointAddress = getEndpointAddress();
/* 503 */     if (endpointAddress != null) {
/* 504 */       stub._setProperty("javax.xml.rpc.service.endpoint.address", endpointAddress);
/*     */     }
/* 506 */     if (isMaintainSession()) {
/* 507 */       stub._setProperty("javax.xml.rpc.session.maintain", Boolean.TRUE);
/*     */     }
/* 509 */     if (this.customPropertyMap != null)
/* 510 */       for (Map.Entry entry : this.customPropertyMap.entrySet())
/* 511 */         stub._setProperty((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   protected void postProcessPortStub(Stub stub)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Remote getPortStub()
/*     */   {
/* 534 */     return this.portStub;
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 546 */     if (AopUtils.isToStringMethod(invocation.getMethod())) {
/* 547 */       return "JAX-RPC proxy for port [" + getPortName() + "] of service [" + getServiceName() + "]";
/*     */     }
/*     */ 
/* 550 */     synchronized (this.preparationMonitor) {
/* 551 */       if (!isPrepared()) {
/* 552 */         prepare();
/*     */       }
/*     */     }
/* 555 */     return doInvoke(invocation);
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 570 */     Remote stub = getPortStub();
/*     */     try {
/* 572 */       if (stub != null)
/*     */       {
/* 574 */         if (this.logger.isTraceEnabled()) {
/* 575 */           this.logger.trace("Invoking operation '" + invocation.getMethod().getName() + "' on JAX-RPC port stub");
/*     */         }
/* 577 */         return doInvoke(invocation, stub);
/*     */       }
/*     */ 
/* 581 */       if (this.logger.isTraceEnabled()) {
/* 582 */         this.logger.trace("Invoking operation '" + invocation.getMethod().getName() + "' as JAX-RPC dynamic call");
/*     */       }
/* 584 */       return performJaxRpcCall(invocation, this.serviceToUse);
/*     */     }
/*     */     catch (RemoteException ex)
/*     */     {
/* 588 */       throw handleRemoteException(invocation.getMethod(), ex);
/*     */     }
/*     */     catch (SOAPFaultException ex) {
/* 591 */       throw new JaxRpcSoapFaultException(ex);
/*     */     }
/*     */     catch (JAXRPCException ex) {
/* 594 */       throw new RemoteProxyFailureException("Invalid JAX-RPC call configuration", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation, Remote portStub)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/* 610 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, portStub);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 613 */       throw ex.getTargetException();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object performJaxRpcCall(MethodInvocation invocation, Service service)
/*     */     throws Throwable
/*     */   {
/* 633 */     Method method = invocation.getMethod();
/* 634 */     QName portQName = this.portQName;
/*     */ 
/* 638 */     Call call = null;
/* 639 */     synchronized (service) {
/* 640 */       call = service.createCall(portQName, method.getName());
/*     */     }
/*     */ 
/* 644 */     prepareJaxRpcCall(call);
/*     */ 
/* 647 */     postProcessJaxRpcCall(call, invocation);
/*     */ 
/* 650 */     return call.invoke(invocation.getArguments());
/*     */   }
/*     */ 
/*     */   protected void prepareJaxRpcCall(Call call)
/*     */   {
/* 667 */     String username = getUsername();
/* 668 */     if (username != null) {
/* 669 */       call.setProperty("javax.xml.rpc.security.auth.username", username);
/*     */     }
/* 671 */     String password = getPassword();
/* 672 */     if (password != null) {
/* 673 */       call.setProperty("javax.xml.rpc.security.auth.password", password);
/*     */     }
/* 675 */     String endpointAddress = getEndpointAddress();
/* 676 */     if (endpointAddress != null) {
/* 677 */       call.setTargetEndpointAddress(endpointAddress);
/*     */     }
/* 679 */     if (isMaintainSession()) {
/* 680 */       call.setProperty("javax.xml.rpc.session.maintain", Boolean.TRUE);
/*     */     }
/* 682 */     if (this.customPropertyMap != null)
/* 683 */       for (Map.Entry entry : this.customPropertyMap.entrySet())
/* 684 */         call.setProperty((String)entry.getKey(), entry.getValue());
/*     */   }
/*     */ 
/*     */   protected void postProcessJaxRpcCall(Call call, MethodInvocation invocation)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Throwable handleRemoteException(Method method, RemoteException ex)
/*     */   {
/* 714 */     boolean isConnectFailure = isConnectFailure(ex);
/* 715 */     if ((isConnectFailure) && (this.refreshServiceAfterConnectFailure)) {
/* 716 */       reset();
/*     */     }
/* 718 */     Throwable cause = ex.getCause();
/* 719 */     if ((cause != null) && (ReflectionUtils.declaresException(method, cause.getClass()))) {
/* 720 */       if (this.logger.isDebugEnabled()) {
/* 721 */         this.logger.debug("Rethrowing wrapped exception of type [" + cause.getClass().getName() + "] as-is");
/*     */       }
/*     */ 
/* 724 */       return ex.getCause();
/*     */     }
/*     */ 
/* 729 */     return RmiClientInterceptorUtils.convertRmiAccessException(method, ex, isConnectFailure, this.portQName.toString());
/*     */   }
/*     */ 
/*     */   protected boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 745 */     return (!ex.getClass().getName().contains("Fault")) && (!ex.getClass().getSuperclass().getName().contains("Fault"));
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxrpc.JaxRpcPortClientInterceptor
 * JD-Core Version:    0.6.1
 */