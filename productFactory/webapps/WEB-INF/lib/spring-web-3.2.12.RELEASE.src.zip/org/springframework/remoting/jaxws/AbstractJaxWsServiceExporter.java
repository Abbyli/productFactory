/*     */ package org.springframework.remoting.jaxws;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.jws.WebService;
/*     */ import javax.xml.ws.Endpoint;
/*     */ import javax.xml.ws.WebServiceFeature;
/*     */ import javax.xml.ws.WebServiceProvider;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class AbstractJaxWsServiceExporter
/*     */   implements BeanFactoryAware, InitializingBean, DisposableBean
/*     */ {
/*     */   private Map<String, Object> endpointProperties;
/*     */   private Executor executor;
/*     */   private String bindingType;
/*     */   private Object[] webServiceFeatures;
/*     */   private ListableBeanFactory beanFactory;
/*     */   private final Set<Endpoint> publishedEndpoints;
/*     */ 
/*     */   public AbstractJaxWsServiceExporter()
/*     */   {
/*  69 */     this.publishedEndpoints = new LinkedHashSet();
/*     */   }
/*     */ 
/*     */   public void setEndpointProperties(Map<String, Object> endpointProperties)
/*     */   {
/*  80 */     this.endpointProperties = endpointProperties;
/*     */   }
/*     */ 
/*     */   public void setExecutor(Executor executor)
/*     */   {
/*  89 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */   public void setBindingType(String bindingType)
/*     */   {
/*  97 */     this.bindingType = bindingType;
/*     */   }
/*     */ 
/*     */   public void setWebServiceFeatures(Object[] webServiceFeatures)
/*     */   {
/* 106 */     this.webServiceFeatures = webServiceFeatures;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 113 */     if (!(beanFactory instanceof ListableBeanFactory)) {
/* 114 */       throw new IllegalStateException(getClass().getSimpleName() + " requires a ListableBeanFactory");
/*     */     }
/* 116 */     this.beanFactory = ((ListableBeanFactory)beanFactory);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 125 */     publishEndpoints();
/*     */   }
/*     */ 
/*     */   public void publishEndpoints()
/*     */   {
/* 134 */     Set beanNames = new LinkedHashSet(this.beanFactory.getBeanDefinitionCount());
/* 135 */     beanNames.addAll(Arrays.asList(this.beanFactory.getBeanDefinitionNames()));
/* 136 */     if ((this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 137 */       beanNames.addAll(Arrays.asList(((ConfigurableBeanFactory)this.beanFactory).getSingletonNames()));
/*     */     }
/* 139 */     for (String beanName : beanNames)
/*     */       try {
/* 141 */         Class type = this.beanFactory.getType(beanName);
/* 142 */         if ((type != null) && (!type.isInterface())) {
/* 143 */           WebService wsAnnotation = (WebService)type.getAnnotation(WebService.class);
/* 144 */           WebServiceProvider wsProviderAnnotation = (WebServiceProvider)type.getAnnotation(WebServiceProvider.class);
/* 145 */           if ((wsAnnotation != null) || (wsProviderAnnotation != null)) {
/* 146 */             Endpoint endpoint = createEndpoint(this.beanFactory.getBean(beanName));
/* 147 */             if (this.endpointProperties != null) {
/* 148 */               endpoint.setProperties(this.endpointProperties);
/*     */             }
/* 150 */             if (this.executor != null) {
/* 151 */               endpoint.setExecutor(this.executor);
/*     */             }
/* 153 */             if (wsAnnotation != null) {
/* 154 */               publishEndpoint(endpoint, wsAnnotation);
/*     */             }
/*     */             else {
/* 157 */               publishEndpoint(endpoint, wsProviderAnnotation);
/*     */             }
/* 159 */             this.publishedEndpoints.add(endpoint);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (CannotLoadBeanClassException ex)
/*     */       {
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Endpoint createEndpoint(Object bean)
/*     */   {
/* 177 */     if (this.webServiceFeatures != null) {
/* 178 */       return new FeatureEndpointProvider(null).createEndpoint(this.bindingType, bean, this.webServiceFeatures);
/*     */     }
/*     */ 
/* 181 */     return Endpoint.create(this.bindingType, bean);
/*     */   }
/*     */ 
/*     */   protected abstract void publishEndpoint(Endpoint paramEndpoint, WebService paramWebService);
/*     */ 
/*     */   protected abstract void publishEndpoint(Endpoint paramEndpoint, WebServiceProvider paramWebServiceProvider);
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 205 */     for (Endpoint endpoint : this.publishedEndpoints)
/* 206 */       endpoint.stop();
/*     */   }
/*     */ 
/*     */   private class FeatureEndpointProvider
/*     */   {
/*     */     private FeatureEndpointProvider()
/*     */     {
/*     */     }
/*     */ 
/*     */     public Endpoint createEndpoint(String bindingType, Object implementor, Object[] features)
/*     */     {
/* 218 */       WebServiceFeature[] wsFeatures = new WebServiceFeature[features.length];
/* 219 */       for (int i = 0; i < features.length; i++)
/* 220 */         wsFeatures[i] = convertWebServiceFeature(features[i]);
/*     */       try
/*     */       {
/* 223 */         Method create = Endpoint.class.getMethod("create", new Class[] { String.class, Object.class, [Ljavax.xml.ws.WebServiceFeature.class });
/* 224 */         return (Endpoint)ReflectionUtils.invokeMethod(create, null, new Object[] { bindingType, implementor, wsFeatures });
/*     */       }
/*     */       catch (NoSuchMethodException ex) {
/* 227 */         throw new IllegalStateException("JAX-WS 2.2 not available - cannot create feature endpoints", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     private WebServiceFeature convertWebServiceFeature(Object feature) {
/* 232 */       Assert.notNull(feature, "WebServiceFeature specification object must not be null");
/* 233 */       if ((feature instanceof WebServiceFeature)) {
/* 234 */         return (WebServiceFeature)feature;
/*     */       }
/* 236 */       if ((feature instanceof Class)) {
/* 237 */         return (WebServiceFeature)BeanUtils.instantiate((Class)feature);
/*     */       }
/* 239 */       if ((feature instanceof String)) {
/*     */         try {
/* 241 */           Class featureClass = getBeanClassLoader().loadClass((String)feature);
/* 242 */           return (WebServiceFeature)BeanUtils.instantiate(featureClass);
/*     */         }
/*     */         catch (ClassNotFoundException ex) {
/* 245 */           throw new IllegalArgumentException("Could not load WebServiceFeature class [" + feature + "]");
/*     */         }
/*     */       }
/*     */ 
/* 249 */       throw new IllegalArgumentException("Unknown WebServiceFeature specification type: " + feature.getClass());
/*     */     }
/*     */ 
/*     */     private ClassLoader getBeanClassLoader()
/*     */     {
/* 254 */       return (AbstractJaxWsServiceExporter.this.beanFactory instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)AbstractJaxWsServiceExporter.this.beanFactory).getBeanClassLoader() : ClassUtils.getDefaultClassLoader();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.AbstractJaxWsServiceExporter
 * JD-Core Version:    0.6.1
 */