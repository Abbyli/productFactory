/*    */ package org.springframework.remoting.jaxrpc;
/*    */ 
/*    */ import javax.xml.rpc.Service;
/*    */ import javax.xml.rpc.ServiceException;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ @Deprecated
/*    */ public class LocalJaxRpcServiceFactoryBean extends LocalJaxRpcServiceFactory
/*    */   implements FactoryBean<Service>, InitializingBean
/*    */ {
/*    */   private Service service;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */     throws ServiceException
/*    */   {
/* 48 */     this.service = createJaxRpcService();
/*    */   }
/*    */ 
/*    */   public Service getObject() throws Exception
/*    */   {
/* 53 */     return this.service;
/*    */   }
/*    */ 
/*    */   public Class<? extends Service> getObjectType() {
/* 57 */     return this.service != null ? this.service.getClass() : Service.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 61 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxrpc.LocalJaxRpcServiceFactoryBean
 * JD-Core Version:    0.6.1
 */