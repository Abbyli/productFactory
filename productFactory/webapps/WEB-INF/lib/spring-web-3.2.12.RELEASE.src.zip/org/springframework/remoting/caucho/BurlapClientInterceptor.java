/*     */ package org.springframework.remoting.caucho;
/*     */ 
/*     */ import com.caucho.burlap.client.BurlapProxyFactory;
/*     */ import com.caucho.burlap.client.BurlapRuntimeException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.net.ConnectException;
/*     */ import java.net.MalformedURLException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.RemoteProxyFailureException;
/*     */ import org.springframework.remoting.support.UrlBasedRemoteAccessor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class BurlapClientInterceptor extends UrlBasedRemoteAccessor
/*     */   implements MethodInterceptor
/*     */ {
/*  63 */   private BurlapProxyFactory proxyFactory = new BurlapProxyFactory();
/*     */   private Object burlapProxy;
/*     */ 
/*     */   public void setProxyFactory(BurlapProxyFactory proxyFactory)
/*     */   {
/*  75 */     this.proxyFactory = (proxyFactory != null ? proxyFactory : new BurlapProxyFactory());
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/*  85 */     this.proxyFactory.setUser(username);
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/*  95 */     this.proxyFactory.setPassword(password);
/*     */   }
/*     */ 
/*     */   public void setOverloadEnabled(boolean overloadEnabled)
/*     */   {
/* 104 */     this.proxyFactory.setOverloadEnabled(overloadEnabled);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 110 */     super.afterPropertiesSet();
/* 111 */     prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */     throws RemoteLookupFailureException
/*     */   {
/*     */     try
/*     */     {
/* 120 */       this.burlapProxy = createBurlapProxy(this.proxyFactory);
/*     */     }
/*     */     catch (MalformedURLException ex) {
/* 123 */       throw new RemoteLookupFailureException("Service URL [" + getServiceUrl() + "] is invalid", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object createBurlapProxy(BurlapProxyFactory proxyFactory)
/*     */     throws MalformedURLException
/*     */   {
/* 135 */     Assert.notNull(getServiceInterface(), "Property 'serviceInterface' is required");
/* 136 */     return proxyFactory.create(getServiceInterface(), getServiceUrl());
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation) throws Throwable
/*     */   {
/* 141 */     if (this.burlapProxy == null) {
/* 142 */       throw new IllegalStateException("BurlapClientInterceptor is not properly initialized - invoke 'prepare' before attempting any operations");
/*     */     }
/*     */ 
/* 146 */     ClassLoader originalClassLoader = overrideThreadContextClassLoader();
/*     */     try {
/* 148 */       return invocation.getMethod().invoke(this.burlapProxy, invocation.getArguments());
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 151 */       Throwable targetEx = ex.getTargetException();
/* 152 */       if ((targetEx instanceof BurlapRuntimeException)) {
/* 153 */         Throwable cause = targetEx.getCause();
/* 154 */         throw convertBurlapAccessException(cause != null ? cause : targetEx);
/*     */       }
/* 156 */       if ((targetEx instanceof UndeclaredThrowableException)) {
/* 157 */         UndeclaredThrowableException utex = (UndeclaredThrowableException)targetEx;
/* 158 */         throw convertBurlapAccessException(utex.getUndeclaredThrowable());
/*     */       }
/*     */ 
/* 161 */       throw targetEx;
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 165 */       throw new RemoteProxyFailureException("Failed to invoke Burlap proxy for remote service [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */     finally
/*     */     {
/* 169 */       resetThreadContextClassLoader(originalClassLoader);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RemoteAccessException convertBurlapAccessException(Throwable ex)
/*     */   {
/* 180 */     if ((ex instanceof ConnectException)) {
/* 181 */       return new RemoteConnectFailureException("Cannot connect to Burlap remote service at [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */ 
/* 185 */     return new RemoteAccessException("Cannot access Burlap remote service at [" + getServiceUrl() + "]", ex);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.caucho.BurlapClientInterceptor
 * JD-Core Version:    0.6.1
 */