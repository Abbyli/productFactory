/*     */ package org.springframework.remoting.httpinvoker;
/*     */ 
/*     */ import java.io.InvalidClassException;
/*     */ import java.net.ConnectException;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteInvocationFailureException;
/*     */ import org.springframework.remoting.support.RemoteInvocation;
/*     */ import org.springframework.remoting.support.RemoteInvocationBasedAccessor;
/*     */ import org.springframework.remoting.support.RemoteInvocationResult;
/*     */ 
/*     */ public class HttpInvokerClientInterceptor extends RemoteInvocationBasedAccessor
/*     */   implements MethodInterceptor, HttpInvokerClientConfiguration
/*     */ {
/*     */   private String codebaseUrl;
/*     */   private HttpInvokerRequestExecutor httpInvokerRequestExecutor;
/*     */ 
/*     */   public void setCodebaseUrl(String codebaseUrl)
/*     */   {
/*  88 */     this.codebaseUrl = codebaseUrl;
/*     */   }
/*     */ 
/*     */   public String getCodebaseUrl()
/*     */   {
/*  95 */     return this.codebaseUrl;
/*     */   }
/*     */ 
/*     */   public void setHttpInvokerRequestExecutor(HttpInvokerRequestExecutor httpInvokerRequestExecutor)
/*     */   {
/* 108 */     this.httpInvokerRequestExecutor = httpInvokerRequestExecutor;
/*     */   }
/*     */ 
/*     */   public HttpInvokerRequestExecutor getHttpInvokerRequestExecutor()
/*     */   {
/* 117 */     if (this.httpInvokerRequestExecutor == null) {
/* 118 */       SimpleHttpInvokerRequestExecutor executor = new SimpleHttpInvokerRequestExecutor();
/* 119 */       executor.setBeanClassLoader(getBeanClassLoader());
/* 120 */       this.httpInvokerRequestExecutor = executor;
/*     */     }
/* 122 */     return this.httpInvokerRequestExecutor;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 127 */     super.afterPropertiesSet();
/*     */ 
/* 130 */     getHttpInvokerRequestExecutor();
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation methodInvocation) throws Throwable
/*     */   {
/* 135 */     if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
/* 136 */       return "HTTP invoker proxy for service URL [" + getServiceUrl() + "]";
/* 139 */     }
/*     */ RemoteInvocation invocation = createRemoteInvocation(methodInvocation);
/*     */     RemoteInvocationResult result;
/*     */     try {
/* 142 */       result = executeRequest(invocation, methodInvocation);
/*     */     }
/*     */     catch (Throwable ex) {
/* 145 */       throw convertHttpInvokerAccessException(ex);
/*     */     }
/*     */     try {
/* 148 */       return recreateRemoteInvocationResult(result);
/*     */     }
/*     */     catch (Throwable ex) {
/* 151 */       if (result.hasInvocationTargetException()) {
/* 152 */         throw ex;
/*     */       }
/*     */ 
/* 155 */       throw new RemoteInvocationFailureException("Invocation of method [" + methodInvocation.getMethod() + "] failed in HTTP invoker remote service at [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult executeRequest(RemoteInvocation invocation, MethodInvocation originalInvocation)
/*     */     throws Exception
/*     */   {
/* 174 */     return executeRequest(invocation);
/*     */   }
/*     */ 
/*     */   protected RemoteInvocationResult executeRequest(RemoteInvocation invocation)
/*     */     throws Exception
/*     */   {
/* 192 */     return getHttpInvokerRequestExecutor().executeRequest(this, invocation);
/*     */   }
/*     */ 
/*     */   protected RemoteAccessException convertHttpInvokerAccessException(Throwable ex)
/*     */   {
/* 202 */     if ((ex instanceof ConnectException)) {
/* 203 */       return new RemoteConnectFailureException("Could not connect to HTTP invoker remote service at [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */ 
/* 207 */     if (((ex instanceof ClassNotFoundException)) || ((ex instanceof NoClassDefFoundError)) || ((ex instanceof InvalidClassException)))
/*     */     {
/* 209 */       return new RemoteAccessException("Could not deserialize result from HTTP invoker remote service [" + getServiceUrl() + "]", ex);
/*     */     }
/*     */ 
/* 213 */     return new RemoteAccessException("Could not access HTTP invoker remote service at [" + getServiceUrl() + "]", ex);
/*     */   }
/*     */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.httpinvoker.HttpInvokerClientInterceptor
 * JD-Core Version:    0.6.1
 */