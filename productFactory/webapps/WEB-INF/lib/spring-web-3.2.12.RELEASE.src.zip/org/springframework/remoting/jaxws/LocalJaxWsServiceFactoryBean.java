/*    */ package org.springframework.remoting.jaxws;
/*    */ 
/*    */ import javax.xml.ws.Service;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class LocalJaxWsServiceFactoryBean extends LocalJaxWsServiceFactory
/*    */   implements FactoryBean<Service>, InitializingBean
/*    */ {
/*    */   private Service service;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 45 */     this.service = createJaxWsService();
/*    */   }
/*    */ 
/*    */   public Service getObject() {
/* 49 */     return this.service;
/*    */   }
/*    */ 
/*    */   public Class<? extends Service> getObjectType() {
/* 53 */     return this.service != null ? this.service.getClass() : Service.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 57 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\svn\productFactory\webapps\WEB-INF\lib\spring-web-3.2.12.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.jaxws.LocalJaxWsServiceFactoryBean
 * JD-Core Version:    0.6.1
 */